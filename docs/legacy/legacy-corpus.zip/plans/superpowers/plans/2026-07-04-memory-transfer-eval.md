# Memory Transfer Eval Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a reproducible offline evaluation harness for cross-project memory transfer, leakage, token impact, and traceability.

**Architecture:** The first slice is read-only. It extracts conversation/project manifests from CC Switch, Codex, Claude, and OpenCode local stores, then produces stable IDs that every Agent can use in later retrieval and execution experiments. Product code and shared contracts stay untouched.

**Tech Stack:** Bun TypeScript scripts, `bun:sqlite`, JSONL parsers, local Markdown/JSON eval artifacts.

---

### Task 1: Conversation And Project Manifest Extractor

**Files:**
- Create: `app/scripts/memory-transfer-eval.ts`
- Test: `app/scripts/__tests__/memory-transfer-eval.test.ts`
- Output: `eval/memory-transfer/conversation-manifest.json`
- Output: `eval/memory-transfer/project-manifest.json`
- Output: `eval/memory-transfer/summary.md`

- [x] **Step 1: Add a failing fixture test**

Create a fixture CC Switch DB with `session_log_sync` and `proxy_request_logs`, plus fixture Codex, Claude, and OpenCode conversations. Assert the extractor emits stable `C-0001` / `P-0001` identifiers, project folders, source paths, titles, message counts, and token totals.

- [x] **Step 2: Run the targeted test**

Run:

```bash
cd app && bun test scripts/__tests__/memory-transfer-eval.test.ts
```

Expected first result before implementation: fail because the script module does not exist.

- [x] **Step 3: Implement the extractor**

Implement a read-only extractor that:

- Reads `/Users/lullwen/.cc-switch/cc-switch.db` by default.
- Uses `session_log_sync.file_path` as the authoritative list of source conversations.
- Joins `proxy_request_logs` by `session_id` for request count and token totals.
- Parses Codex JSONL `session_meta.payload.cwd` and `session_id`.
- Parses Claude JSONL `cwd`, `sessionId`, and first user message.
- Parses OpenCode DB session/project rows for `ses_*` sessions.
- Writes stable manifests to `eval/memory-transfer/`.

- [x] **Step 4: Run the targeted test again**

Run:

```bash
cd app && bun test scripts/__tests__/memory-transfer-eval.test.ts
```

Expected: pass.

- [x] **Step 5: Run against local CC Switch data**

Run:

```bash
cd app && bun run scripts/memory-transfer-eval.ts --limit 120
```

Expected: creates/updates the three eval artifacts and prints a short summary with conversation count, project count, and source-app distribution.

### Task 2: Retrieval Strategy Eval Fixtures

**Files:**
- Create: `eval/memory-transfer/tasks.seed.json`
- Create: `eval/memory-transfer/memory-labels.seed.json`
- Create: `eval/memory-transfer/runs.template.md`

- [x] **Step 1: Create seed task schema**

Add task records with `taskId`, `targetProjectNo`, `taskType`, `prompt`, `positiveMemoryIds`, `forbiddenMemoryIds`, and `leakageTraps`.

- [x] **Step 2: Create memory label schema**

Add memory records with `memoryId`, `sourceProjectNo`, `scope`, `content`, `allowedTargets`, `blockedTargets`, `risk`, and `mustNotInjectWhen`.

- [x] **Step 3: Add run report template**

Add a report template that all Agents must fill with `conversationNo`, `projectNo`, `memoryIds`, `strategy`, `tokens`, `leakage`, `planScore`, and `verdict`.

### Task 3: Strategy Scoring Harness

**Files:**
- Create: `app/scripts/memory-transfer-score.ts`
- Test: `app/scripts/__tests__/memory-transfer-score.test.ts`

- [x] **Step 1: Add score test**

Create fixture runs for strategies A/B/C/D/E. Assert the scorer computes `helpfulRecall@5`, `precision@5`, `leakage@5`, `conflictRate`, `sensitiveLeakCount`, and pass/fail against the thresholds in the user-approved eval plan.

- [x] **Step 2: Implement scorer**

Read task, memory, and run JSON. Compute per-strategy and per-task metrics. Fail D if `sensitiveLeakCount > 0` or `leakage@5 > 5%`.

- [x] **Step 3: Run scorer test**

Run:

```bash
cd app && bun test scripts/__tests__/memory-transfer-score.test.ts
```

Expected: pass.

### Task 4: Governed Memory Candidate Extraction

**Files:**
- Create: `app/scripts/memory-transfer-extract.ts`
- Test: `app/scripts/__tests__/memory-transfer-extract.test.ts`
- Output: `eval/memory-transfer/memory-candidates.json`
- Output: `eval/memory-transfer/memory-candidates.md`

- [x] **Step 1: Add a failing extraction test**

Create fixture conversations that include a project-specific UI rule, a reusable Bun test-selection rule, a transferable cross-project abstraction rule, and a sensitive token/account conversation. Assert the extractor produces governed short memories, not raw logs.

- [x] **Step 2: Implement deterministic extraction**

The extractor currently recognizes:

- project-specific UI doc rules as `project_specific`
- Bun/TypeScript validation habits as `tool_pattern`
- cross-project abstraction rules as `transferable`
- sensitive credential/account/token conversations as `sensitive`
- absolute local paths as `raw_path`

Sensitive and raw-path records are retained only as governance facts; they are blocked from default injection.

- [x] **Step 3: Run against the local manifest**

Run:

```bash
cd app && bun run scripts/memory-transfer-extract.ts --max 80
```

Current result from the 113-conversation manifest: 12 candidates total: 6 `raw_path`, 4 `sensitive`, 2 `tool_pattern`. This is intentionally conservative and should be treated as a lower-bound candidate set, not final recall.

### Task 5: Automatic Retrieval Run Generator

**Files:**
- Create: `app/scripts/memory-transfer-retrieve.ts`
- Test: `app/scripts/__tests__/memory-transfer-retrieve.test.ts`
- Output: `eval/memory-transfer/runs.generated.json`
- Output: `eval/memory-transfer/runs.generated.md`

- [x] **Step 1: Add a failing strategy-gating test**

Create fixture tasks for `P-0010` and `P-0017`. Assert naive global strategy C can retrieve project-specific and sensitive memories, while D/E block them and still retrieve transferable memories.

- [x] **Step 2: Implement A/B/C/D/E retrieval**

Implemented strategy behavior:

- A: no memory baseline.
- B: same-project/global only, sensitive blocked.
- C: naive global similarity, no project/sensitive gating; used as leakage counterexample.
- D: governed agentic route, with safety gate plus relevance gate.
- E: context-spine route, prioritizing transferable/global context under the same safety gate.

- [x] **Step 3: Generate and score runs**

Run:

```bash
cd app && bun run scripts/memory-transfer-retrieve.ts --strategies A,B,C,D,E --top-k 5
cd app && bun run scripts/memory-transfer-score.ts --runs ../eval/memory-transfer/runs.generated.json --out ../eval/memory-transfer
```

Current generated-run score:

| Strategy | helpfulRecall@5 | precision@5 | leakage@5 | conflictRate | sensitiveLeaks | avgInjectedTokens | Verdict |
|---|---:|---:|---:|---:|---:|---:|---|
| A | 0% | 0% | 0% | 0% | 0 | 0 | pass baseline |
| B | 48.33% | 65% | 0% | 0% | 0 | 64 | pass baseline |
| C | 88.33% | 52% | 16% | 80% | 0 | 120 | fail |
| D | 76.67% | 86.67% | 0% | 0% | 0 | 49 | pass |
| E | 76.67% | 86.67% | 0% | 0% | 0 | 49 | pass |

Interpretation: naive global retrieval has high recall but unacceptable leakage/conflict. The current best default route is D/E-style governed agentic retrieval: safety gate first, relevance gate second, token cap by returning fewer than topK when additional memories are not task-relevant.

### Self-Review

- Spec coverage: Task 1 covers detailed conversation numbering and project folders from CC Switch. Task 2 covers eval dataset labels. Task 3 covers pass/fail scoring. Task 4 covers governed memory extraction from real conversation manifests. Task 5 covers automatic strategy comparison and token/leakage scoring.
- Placeholder scan: no TBD/TODO placeholders.
- Scope check: implementation is isolated to eval scripts/artifacts; product runtime, shared contracts, session store, and UI remain untouched.

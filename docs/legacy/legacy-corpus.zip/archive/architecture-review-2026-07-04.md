吗# Fleet 架构评审报告

> 日期：2026-07-04
> 范围：订阅会员 / API 路由 / CLI Runtime / 团队编排 / 成本账本
> 主线：`Fleet owns the team, API owns control, CLI owns a run`
> 代码基线：`work/fresh-base-spine`（`app/` 目录）

> **落地更新（2026-07-04）**：本报告提出的 `TeamRunCostSource` 扩展与 `MembershipProfile` / `QuotaSnapshot` / `QuotaAdapter` 只读协议已进入代码；`server-core` 已有只读 `QuotaService` registry，`shared/protocol/subscription.ts` 已提供 `quotaSnapshotToPlanUsage` 复用 Token 环的 `PlanUsage`。`teamRun.invokeAction` 也已接入 `InternalActionExecutorService`，仅允许 L0/L1，L2/L3 结构化拒绝。`TeamRunCoordinator.startRunAndWaitForReport` 与 `teamRun:startRun({waitForReport:true})` 已具备 blocking await / `timeout_pending_report` 骨架。真实 provider adapter、刷新 RPC、UI 展示、TeamRun 路由建议、真实 CLI Bridge/MCP 注入和报告自动归集仍未实现。下文保留原评审风险描述，但以本段为当前状态修正。

---

## 1. 路线有效性：强烈推荐

**推荐**。用户提出的主线「Fleet owns team, API owns control, CLI owns a run」与 docs/38 的 D19 目标架构完全一致，且 D19 决策已正式写入 docs/04 §1 的 D19 条目。代码方向与文档决策无原则性冲突——当前代码的问题是**半成品**，不是**方向错误**。

### 1.1 文档-代码对齐度

| 维度 | 文档（docs/38）目标 | 代码现状 | 对齐 |
|---|---|---|---|
| **Fleet owns the team** | AgentSeat / RuntimeLane / TeamRun / attributionChain 归 Fleet | ✅ 协议已冻结（`team-run.ts:294` line），类型齐全 | ✅ |
| **API owns control** | 普通对话只走 API；管理 Agent 固定 cheap API 永不 CLI | ✅ `surface='chat'` 已隐藏 CLI picker（`FreeFormInput.tsx` 条件渲染） | ✅ |
| **CLI owns a run** | CLI 只拥有一次执行 run 的上下文 | 🟨 协议有 one-shot adapter，但 ACP/PTY 长会话 launcher 未完成 | 🟨 |
| **Bridge 同步阻塞** | 对外同步 blocking await，对内异步 TeamRun | 🟨 `startRunAndWaitForReport` 骨架已接；真实 CLI Bridge tool 注入、成员报告自动归集和端到端 smoke 未完成 | 🟨 |
| **权限/租约/timeline 归 Fleet** | 所有能力回写 craft SessionManager | 🟨 WorkspaceFileLeaseManager 已接 TeamRun；permission UI 和持久化未完 | 🟨 |
| **成本账本** | 真实/估算/未知三分 | 🟨 `TeamRunCostSource` 已扩展为 `LOCAL_COMPUTE / SUBSCRIPTION_QUOTA / BYOK_API / FLEET_CLOUD / EXTERNAL_JOB / UNKNOWN`；成本写入和 UI 归因仍需继续接 | 🟨 |
| **Capability Loadout** | 按 lane 裁剪工具表 | ❌ 无实现；protocol/capability.ts 存在但 catalog/loadout/resolver 未建 | ❌ |
| **QuotaAdapter** | 读取用户已有 CLI 订阅额度 | 🟨 共享只读协议与 `QuotaService` registry 已有；真实 provider adapter / RPC / UI 仍无实现 | 🟨 |

### 1.2 路线不偏离的原因

1. **类型层先于实现层是对的**。`team-run.ts` 的类型定义（AgentSeat/RuntimeLane/TeamRun/RunReport/AttributionChain/错误码）已冻结，覆盖了 D19 的核心语义。这是"协议先行"，后续实现只需往里面填逻辑。
2. **TeamRunCoordinator 已有真实投递路径**（`team-run-coordinator.ts:180-181` 调用 `sessionManager.sendMessage` 投递到目标 session），不走假 running。
3. **WorkspaceFileLeaseManager 的冲突规则设计正确**（read 不互斥、write/git_write 互斥、`workspace:*` 覆盖一切），7 条单测覆盖。
4. **Surface 分离的架构决策已体现在代码中**（`FreeFormInput` 按 surface 条件渲染），不再是文档说目标态但代码还在 UI 上混着。
5. **没有走错路**：没有给 CLI 建第二套 session/store，没有在普通对话里混 CLI runtime picker，没有把 CLI 当作 API 模型路由的候选。

---

## 2. Top 3 架构风险

### 风险 1：Bridge 同步阻塞不是"没做完"而是"设计缺失"会锁死 CLI 队长场景

**状态更新（2026-07-04）**：`teamRun.invokeAction` 已接 L0/L1 Internal Action gate，不再是 stub；`startRunAndWaitForReport` 已提供 RunReport 等待/超时返回骨架。但真实 CLI Bridge tool 注入、成员报告自动归集和端到端 smoke 仍未落地，所以 CLI 队长调 API 队员的核心风险仍成立。

**位置**：`app/packages/server-core/src/services/runtime-launcher-adapter.ts:29-44`（RuntimeLauncherAdapter 接口）、`app/packages/server-core/src/handlers/rpc/team-run.ts`（Bridge handler）

**问题**：
- docs/38 §4.2 定义了同步阻塞桥：CLI 调用 `fleet.start_member_run` 时 Bridge 挂起 tool call，Core 后台异步调度，完成后返回 RunReport。这是整个「CLI 队长调 API 队员」场景的核心机制。当前已有等待骨架，但真实 CLI tool 注入与报告归集未接，仍不能算端到端闭环。
- 当前 `RuntimeLauncherAdapter.launch()` 是普通 async 返回 Promise，没有 machinery 能让外部 CLI 的 tool call 挂起等待 Fleet 内部的异步 TeamRun。
- `invokeAction` 已可执行 L0/L1 Internal Action；`startRunAndWaitForReport` 已可等待压缩 RunReport 或返回 timeout pending report；外部 CLI 仍无法通过一个真实注入的 Bridge tool 发起并完整验收 TeamRun。
- `NativeOneShotRuntimeLauncherAdapter` 的 `bridgeInjection = 'not-supported'`（`runtime-launcher-adapter.ts:113`），所有当前 supported runtime（Codex/Claude/Grok/Antigravity/Pi/Cursor）都走 one-shot + bridge unavailable。**没有一个真实 CLI 能通过 Bridge 调 API 队员**。

**影响**：如果按当前顺序继续推进 Subscription Quota / Capability Loadout 等上层功能，CLI 队长的核心场景（跨 Runtime 调度）仍然是纸面上的——用户真实体验是我选了 CLI 队长但无法让它调 API 设计队员。

**建议**：Bridge 同步阻塞必须在 Quota / Loadout 之前排入 P0 优先级。优先接一个真实 CLI（如 Codex 或 Claude Code）的 Bridge 注入链路，做端到端 smoke：CLI 队长 → `fleet.start_member_run` → API 队员执行 → RunReport 回 CLI。smoke 通了才算 D19 核心场景闭环，再往上堆 Quota / Loadout 才有意义。

### 风险 2：`TeamRunCostSource` 枚举不完整导致"用户已有订阅承担成本"不可表达

**状态更新（2026-07-04）**：已整改。`TeamRunCostSource` 已扩展为 `LOCAL_COMPUTE | SUBSCRIPTION_QUOTA | BYOK_API | FLEET_CLOUD | EXTERNAL_JOB | UNKNOWN`。后续风险从"无法表达"转为"需要把归因写入 TeamRun / RunReport / UI / ledger 的真实数据路径"。

**位置**：`app/packages/shared/src/protocol/team-run.ts:213-216`

```ts
export type TeamRunCostSource =
  | 'LOCAL_COMPUTE'   // 本机 CLI，不消耗 API token
  | 'BYOK_API'        // 用户自带 API key
  | 'FLEET_CLOUD'     // Fleet 云端 API
```

**缺失值**：
- `SUBSCRIPTION_QUOTA`：用户的 Claude Pro/Max、Codex、SuperGrok 订阅额度承担了这次 TeamRun 的成本
- `EXTERNAL_JOB`：生图、生视频等 External Job 的成本
- `UNKNOWN`：无法确定成本来源（docs/16 §2.2.3 的 `UsageSource` 包含 `unknown`，成本也应有）

**影响**：
- docs/38 §3.1 第 2 条（全文最值得记住的一条）说「省 token 最大的杠杆是这个任务该不该整个转嫁给一个已经沉没成本的 CLI 订阅」，但 `TeamRunCost` 的 `source` 字段无法表达"成本由用户已有订阅承担，Fleet 零成本"——这是 `LOCAL_COMPUTE` 和 `SUBSCRIPTION_QUOTA` 的关键区别：前者是本机跑不需要付费，后者是用户已经付过订阅费。
- 同理 `TeamRunCost` 被 `RunReport.cost` 复用（`team-run.ts:195`），RunReport 回给 CLI 队长的成本信息同样缺这些分类。
- docs/38 §5.2 成本归因表只写了 `LOCAL_COMPUTE / BYOK_API / FLEET_CLOUD` 三种——**文档本身也已经落后于产品需求**（用户明确要求能按订阅额度做路由判断）。

**建议**：冻结前补齐为：
```ts
export type TeamRunCostSource =
  | 'LOCAL_COMPUTE'          // 本机 CLI，不消耗 API token（无订阅，纯本地算力）
  | 'SUBSCRIPTION_QUOTA'     // 用户已有订阅（Claude Pro/Max / Codex / SuperGrok 等）承担
  | 'BYOK_API'               // 用户自带 API key / 余额
  | 'FLEET_CLOUD'            // Fleet 云端 API（M3 条件项，当前不预填）
  | 'EXTERNAL_JOB'           // 生图/生视频等 External Job 产生的独立成本
  | 'UNKNOWN'                // 无法确定
```

### 风险 3：QuotaAdapter / MembershipProfile 原先完全缺失，真实 provider adapter 仍未落地

**状态更新（2026-07-04）**：已部分整改。`shared/protocol/subscription.ts` 已冻结 `MembershipProfile` / `QuotaSnapshot` / `QuotaAdapter`，`server-core` 已有 `QuotaService` registry；真实 provider adapter、刷新 RPC、UI 展示和 TeamRun 创建时读取 quota 仍未实现。

**原评审位置**：整个 `app/` 目录当时没有 `MembershipProfile` / `QuotaSnapshot` / `QuotaAdapter`。当前已补共享协议与服务 registry，未补真实 provider adapter。

**问题**：
- docs/16 §2.2.5 明确规划了「先在共享协议补只读 `MembershipProfile` / `QuotaSnapshot`」作为最佳落地顺序第 1 步，字段都已列明（`membershipProductId`、`accountProviderId`、`apiProviderId?`、`bridgeRuntimeId?`、`modelProviderId?`、`authMode`、`billingMode`、`quotaSource`、`windows[]`、`iconSource`、`source/confidence/observedAt/error`）。
- AGENTS.md 规则 41 说「CLI/API 的选择点是创建 TeamRun / 分派任务时」，选型依据之一是「读一眼对应 CLI 的套餐额度账本还有没有余量」。**但类型根本不存在**，任何代码都无法按这个逻辑做判断。
- docs/32 §1.2 的 P1-1 闭环计划列为「建 QuotaAdapter 抽象：Claude/Codex/SuperGrok/Copilot 只在合法账号能力暴露真实窗口时显示」——但没有共享类型，adapter 接口设计无从落地。

**影响**：
- 这是一个"文档超前于代码"的典型漂移：多达 3 篇正规格文档引用了尚未在任何文件中定义的类型名称。如果并行 Agent 以"MembershipProfile 已定义"为前提开工，必然发现共享协议中找不到类型，然后要么等 Lead、要么自己往 `team-run.ts` 里加（违反契约冻结规则 36）。
- Token 环详情卡目前「套餐额度样式仅有真实 plan windows 时显示」（docs/16 §2.2.5），但"有真实 plan windows"的判断依据是什么？代码里没有任何地方能表达 `PlanWindow` 这个概念。

**建议**：在 Bridge/Quota 排期之前，先由 Lead 在 `shared/protocol/` 下建 `subscription.ts` 冻结 `MembershipProfile` / `QuotaSnapshot` / `PlanWindow` / `QuotaAdapter`（接口）的只读类型。不做实现——只是让所有引用这些概念的文档和 Agent 有一个真实的类型锚点。

---

## 3. 应首先冻结的协议

### 3.1 第一优先：`TeamRunCostSource` 扩展

**文件**：`app/packages/shared/src/protocol/team-run.ts:213-216`

**当前**：3 值（`LOCAL_COMPUTE | BYOK_API | FLEET_CLOUD`）

**冻结后**：6 值（加 `SUBSCRIPTION_QUOTA | EXTERNAL_JOB | UNKNOWN`），见 §2 风险 2 的具体定义。

**理由**：这是财务/成本系统的类型基石。成本账本、RunReport、Token 环详情卡、订阅额度路由判断都依赖这个枚举。现在只有 3 值，后续补齐必然要改协议，会造成依赖这些类型的代码漂移。Move early, freeze now.

### 3.2 第二优先：`MembershipProfile` / `QuotaSnapshot` 只读协议

**文件**：新建 `app/packages/shared/src/protocol/subscription.ts`

**最少冻结字段**（来自 docs/16 §2.2.5）：

```ts
export interface MembershipProfile {
  membershipProductId: string   // 订阅产品 id（如 grok:supergrok）
  accountProviderId: string     // 账号/厂商（如 xAI / Anthropic / OpenAI）
  apiProviderId?: string        // 对应的 API provider（如 xai / anthropic / openai）
  bridgeRuntimeId?: string      // 对应的 CLI Runtime id（如 codex / claude-code / grok）
  modelProviderId?: string      // 模型 catalog 的 provider id
  displayName: string           // 显示名（如 SuperGrok / Claude Pro / Codex Pro）
  authMode: 'subscription' | 'api' | 'local' | 'external' | 'unknown'
  billingMode: 'subscription' | 'api' | 'local' | 'external' | 'unknown'
  quotaSource: 'runtime' | 'official_api' | 'user_authorized_oauth' | 'local_snapshot' | 'provider_passthrough' | 'unknown'
  iconSource: string            // 图标路径或 provider icon id
  windows: PlanWindow[]         // 套餐额度窗口
  source: UsageSource           // 复用 docs/16 的 UsageSource
  confidence: 'high' | 'medium' | 'low' | 'unknown'
  observedAt: string            // ISO datetime
  error?: string                // 最后一次刷新失败原因
}

export interface PlanWindow {
  name: string                  // 窗口名（如 5 小时额度 / 每周·所有模型）
  used?: number
  total?: number
  remaining?: number
  unit: 'percent' | 'credits' | 'tokens' | 'requests' | 'currency'
  usedPercent?: number          // 0-100
  resetsAt?: string             // ISO datetime
  source: UsageSource
}

export interface QuotaSnapshot {
  profiles: MembershipProfile[]
  timestamp: number
  error?: string
}

/** Usage 来源信任度（复用 docs/16 §2.2.3 的 UsageSource） */
export type UsageSource = 'provider' | 'runtime' | 'local-metered' | 'estimated' | 'unknown'
```

**理由**：docs/16 §2.2.5 已列明字段但未落地协议。QuotaAdapter 实现和 UI 都依赖这个类型——没有它，TeamRun 路由决策中「检查订阅额度有余量」的代码无法写。

### 3.3 第三优先：`CapabilityLoadout` 只读协议

**文件**：近期已有 `docs/43` 定义完整规格，`protocol/capability.ts` 文件应已存在。核实后冻结 `loadout` 相关类型。

**最少冻结字段**：
- `CapabilityLoadout`：`seatId / laneId / internalActions[] / skills[] / mcpServers[] / cliCapabilities[] / apiTools[]`
- `CapabilityCatalog`：枚举所有可装载能力
- `LoadoutResolver`：按 seat/lane 裁剪可用工具表

**理由**：多项目隔离和工具表裁剪是 D19 §9 的要求——「不同 runtime 的 Skill/MCP/模型不强行统一，统一的是 Capability Catalog 和 loadout」。这个协议不先冻，并行 Agent 各写各的 loadout 逻辑必然冲突。

---

## 4. 实现顺序

### 优先级排名与论证

| 排名 | 项 | 理由 |
|---|---|---|
| **1. Bridge 同步阻塞** | 风险 1（最高风险）。没有这个，CLI 队长调 API 队员的核心场景是假的。docs/38 §13 的 P3 写了必须做但代码无实现。是承重墙，必须先落。 |
| **2. TeamRunCostSource 扩展** | 风险 2。只有 3 行 diff，但影响面贯穿成本账本/RunReport/Token 环/TeamRun 路由。越早改越便宜。 |
| **3. MembershipProfile 协议** | 风险 3。类型先存在，QuotaAdapter 实现才能开工，Token 环套餐视图才有一个真实的枚举值可以 switch。 |
| **4. QuotaAdapter 实现** | 依赖 3。先做 Claude/Codex 两个最常用订阅的 runtime statusline 读取；失败兜底 unknown。不做 UI 实时刷新——先做"创建 TeamRun 时读一次"以支撑 docs/38 §3.1 的路由建议。 |
| **5. WorkspaceFileLease 持久化 + CLI harness 粗粒度租约** | 当前只有内存（进程重启全丢）。持久化后才能用于真实 CLI 编码保护。粗粒度 `workspace:*` 租约是 CLI harness 无法精确声明写文件时的兜底方案。 |
| **6. Capability Loadout** | 多项目工具表裁剪是 M2 需求。排在 Bridge/Quota 之后，因为目前最重要的隔离是"CLI 的 API tool 不直接暴露给 API 队员"——这个已经通过 Bridge 工具集清单做到。 |
| **（不排）Fleet Portal / Daemon / Sandbox** | AGENTS.md 规则 41 明确是 M3 条件项，docs/42 标注未拍板。本轮不允许进入实现。 |

### 详细排序（按依赖链）

```
Step 0 (Lead)：冻结 TeamRunCostSource 扩展 + MembershipProfile 协议
    ↓
Step 1 (Lead/主线)：Bridge 同步阻塞
    - 选一个真实 CLI（Codex 或 Claude Code）走完整 Bridge 注入 → start_member_run → 
      同步等待 → TeamRun 异步执行 → RunReport 回 CLI 的 smoke
    - 这一步通了才算 D19 核心场景闭环
    ↓
Step 2a (并行 Agent A)：QuotaAdapter 实现（依赖 Step 0 的 MembershipProfile 类型）
    - 读取 Claude Code statusline stdin / Codex runtime 的 rate_limits/credits
    - 缓存上次成功值，失败不阻塞
Step 2b (并行 Agent B)：WorkspaceFileLease 持久化 + permission UI（独立，与 2a 无冲突）
    - 落地到 workspace .fleet/leases.json 或类似
    - 还原启动时未释放的过期租约
    - 人类 permission 弹窗显示租约冲突细节
    ↓
Step 3 (并行 Agent C)：Capability Loadout
    - 建 catalog/loadout/resolver
    - 多 workspace 工具表隔离
```

### 为什么 Capability Loadout 排在 Quota 后面

- Quota 有直接的用户体验影响：「这个任务建议走 Codex CLI，因为本月订阅还有 90% 额度」是一条具体的产品行为，用户能直接感知价值。
- Capability Loadout 解决的是"工程稳定性"（不同项目不互相污染工具表），在只有一个项目/一个工作区的使用场景里，用户感知不到差异。
- 按 `docs/01` M0→M1→M2 节奏：租约/团队已有用户可感知的半成品，优先收口；loadout 属于 M2 治理增强，可以等 Bridge 和 Quota 稳了再说。

---

## 5. 代码缺陷核实（逐一核对用户清单）

### 5.1 CLI Runtime Send

**用户状态**：`usable` base / `wired but not visually checked`

**核实**：✅ 正确。Codex/Claude/Grok/Antigravity/Pi/Cursor Agent 的 one-shot adapter 代码存在（`runtime-launcher-adapter.ts:110-184`、`native-cli-runtime.ts`）。ACP（Goose/Hermes/OpenCode/Custom）的发送链路存在（`services/acp/`）。但 `docs/32 §2`「CLI Runtime」行明确标注：「未做：usage/额度采样、真实 CLI smoke、Claude 等 CLI 的 reasoning flag 实机确认」。状态描述准确。

### 5.2 TeamRun

**用户状态**：`wired but not visually checked`

**核实**：✅ 正确。`TeamRunCoordinator`（`team-run-coordinator.ts:332`）有 propose/startRun/getStatus/getReport/cancel/submitReport 完整状态机。`startRun` 已走真实 `SessionManager.sendMessage` 投递（`team-run-coordinator.ts:180-181`）。`teamRun.sendMessage` RPC 按 target seat 投递真实 session（`team-run.ts:83-93`）。

缺失项（用户列出的）：
- 🟨 Bridge 同步阻塞：blocking await 骨架已接；真实 CLI Bridge tool 注入和报告自动归集未实现
- ❌ 报告自动归集：`submitReport` 方法存在但未接实际 session 事件
- 🟨 `invokeAction`：L0/L1 已接 Internal Action gate；L2/L3 拒绝；真实 CLI tool 注入未验
- ❌ permission UI：无
- 🟨 WorkspaceFileLease 已接，但持久化未做

### 5.3 RuntimeLauncherAdapter

**用户状态**：`wired but not visually checked`

**核实**：✅ 正确。`RuntimeLauncherAdapter` 接口（`runtime-launcher-adapter.ts:29-44`）+ registry（`:80-104`）+ `NativeOneShotRuntimeLauncherAdapter`（`:110-184`）存在。可诊断 binary/version/bridgeStatus，可真实启动 one-shot 进程返回 pid/startedAt/stderrTail。

缺失项：
- ❌ Bridge/MCP 注入：所有 adapter 的 `bridgeInjection = 'not-supported'`
- ❌ ACP/PTY launcher：无实现
- ❌ 长期进程 cleanup：one-shot 的 cleanup 是 no-op；ACP/PTY 长会话无 cleanup
- ❌ Native hook permission bridge（docs/38 §8.4 的 omnigent 范式）：无实现

### 5.4 WorkspaceFileLeaseManager

**用户状态**：`wired but not visually checked`

**核实**：✅ 正确。`WorkspaceFileLeaseManager`（`workspace-file-lease-manager.ts:21-88`）有完整内存实现：TTL、read/write/git_write 冲突规则、过期清理。7 条单测（`workspace-file-lease-manager.test.ts`）。已接入 `TeamRunCoordinator` 的 `acquireWorkspaceFileLeases`（`team-run-coordinator.ts:274-305`）——冲突会进入 `blocked_waiting_for_lease` 并阻止 dispatch。

缺失项：
- ❌ 持久化（内存单例，重启全丢）
- ❌ permission UI（租约冲突后人类无感知）
- ❌ CLI harness 粗粒度 `workspace:*` 租约声明

### 5.5 Subscription Quota

**用户状态**：`wired but not visually checked`（协议/registry）+ `not implemented`（真实采样/UI）

**核实更新（2026-07-04）**：共享 `MembershipProfile` / `QuotaSnapshot` / `QuotaAdapter` 类型已落地，`server-core` 已有只读 `QuotaService` registry，Token 环可复用 `quotaSnapshotToPlanUsage`。仍没有 Claude/Codex/Grok/Gemini/Copilot 的真实额度采样 adapter、缓存刷新、RPC handler 和 UI 展示；因此套餐额度真实数据源仍是 `not implemented`。

### 5.6 Token 环

**用户状态**：`usable` session usage / `not implemented` plan quota

**核实**：✅ 正确。docs/16 §2.2.5 的行「Token 环详情」状态写为：`usable`（provider/runtime 上下文总量 + Fleet 本地计量分项）+ `not implemented`（system/tool definitions/rules 装配级分项）+ `display-only`（套餐额度样式）。与用户描述「API usage, context occupancy, membership quota, cost still need thorough view separation」一致。

### 5.7 Cost Ledger

**用户状态**：`wired but incomplete`

**核实更新（2026-07-04）**：`TeamRunCostSource` 已扩展为：
```ts
| 'LOCAL_COMPUTE' | 'SUBSCRIPTION_QUOTA' | 'BYOK_API' | 'FLEET_CLOUD' | 'EXTERNAL_JOB' | 'UNKNOWN'
```
后续仍需把这六值归因写入 TeamRun、RunReport、Token 环和持久化账本；当前只是协议层整改完成。

### 5.8 Capability Loadout

**用户状态**：`not implemented`

**核实**：✅ 正确。全文 grep `CapabilityLoadout` 返回空。`docs/43` 定义了完整规格但协议/服务/UI 均未落地。`InternalActionRegistry` 存在（`internal-action.ts:227-234`）但负责的是 Fleet 内部结构化动作，不是跨 Runtime 的 Skill/MCP/CLI 能力裁剪。

### 5.9 Fleet Portal

**用户状态**：`not implemented / M3`

**核实**：✅ 正确。代码库中无任何 Portal/billing/cloud-gateway 实现。docs/42 §5 只有约 6 行轻量描述。AGENTS.md 规则 41 和 docs/01 §5 的 M3 标注明确此为非当前项。

---

## 6. 技术决策审查（逐一回答用户提出的 8 个问题）

### 6.1 MembershipProfile / QuotaSnapshot 是否应先冻结只读协议而非直接实现 providers？

**强烈同意**。当前既无类型也无 providers，代码完全空白。先冻结至少 `MembershipProfile / QuotaSnapshot / PlanWindow` 三类型（见 §3.2），让 Token 环 UI 和 TeamRun 路由代码有一个真实的类型锚点。Provider 实现（逐 CLI 读 statusline/usage API）可以在协议冻结后并行开工。

### 6.2 TeamRunCostSource 是否应扩展为 6 值？

**同意**。扩展为 `LOCAL_COMPUTE | SUBSCRIPTION_QUOTA | BYOK_API | FLEET_CLOUD | EXTERNAL_JOB | UNKNOWN`。理由见 §2 风险 2。`SUBSCRIPTION_QUOTA` 是 docs/38 §3.1 第 2 条（全文最重要的一句）能否在产品中落地的类型前提。

### 6.3 CLI/API 选择点是否应固定在 TeamRun 创建/任务分派时而非逐消息 Auto 路由？

**强烈同意**。docs/38 §3.1 已有详细论证：CLI 有常驻上下文和独立计费，在运行中切换等于丢弃进程积累的理解。当前代码里 `SessionManager.sendMessage` 一旦检测到 `cliRuntimeId` 就跳过整条 Auto/Fusion/缓存路由——这本质是**创建会话时人工选的**，后续逐条消息不会重新判断。所以这个决策点天然就是「创建/分派时」，而不是「逐消息」。用户提出的「固定在 TeamRun 创建/任务分派时」和现有代码行为一致，只需在文档和 UI 上把这个「选择粒度」写清楚即可。

### 6.4 Bridge 必须采用「对外同步阻塞、对内异步 TeamRun」吗？

**必须**。外部原装 CLI（Claude Code、Codex、Grok 等）的 tool call 机制多数是同步等待返回。如果 Fleet 让它们自己轮询 `get_run_status`，不支持的 CLI 直接卡死。当前代码已有 `startRunAndWaitForReport` 的 blocking machinery，但 `NativeOneShotRuntimeLauncherAdapter.launch()` 仍没有把固定 Bridge tools 注入真实 CLI，也没有自动把成员 session 结果归集为 RunReport。参考范式：`fleet.start_member_run` 在外部 CLI 看来是一个同步工具返回 RunReport，内部 Fleet 异步执行 TeamRun，超时时返回 `RUN_TIMEOUT_PENDING_REPORT`。

### 6.5 ACP runtime 权限是否应采纳 AionUi 的 session/request_permission 结构？

**同意**。docs/29 §1.1 的 A 类表已验证：AionUi 的 `AcpPermissionRequest`（`session_id` + `tool_call` + `options: allow_once/allow_always/reject_once/reject_always`）是 ACP 协议标准结构。当前 Fleet 的 `services/acp/` 已有 ACP 连接，但权限请求如何从 ACP CLI 传回 Fleet UI 的具体桥接未实现。直接复用 AionUi 的 `AcpPermissionRequest` 结构（从 `common/types/platform/acpTypes.ts` 迁入），不另设计。

### 6.6 Claude Code / Codex 原生 runtime 是否应采纳 native hook → Fleet policy eval → fail-closed 模式？

**强烈同意**。docs/38 §8.4 已分析 omnigent 的 `native_policy_hook.py` 范式：拦截 `PreToolUse`/`PostToolUse`/`UserPromptSubmit` hook → 转译成统一评估请求 → Fleet 权限服务裁决 → hook `permissionDecision`/`decision:block` 落地。且必须带 fail-closed 重试预算。

当前代码中这个链路**完全不存在**。`NativeOneShotRuntimeLauncherAdapter` 的 `bridgeInjection = 'not-supported'` 意味着连 MCP 注入都没做，更不用说 hook 拦截。但这条路是让「CLI lane 的 timeline 细粒度追上 API lane」的唯一方式——不接 hook 的话，CLI 路径永远只有「开始/结束/报告」三条 timeline event，拿不到外部 CLI 每一步在做什么。

建议：RSLauncherAdapter 的 `BridgeInjection` 类型（`runtime-launcher-adapter.ts:48`）扩展一项 `'native-hook'`，区分「有 ACP 协议的 runtime 走 MCP 注入」和「只有原生 hook 的 runtime 走 hook 拦截」。

### 6.7 Fleet Portal / Daemon / physical Sandbox 是否应保持 M3 条件项？

**同意保持 M3，不进入当前实现**。AGENTS.md 规则 41、docs/01 §5 的 M3 标注、docs/04 §1a 的 D22「未拍板」状态均一致指向这个结论。docs/42 目前只有约 6 行轻量描述，无成本追踪/计费/限流细节。M3 触发条件未满足，提前展开计费细节违反 docs/30/WHITEPAPER P7 的条件触发纪律。

### 6.8 Capability Loadout 是否应排在 Bridge/Quota 之后？

**同意**。理由见 §4 的实现顺序排名。当前最重要的隔离——「CLI 的 API tool 不直接暴露给 API 队员」——已经通过 Fleet Bridge 的固定工具集清单（`team-run.ts:244-253`）在协议层做到。多项目间的 Skill/MCP/CLI 能力隔离是工程稳定性增强，在只有一个项目的场景里用户无感知。先让 Bridge 同步阻塞跑通一个端到端 smoke，再让 Quota 能给出真实的「建议走哪个 CLI」路由建议，这两个是直接决定产品能不能用的关键功能。

---

## 7. 附：当前代码-文档漂移项（需同步）

| 漂移 | 详情 | 建议 |
|---|---|---|
| `docs/38 §5.2` 原成本归因表只有三值 | 2026-07-04 已同步为六值 | 后续验证 TeamRun / RunReport / UI 是否真实写入 |
| `docs/38 §13` P3 写「同步阻塞桥」但代码无 | 文档目标态，代码 P0-P2 只做了一部分；L0/L1 `invokeAction` 已接，不等于 P3 `start_member_run` 已接 | 完成真实 CLI 注入 + blocking await + RunReport 后再更新状态表 |
| `docs/16 §2.2.5` 引用了不存在的 `MembershipProfile` | 2026-07-04 已补共享协议与 `QuotaService` registry | 继续接真实 provider adapter / RPC / UI |
| `docs/32 §2` D19 行已更新到 2026-07-03 状态 | 状态准确，无需改 | — |
| `docs/32 §1.2` P1-1 「建 QuotaAdapter 抽象」 | 2026-07-04 已更新为协议/registry 已有、provider adapter 未实现 | 继续接 membership inventory 与合法 quota adapter |
| `RuntimeLauncherAdapter` 文件头注释说「P1 skeleton · 不启动真实 CLI 进程」 | 已过时——`NativeOneShotRuntimeLauncherAdapter` 可真实启动 one-shot | 更新注释或在文件头补充状态日期 |

---

## 8. 总结

**路线正确**。`Fleet owns the team, API owns control, CLI owns a run` 的主线在协议层和基础代码层都有对应落点。当前的风险不在方向，而在实现优先级：

1. **Bridge 同步阻塞**是第一优先级——没有它，D19 最核心的「CLI 队长调 API 队员」场景是假的。
2. **TeamRunCostSource 扩展**和 **MembershipProfile 协议冻结**是低成本高收益的类型锚定——各只需几行 diff，但决定了 QuotaAdapter / Token 环 / TeamRun 路由能否写得干净。
3. **Capability Loadout**和**Fleet Portal**是明确的后续项，不抢当前 P0 资源。

建议下一步：协议锚点已补齐，Lead 集中做 Bridge 同步阻塞 smoke 闭环：选一个真实 CLI lane 注入固定 Fleet Bridge tools，跑通 `fleet.start_member_run` → API 队员执行 → 压缩 RunReport / timeout pending report 返回。

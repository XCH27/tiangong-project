# 00 · 当前执行总纲

> 状态日期：2026-07-04（文档治理收口：当前状态唯一真相改为 `docs/32`；本文只保留执行摘要）
> 当前分支：`work/fresh-base-spine`
> 口径：只把当前分支已经存在并可验证的代码算作完成。其它 worktree、旧分支和 Agent 汇报只算候选资产。
> **状态唯一真相**：模块级完成度见 `docs/32`；本文是事实摘要 + 执行优先级，不维护第二份长状态表。

## 1 · 当前代码事实

当前 `app/` 是干净的 craft-agents-oss 二开基座。已经落在当前分支的 Fleet 主干能力包括：

- `DesignAction`、`DesignPatch`、`ActorRef` 等共享协议。
- `DesignEngine` 的基础服务接口与实现。
> **2026-06-27：Wave 0 + Wave 1 已合入主线**（`work/fresh-base-spine`）：S1 内部动作注册表承重墙、S3 会话列表团队化 UI、S5 管理 Agent 全局专栏、S6 分层记忆增强（含输入建议接线）、S7 CLI native adapter、S8 `@`/`/` 输入迁移、S10 External Job 模型均已逐项核验并提交。验收口径：`typecheck:all` + `fleet-verify` 通过，相关目标单测通过；Electron 视觉/真实 CLI/真实外站仍需本机手工验收。当前已同步上游 v0.10.4；2026-07-02 已检测到 craft-agents-oss v0.10.5 待同步，状态见 `docs/32 §8.3`。

- 团队编排后端 ✅ 已落主线：team rules、TeamCoordinator、事件持久化、投递/运行分离、收件箱、Agent session 工具；**身份双写已收敛到 craft 原标签系统**（`LabelConfig` 扩展 + session labels 派生 + `setSessionLabels` 队长唯一性，见 `docs/33` §0）。
- 任务进度 Progress ✅ 已落主线：`protocol/progress.ts` + `set_session_progress` 工具 + `SessionManager.setSessionProgress` + RPC + JSONL 持久化字段 + 会话顶部 Progress 卡 + 会话行 N/M 小药丸。剩余：团队 rollup UI、本机视觉验收。见 `docs/35`。
- CLI Runtime + ACP/native 发送 ✅ 已落主线：catalog/health/RPC/协议 + `services/acp/`（JSON-RPC 客户端/runtime session/stdio transport/host，mock-transport 单测）+ Codex/Claude/Grok/Antigravity one-shot adapter + 会话级 runtime/model 选择 + JSONL 持久化 + `sendMessage` 路由 + 附件硬拒绝 + 进程清理 + 设置页（CLI 列表/Custom 表单可用）。见 `docs/23`/`docs/24`。剩余：usage/额度采样、真实 CLI smoke、Claude 等 CLI 的 reasoning flag 实机确认。
- CLI / 模型选择器 UI ✅ 已按 `docs/36` 收口：输入框底部拆为 CLI / 模型 / Token 三按钮；CLI 模式显示“模型由 CLI 管理”，不伪造模型列表；Token 环 API/CLI 诚实分级。剩余：本机 Electron 视觉验收。
- D19 API/CLI 分离与跨 Runtime 编排 🟨 最新状态只看 `docs/32` P0/P1。当前已具备：TeamRun 协议/RPC、真实 dispatcher 投递、WorkspaceFileLeaseManager 内存租约、RuntimeLauncherAdapter one-shot 诊断、`teamRun.invokeAction` L0/L1 gate、`startRunAndWaitForReport` 同步等待骨架。**仍未闭环**：真实 CLI Bridge/MCP 注入、ACP/PTY launcher、报告自动归集、permission UI、租约持久化、真实 CLI smoke。详见 `docs/38-API-CLI分离与跨Runtime团队编排.md`。
- 管理 Agent 分级自动决策 L0-L3 ✅ 已落主线：`decideAuto` 引擎 + 两个接入点（`TeamCoordinator.enforcePermission` + 中央 `requestWorkflowPermission`）+ `managerDecision` RPC + 设置页（模型配置：跟随工作区或固定 API 连接/模型/推理强度；自动决策开关/L2 规则增删）。S5 已补“所有会话”层专栏、右下角 mini 入口和退出行为设置；首次发送创建 hidden craft session，注入管理 Agent 专用系统提示词，仍走原 `onSendMessage`/permission/timeline。见 `docs/17 §4`。剩余：真正跨工作区单一全局 session、更多结构化管理动作。
- 分层记忆 ✅ 已落主线（后端 + 设置页 + 输入建议）：7 分区/4 层 + scopeId 隔离 + `memory` RPC + 独立 `MemorySettingsPage`；S6 已补全局/工作区存储拆分、TF-IDF + 3-gram 语义检索、episodic 时间衰减、turn 事实抽取、管理决策依据注入、snippet/suggestion 服务；`MemoryInputSuggestions`/`useMemoryInputSuggestions` 已在 `FreeFormInput` 接线。见 `docs/05`。剩余：向量库/更稳健抽取、归档 UI、L3 清空/导出确认。
- 前端剩余（最小 UI，需本机视觉验收，**挂点见 `docs/00A` + 下表**）：会话列表团队化 UI、`@`/`/` 输入收口、管理 Agent 专栏、CLI 三按钮、Progress 卡、Token 环、记忆输入建议条均已落主线。仍需本机视觉验收和真实 CLI/外站 smoke。
- craft 原有的 session、permission、timeline、BrowserPane/CDP、文件工具和标注能力。
- 智能模型路由 + Fusion + 分层缓存 ✅ **已落主线**（commit `362d02b1`）：`model-orchestrator`/`fusion-pipeline`/`fusion-cache`/`semantic-cache`/`session-routing-bridge` + `SessionManager.sendMessage` Auto 分支 + 设置页 + 输入框 Auto + timeline 组件（`ModelRoutingEvent`/`CacheLedgerEvent`）。**主线已实现**：mini 二段判官、语义缓存磁盘、RouteLLM 磁盘、Plan Fusion + verification hooks、cascade 文本/工具信号、偏好 accepted/retried/switched/rolled_back、git HEAD 精确缓存失效。**仍缺**：`context-shaper` 实接 rtk/codegraph（骨架已合入，sidecar 调用待接）、A2/A3 Fusion/Auto 实跑 smoke。
> 验证口径（2026-06-27）：`typecheck:all` + `fleet-verify` 在 S3/S5/S6/S7/S8/S10 合入后通过；目标单测覆盖 S1/S6/S7/S8/S10。仍需单独补本机 Electron 视觉验收、真实 CLI 登录 smoke、真实外站审查 smoke。

以下能力即使曾在其它工作树完成，也**尚未算当前分支完成**：全部文件/Library 写操作、无限画布、AIGC UI、网页/文档工作面、视频剪辑、上下文效率 UI、外部审查 UI、能力装载商城（S13）、Git 审查 UI 接线、Fleet 自有发布源。

**已提交主线（2026-06-27，commit `362d02b1`）**——以下能力已合入主线：

| 能力 | 文件 | 状态 |
|---|---|---|
| 上游软分叉同步 | `app/scripts/oss-sync.ts`、`.oss-sync-state.json` | v0.10.4 已提交；v0.10.5 (`c9d9a26`) 待同步，禁止在当前脏 worktree 上直接合并 |
| 人类交互终端 PTY | `interactive-terminal-ipc.ts`、`BottomTerminalPanel.tsx`、xterm | ✅ 已提交；待 A2 视觉验收 |
| Git 审查 | ✅ 已落主线 | `git-review-service` + RPC + `GitReviewPanel` + `GitHubSettingsPage`；已提交，待 A2 视觉 smoke |
| 工作面模块壳 / Tool Dock | ✅ 已落主线 | `CraftModulePanel` + `ResizablePanelGroup` + `workbench-layout` + `tool-dock-config`；规范见 `docs/37` §0/§6 |
| 智能模型路由 + Fusion | ✅ 已落主线 | 见 §1 路由条目；已提交 `362d02b1` |
| 本机 CLI 并行子 agent | `scripts/cli-subagents.sh` | ✅ 已提交；Claude `deepseek-v4-pro`、Grok `grok-build`/`grok-composer-2.5-fast`、Antigravity `Gemini 3.5 Flash (High)` |

迁入前必须逐项核对 diff、许可证、测试和当前架构。

## 2 · 当前最高优先级

按 `docs/32 §8` 详细计划执行。摘要：

1. **D19 Bridge 闭环**：真实 CLI Bridge/MCP 注入 → `fleet.start_member_run` blocking await → API 队员执行 → 压缩 RunReport / timeout pending report 返回。
2. **Quota provider adapter**：在已有 `MembershipProfile/QuotaSnapshot/QuotaService` 基础上接合法 provider/runtime 额度来源；无来源保持 unknown。
3. **Workbench 全矩阵视觉验收**：按 `docs/32` 和 `docs/37` 验 1/3/6/7/8/9/10 面板、Tool Dock、终端、坏 session restore。
4. **真实 CLI smoke**：Codex/Claude/Grok 等 one-shot 与 Bridge 注入分开验证；Bridge 未接前不能写成 CLI 队长可调 API 队员。
5. **能力装载/专业工作面**：只在 Bridge/Quota 主线稳定后推进 Capability Loadout 与专业工作面。

完成这条脊柱后，按 `docs/32` 继续推进创作工作面与外部任务桥。

## 3 · 产品主线

Fleet 是人类与 AI 共用的工作创作台。默认工作台与四个专业工作面共享同一套：

- 项目与本地文件；
- Library 素材层；
- Agent、身份、记忆和权限；
- session timeline、成本账本和导出记录；
- 结构化工具入口。

四个专业工作面是无限画布、AIGC 生成、网页/文档、视频剪辑。它们使用各自适合的原生文档模型和编辑引擎，不用一个万能 DOM patch 统一实现；真正统一的是 session、permission、actor、事件、工具动词和资产交接。

## 4 · 必读顺序

0. `docs/00A-UI改造红线与挂点地图.md`（改 UI / 加功能前的单页速查）
1. `AGENTS.md`
2. `docs/04-产品决策记录.md`
3. `docs/01-产品主干与落地序列.md`
4. `docs/30-架构重审与最优落地判断.md`
5. `docs/33-T-TEAM-SPINE-团队编排脊柱协议.md`
6. `docs/32-并行开发状态看板与工作令.md`
7. 与任务对应的专题文档和 craft 源码

## 5 · 完成与验收规则

- 文档中的 `✅` 只能表示当前分支已有代码或正式决策，不能表示旧工作树完成。
- Agent 交付必须提供 worktree、branch、commit、实际 diff、测试和未完成边界。
- 合入后再把 `docs/32` 状态改为完成。
- 前端页面、按钮、输入语法或工具变化必须同步 `AGENTS.md`、相关 `docs`、bundled docs、session tools 和 MCP Agent 说明。
- 不创建过程快照；使用 Git 分支和提交作为恢复点。

## 6 · 基础验证

```bash
./scripts/craft.sh run typecheck:all
git diff --check
```

功能任务还必须运行对应的目标测试；涉及 Electron 原生窗口、BrowserPane、文件权限或真实 CLI 的功能必须补本机手工验收。

---

## 7 · 文档治理与收束规则

本文只做执行总纲，不再维护套件迁移地图、每日状态或长验收账。文档收束的执行队列和当前状态统一放在 `docs/32`；入口导航统一放在 `docs/README.md`。

### 7.1 · 写什么

- **长期保留**：产品决策、架构契约、权限/timeline 边界、UI 红线、验收矩阵、源码许可规则。
- **只放 `docs/32`**：当前完成度、下一步队列、短期风险、视觉/真实 smoke 状态。
- **不进长期文档**：commit hash 流水、某次测试输出、临时 dirty tree、一次性截图结论、某个 Agent 的口头完成汇报。

### 7.2 · 合并什么

- CLI Runtime 的规格、验收、附件边界和选择器交互应收敛为一个 S7 闭环文档；`docs/23/24/25/36` 不继续并列维护实时状态。
- Workbench 布局以 `docs/00A` + `docs/00B` + `docs/37` 为边界；状态只回写 `docs/32`。
- External Job / 上下文效率 / Quota 只保留稳定协议；真实 provider、额度采样和 UI 验证状态只写 `docs/32`。
- 源码参考保留三类：清单、许可规则、取舍决策；过程性审计材料归档或 tombstone。

### 7.3 · 删除和改名纪律

- 文档编号是稳定 ID；删除或合并后保留 tombstone，不平移已有编号。
- 删前必须 `rg` 全仓引用，迁移独有内容后再删，禁止只因“看起来过期”直接删除。
- 新增文档必须先说明它承载哪条闭环；不能为未开工功能提前写目标态长文。

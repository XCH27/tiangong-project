# Design System: TRAE Work Baseline

## 1. Visual Theme & Layout Vibe (TRAE Work Baseline)
This design system is modeled directly on the high-density settings, panel splitters, and node editors seen in **TRAE Work**. The aesthetic is clean, industrial, and completely flat, focusing on structural definition via thin 1px lines instead of rounded card surfaces or colors.
* **Density:** Level 9 (Extreme high density). Tiny 8px/12px grid gutters, tight list spacing, and minimal text padding.
* **Shape Roundness:** `ROUND_NONE` (Strictly 0px sharp corners). Absolutely no border-radius on modals, inputs, sidebars, buttons, or active selection states.
* **Atmosphere:** Dual-mode layout. Settings, catalogs, and list views use a clean Light Mode surface. Coding grids and timeline monitors use a Zinc Off-Black canvas.

## 2. Color Palette & Roles

### Light Mode UI (Settings & Catalogs)
* **Background Canvas:** `#FFFFFF` — Pure white.
* **Alternate Row Background:** `#FAFAFA` — Light neutral fill for table rows or cards.
* **Structural Borders:** `#E4E4E7` (Zinc-200) — Sharp, thin 1px lines dividing sidebars, split panes, and inputs.
* **Text Primary:** `#18181B` (Zinc-900) — Deep off-black for headlines and active labels.
* **Text Secondary:** `#71717A` (Zinc-500) — Muted gray for inactive states and helper descriptions.
* **Active Accent:** `#18181B` (Solid black) or `#2563EB` (Blue indicator) — For selected menu tab lines and primary action states.

### Dark Mode Canvas (Editing Console & Node Canvas)
* **Canvas Base:** `#09090B` (Zinc-950) — Main editor grid background.
* **Node Surface:** `#18181B` (Zinc-900) — Flat card container surfaces.
* **Console Fill:** `#121214` — Monospaced terminal output boxes.
* **Border Lines:** `#27272A` (Zinc-800) — Dark borders for cards and split panels.
* **Active Status:** `#10B981` (Emerald) — Green signal for connection online / task complete.
* **Alert Status:** `#EF4444` (Red) — Warning text or broken node states.

## 3. Typography & Spacing Rules
* **UI Copy & Headings:** `Public Sans` or `Geist` — Clean, flat geometric sans-serif. Leading is compact (1.2 to 1.35).
* **Settings & Parameters:** `JetBrains Mono` — Every parameter label, coordinate offset value, code symbol, environment variable, or key sequence is set in monospace.
* **Border Borders:** Structural lines are strictly `1px solid`. Dividers must be continuous and span the entire length of their container.
* **Spacing Scale:** Spacing units must be multiples of 4px (4px, 8px, 12px, 16px). No arbitrary pixel paddings are allowed.

## 4. Specific Panel Layouts (TRAE Work Reference)
* **Settings Dialog Box:**
  * Left sidebar list of categories (General, Accounts, Prompts, Keyboard, MCP, Advanced) with light-gray hover states and solid black left-border indicator on active tab.
  * Right content panel with grid-aligned input controls and thin separator borders.
* **Skills Catalog Grid:**
  * Uniform grid items with flat light gray backgrounds (`#FAFAFA`), 1px zinc borders, and sharp square corners.
  * Compact text headers with monospace metadata badges.
* **Checklist Control Panel:**
  * Square checklist items with no rounded corners.
  * Task entries display simple strike-through status when completed.
* **Node Workflow Canvas:**
  * Solid cards connected by thin light gray Bezier curves.
  * Input sockets are tiny square pins.

## 5. Slop Control & Exclusions
* No emojis anywhere in the user interface (no decorative icons inside tabs or logs).
* No rounded corners (`border-radius: 0px` is absolute).
* No colored shadows, outer card glows, or gradient text overlays.
* No generic placeholder texts or names.

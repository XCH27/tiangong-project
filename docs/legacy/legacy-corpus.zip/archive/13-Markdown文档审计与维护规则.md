# 13 · Markdown 文档审计与维护规则（已退役）

> **Tombstone（2026-07-01）**：本文原本维护 Fleet Markdown 文档的真相分工、审计范围和状态标注规则。当前这些规则已经收束到 `docs/README.md` 的“维护规则”与 `docs/34-多Agent协同开发规范.md` 的前置门控/删除治理中，不再维护第二份规则文档。
>
> 新任务请读：
> - `docs/README.md`：文档索引、编号纪律、真相分工、状态标注。
> - `docs/34-多Agent协同开发规范.md`：动手前置门控、删除治理、契约/Mock 并行、任务交接模板、新功能准入。
>
> 原文如需查证，先用 `git log -- "docs/13-Markdown文档审计与维护规则.md"` 找到退役前提交，再用 `git show <commit>:"docs/13-Markdown文档审计与维护规则.md"` 查看。不要再把本文作为当前规则来源。

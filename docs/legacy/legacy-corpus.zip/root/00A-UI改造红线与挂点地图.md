# 00A · UI 改造红线与挂点地图（动手前必读 · 单页）
> ⚠️ **参考层**（2026-07-05 三层定形）：本文为细节/历史权威；当前路线与状态以 `docs/蓝图/INDEX-文档总地图.md` + `docs/04`（含 §1b 最新决策）+ `docs/32` 为准。

> ⚠️ **梳理指针（2026-07-04）**：界面已由 **D27 决定彻底重构**（TRAE 结构 + 统一设计系统 + 单自适应工作面 + 画布主工作面）。**前端设计以 `docs/蓝图/UI-00/UI-01/UI-02` 为唯一真相。** 本文只再用于查 Craft **原有挂点/组件位置**等仍然有效的技术事实（改哪个文件、原结构在哪），**不再作为界面布局/信息架构依据**。冲突处以蓝图为准。
>
> 状态日期：2026-06-24
> 效力：这是「改 UI / 加功能前」的唯一速查闸。它把分散在 `AGENTS.md`(规则 9/13/16/18/23/24/35/36)、`docs/18 §7`、`docs/32 §0/§5`、`docs/01 §3` 的反跑偏规则**收口成一页**。冲突时仍以 `AGENTS.md` 和 `docs/18` 原文为准，但**动手前先过这一页**。
> 为什么存在：Agent 反复在 UI 上「胡乱加东西」——新建壳层、造第二套真相、堆散按钮、做假按钮、改共享契约。下面是硬约束，不是建议。

---

## 1 · 动手前的三道闸（挂槽三问，全过才能写代码）

加任何页面 / 按钮 / 输入语法 / 工具前，先用一句话回答：

1. **挂哪个槽？** 它挂在 craft 现有的哪个 Surface 的哪个挂点（具体到 §4 的文件）？如果答案是「我得新建一个壳/页/store」——**停**，回 §3 自查，多半是错的。
2. **用哪套动作？** 人在 UI 的写操作，对应哪个**已存在**的结构化工具/动作信封 + permission？人能点、Agent 不能复现的暗状态 = 违规。
3. **怎么回？** 它怎么进 `SessionEvent`/timeline，怎么撤销/回滚？进不了 timeline 的写操作 = 不做。

三问答不齐 → 不写。答案是「新建」→ 默认错，除非命中 §5 的唯一例外。

---

## 2 · 改 UI 的唯一正确姿势

**默认界面不重做，只在 craft 原挂点改字段、增必要入口。** 保留原工作区、会话列表、聊天面板、标签、设置、BrowserPane 的设计语言与组件。需要新能力时，**先在原组件上加字段/分支**，原结构确实没有合理挂点时才新增——且只能是 §5 的四个专业工作面。

---

## 3 · 七条硬「不要」（命中任意一条就是跑偏）

1. **不新建壳。** 不造 `WorkbenchShell`、三栏 Stage/Inspector/Context、全局底部 Action Ticker、团队控制台。改原 `AppShell` / 原面板。（AGENTS 9，docs/18 §7）
2. **不造第二套真相。** 只用 craft 的 `SessionManager`/`SessionEvent`/permission/timeline；不新建第二套 conversation/session store、team store、身份 store、消息库。手动编辑写进原 `config`/`preferences`/`labels`。（AGENTS 13，docs/18 §7，docs/32 §5）
3. **不做假按钮。** 没接真实后端/原生引擎/会话路由的按钮必须 `disabled` 或明确报错，**不准显示为可用、不准谎称完成**。（AGENTS 23，docs/18 §1.5，docs/32 §5）
4. **不碰共享契约。** `protocol/{channels,routing,dto,index,team}.ts`、`transport/channel-map.ts`、`shared/types.ts`、`handlers/rpc/index.ts`、`handler-deps.ts`、`i18n/locales/*.json` 由 Lead 冻结，对并行 Agent **只读**。需要新 channel/event/type/i18n key → **回 Lead 加**，不自己改。（AGENTS 36，docs/32 §0）
5. **`@` 只找人。** `@` = 人/Agent/会话/身份；`/` = Skill/命令/模板。不保留 `@Skill` 双入口。团队群聊里无 `@` 是跟队长普通聊天，`@全体成员` 才广播，`@G-01`/`@G-02` 定向成员。（AGENTS 16，docs/32 §5）
6. **身份不双写。** 队长/代码/设计/审查等身份**只在 craft 原标签系统**（`labels/config.json` + session `labels`）表达；不在 team rules、renderer 或第二处再定义一套身份。加/取消「队长」标签就是升/降队长。（docs/18 §3.2，docs/33）
7. **不用万能 patch。** 不用一个通用 Inspector / 通用 `DesignPatch` 强行解释设计、文档、视频、代码的内部结构。各工作面用各自原生引擎。（AGENTS 14，docs/01 §2，docs/18 §7）

---

## 4 · 挂点地图：想做 X → 改这个，**别新建**

> 行=你想加的能力；列=craft 现有挂点（精确到文件）。先 `rg` 定位再改；下列文件的所有权与禁改清单以 `docs/32 §3` 为准。

| 你想做 | 改这里（craft 现有挂点） | 别做 |
|---|---|---|
| 会话列表显示模型/Runtime 图标、稳定序号、身份、团队状态 | `renderer/components/app-shell/{SessionItem,SessionList,SessionBadges,SessionInfoPopover,SessionStatusIcon}.tsx` 加显示字段；标签栏固定顺序为「模型/Runtime 图标 → 稳定编号 → 队长身份 → 其他标签」，队长必须引用 `LEADER_LABEL_ID`，不按名称或赋值顺序判断。队长会话在“所有会话”Navigator 中自动置顶到“团队群聊”分组；普通行和队长行 hover 时可显示行内“删除会话”快捷按钮，按钮必须复用原 `onDelete` 路径并渲染在主行 button 外层 overlay，避免 nested button / 选中态位移回归 | 别新建会话卡/团队会话栏组件（旧 `TeamConversationBar` 不复活）；别把 hover 删除做成第二套删除 RPC；别把按钮塞进主行 button 内部；别用改变 `lastMessageAt` 的方式伪造置顶 |
| `@` 人/Agent/身份、`/` Skill/命令/模板 | ✅ 聊天输入已先收口：`renderer/components/app-shell/input/FreeFormInput.tsx` 不再用 `@` 弹出 Skill/Source/File；`/` 菜单可插入 Skill 和 Source，内部仍生成原 `[skill:...]` / `[source:...]` 执行标记并复用原 badges/发送链路。下一步 `@` 只接团队名册/身份搜索（`components/ui/mention-menu.tsx` 可复用样式但不得再放 Skill/Source/File） | 别新建输入框/第二套 mention store，别恢复 `@Skill` 双入口 |
| 团队群聊 | 原 `ChatDisplay.tsx` + 原聊天面板 + 原会话项样式；有队长时**队长会话本身**就是群聊 transcript，在“所有会话”里只作为同一个真实 session 置顶显示，不复制第二个会话项；无 `@` 走原 Craft 发送链路跟队长聊天，`@全体成员` 广播，`@G-01` 定向成员，团队投递均由 `TeamCoordinator` 写 timeline；队长回复和队员投递都从 `TeamProjection.members[].identityLabelIds` + `labels/config.json` 派生同一条只读身份条（稳定编号 → 队长/身份标签 → 显示名）；队长身份条位于 `TurnCard` 顶部，队员身份条位于正文气泡外上方，正文仍是普通左侧消息气泡 | 别建群聊页/群聊库，别在会话列表里加输入框或维护 renderer 成员映射；别为置顶新建假 session 或 hidden UI 副本；别把队员投递包成另一套卡片头部；别在消息气泡里硬编码第二套身份 |
| 管理 Agent 入口 | ✅ `renderer/components/app-shell/ManagerAgentLauncher.tsx`，挂在 `AppShell`。只保留一个可拖动的左下角 Craft 标识小球（左栏滚动区预留底部空间，避免压住“设置/最新动态”；不占右侧 Tool Dock），渲染进单例 `#manager-agent-launcher-root`，挂载时清理旧管理 Agent 浮层；点击打开对齐原 `EditPopover` 视觉与尺寸的轻量 Agent 输入框（grip + 空态 + 底部输入框），点击外部收起。首次发送创建 hidden craft session，按 `ManagerSettingsPage` 的模型配置填 `llmConnection/model/thinkingLevel`，注入管理 Agent 专用系统提示词，发送走原 `onSendMessage`/permission/timeline。**不要占用 SessionList 顶部槽**，那里只给团队群聊。 | 别塞进某个 workspace 的普通会话，别把它做成「团队群聊」，别再加第二个圆形入口，别做特权后门绕 permission，别做未接后端的假发送 |
| 团队状态（待安排/进行中/待审查/完成/取消） | 映射到 craft 现有 session status / `SessionStatusIcon`；身份扩展原 `labels/config.json` + session `labels` | 别在团队规则或 renderer 建第二套身份/状态定义 |
| 设置项 / 手动编辑逃生舱 | `renderer/pages/settings/*`、`components/settings/*`，写进 craft `config`/`preferences` | 别另起第二套设置真相 |
| AI/API 连接配置 | `pages/settings/AiSettingsPage.tsx` 复用原 `OnboardingWizard` / `ProviderSelectStep` / `CredentialsStep` / `ApiKeyInput`。连接区直接露出 compact provider 卡片，点击进入同一套 API/OAuth/local model 流程；已有连接仍用原 `ConnectionRow` 管理、验证、编辑、删除 | 别新建第二套 API 配置页；别把 provider 选择藏成只有一行空态文字；别让按钮绕过原凭据保存/验证流程 |
| 工作区动作 / 新增 / 重命名 | `renderer/components/app-shell/{TopBar,WorkspaceSwitcher}.tsx` + `components/workspace/*` + `shared/config/storage.ts`。顶部工作区 pill 的下拉是当前工作区动作菜单：重命名、在新窗口打开、关闭工作区、删除工作区；**「添加工作区」紧跟工作区 pill 右侧**（同 pill 边框/高度，桌面宽度足够可图标+文案，窄宽仅图标+tooltip，点击打开原 `WorkspaceCreationScreen`）。关闭工作区只从软件工作区列表移除，不删除真实文件夹；删除工作区才删除磁盘 rootPath。工作区名称不靠 UI 强行汉化，默认名称从主语言取 `workspace.myWorkspace`，真实文件夹名用同一名称（保留中文等非 ASCII），重命名时同步移动 workspace 根目录并更新全局 config 与 workspace `config.json` | 别把“添加工作区”塞回工作区下拉；别把关闭写成删除文件夹；别只改显示名不改文件夹；别新增第二套 workspace store；别用 slug 强行把中文默认工作区落成 `workspace`/`my-workspace` |
| 右上角新建面板按钮 | `renderer/components/app-shell/TopBar.tsx`。Craft 原版 `+` 菜单包含“新会话进新面板”，Fleet 现阶段有意收回这个默认入口：普通“新建会话”只替换/创建当前主会话，不制造多个聊天窗口；多 Agent 观察优先走队长会话/团队群聊。右上角只保留明确的工作面入口：终端面板、浏览器面板、Tool Dock 模块菜单。 | 别恢复“新建会话进新面板”作为默认按钮或快捷 action；别用多聊天窗口替代团队群聊；别新增第二套 panel 创建入口 |
| 帮助文档入口 | `shared/menu-schema.ts` 的 `HELP_LINKS` + `renderer/components/app-menu/{DesktopAppMenu,MobileAppMenu}.tsx`。帮助链接统一放在左上 Craft 菜单 →「帮助」子菜单里，「帮助和文档」下面列数据源/技能/状态/权限/自动化/Messaging 等文档 | 别在 `TopBar` 右侧恢复 `?` 帮助按钮；别做第二套帮助下拉菜单 |
| 浏览器 / 网页标注 / 设计选择 | `renderer/components/browser/*` + BrowserPane/CDP + session timeline | 别建孤岛 Figma 克隆页 |
| CLI Runtime 的会话显示 | 当前态：普通对话 `surface='chat'` 只走 API；终端按钮或 `Cmd+J` 创建 `surface='terminal'` 的 craft session，并打开 `terminal/session/{id}` 一等 PTY 面板。终端输入/输出通过 `appendTerminalTranscript` 写回同一 craft session（输入 `user`、输出 `tool`，不触发 LLM），terminal route 聚焦时仍显示“所有会话”Navigator；terminal session 行复用 `SessionBadges` 显示 Runtime 图标 + `终端` lane badge，不新增标签真相；`TerminalPanel` 重挂载会加载同一 session 的持久化 transcript 并恢复显示，header/拖拽标签/列表新面板打开路径必须按 terminal session 处理。状态：transcript 持久化与重挂载显示 `usable`；活 PTY 进程跨页面保活、AgentSeat↔RuntimeLane 归属字段、Bridge 注入仍未闭环。`Cmd+J` 不再切换旧底部卡片，而是走同一 terminal surface 创建/聚焦路径。Runtime 标识走 `SessionBadges`/`SessionInfoPopover`；设置页“本机 CLI”负责刷新扫描全部本机 Agent CLI 并自动测试。Fleet Bridge/RuntimeLauncherAdapter/TeamRun 见 `docs/38-API-CLI分离与跨Runtime团队编排.md`。`protocol=acp` 走 stdio ACP；已接 one-shot adapter 的 CLI 可发送；未接 adapter 的只显示“已检测，待接入”。进程控制走后端 service + permission + timeline | 别在 renderer 存 CLI 进程暗状态、别另起第二套 session，别把 terminal route 用普通 ChatPage 打开，别把顶部按钮做成第二套模型中心，别把 native/subscription CLI 伪装成 ACP，别恢复 Gemini CLI 内置探测；别把旧底部卡片当成终端主入口 |
| API/模型/Runtime 厂商图标 | ✅ 已补统一管线：`ConnectionIcon`/`provider-icons.ts` 现在覆盖 Antigravity、Grok Build、xAI、Hermes、OpenCode、DeepSeek 等静态 SVG；现有 Claude/OpenAI/Google/Azure/OpenRouter/Ollama 等继续复用原资产。后续新增图标优先用 MIT 的 LobeHub Icons 静态 SVG（`@lobehub/icons-static-svg`；React 包 `@lobehub/icons` 需适配层，别直接引入破坏 React/peer deps），UIED SVG 可作为补充下载源；Groq 暂无绿灯静态资产，继续 favicon fallback | 别复制 LobeHub 软件源码或 UI 结构；别把图标资产无来源塞进仓库；别为每个页面单独做 provider 图标逻辑 |
| 上下文圆环 / Token 全览 | ✅ 当前态：Token 环是每个会话面板 `PanelHeader` 左侧的独立 `SessionUsageButton`，不占用输入栏底部空间；点开弹层按来源显示**单一视图**：API 模式顶部显示 provider/runtime 返回的当前上下文总量、当前模型窗口和占比；userDefined Pi 模型刷新会保留用户选择但补齐 provider 返回的 `contextWindow/supportsThinking` metadata；同一份模型能力也约束输入框/紧凑模型选择器的思考档位，只展示当前 API 模型或 CLI runtime 声明支持的档位，历史 `max/xhigh/high` 不可用时只能就近降到仍有推理的可用档，不能自动写成 `off`；多色条由 Fleet 本地 usage ledger 展示可复现计量的对话消息、工具结果、MCP/外部工具输出、Skill 输出、子代理输出，并用 provider 总输入扣除本地分项后的“未归因上下文”兜底；输出 token、费用、provider cache read/write 节省仍走 provider usage。系统提示、工具定义、规则等只有未来装配层能按实际 prompt part 计量后才显示，不能靠字符估算硬塞。订阅套餐模式仅显示套餐窗口（Claude 式：窗口 label+重置时间+百分比+条），不显示 API 费用字段；CLI/runtime 托管但未暴露额度时只显示“额度由运行时账号管理/未暴露”。⏳ 待办：system/tool definitions/rules 的装配级 token part、真实套餐 QuotaAdapter、runtime 原生 breakdown adapter、完整模型 variant/timeline 记录 | 别把 Token 环放回输入栏底部挤发送按钮；别要求用户输入 `/status`/`/usage`，别另建常驻 Usage 控制台，**别把上下文占用、API 账单、会员额度画成同一个口径**；别用估算的系统/工具/规则/Skill/MCP 数字填 UI 主视图；别把不支持的思考档位静默写成无思考 |
| 全部文件 / Library | ✅ raw「全部文件」只读浏览改为默认工作台**右侧上下文栏**：`renderer/components/app-shell/WorkspaceContextSidebar.tsx`，上半区显示当前会话 Progress，下半区复用 `renderer/components/files/FilesListPanel.tsx` 浏览当前工作区文件夹；隐藏/显示入口收进 `TopBar` 的 Tool Dock 分组下拉，不再和模块下拉并排重复成两个按钮。右栏可拖拽调整宽度、双击恢复默认，宽度持久化；桌面宽度足够且满足当前内容 grid 最小可读宽度时作为停靠工作台列；空间不足时右栏不 dock，绝不 overlay 到内容上，也不自动收缩/折叠左全局 sidebar 或“所有会话”Navigator。仅 mobile compact、focus mode 或用户主动隐藏时收起；右栏缩到窄宽度时折叠文件搜索和 Progress 备注/活动态。后端复用文件 RPC 并新增只读 `fs:listEntries`；点可预览文件在 Tool Dock 内联文稿预览（`ToolDockDocumentPreview`），全屏仍走 `onOpenFile` overlay；不可预览类型直接外部打开。⏳ 未落：用户额外素材目录、类型过滤、缩略图、拖入专业工作面、Library 资产层、文件整理写操作（这些必须先接 permission + timeline） | 别在左栏增加「全部文件」按钮；别再做右侧孤立浮动圆按钮；别让右栏强行抢占内容面板最小宽度；别和「本地知识库」数据源混成一个概念；别给 raw view 加未授权的移动/删除/重命名假按钮 |
| 管理 Agent 设置（模型/决策） | ✅ 已落：`pages/settings/ManagerSettingsPage.tsx`（craft 设置骨架），真接 `managerDecision` RPC。模型配置写入管理 Agent 设置（跟随工作区默认 / 固定 API 连接+模型+推理强度）；自动决策开关+L2 规则增删。CLI Runtime 暂不作为管理 Agent 模型，需 native adapter 后再开放 | 别把记忆塞进管理 Agent 页面；别另做治理控制台；常驻悬浮入口走上面「管理 Agent 入口」行 |
| 记忆模块 | ✅ 已落：`pages/settings/MemorySettingsPage.tsx`（craft 设置骨架），真接 `memory` RPC。按 user/software/project/agent/task/design_asset/external_review 分区查看、添加、删除；scoped 分区按 scopeId 隔离。Agent 结构化工具 `list_memory` / `add_memory` / `delete_memory` 已接同一个 `MemoryStore`。入口是设置里的「记忆」，不是管理 Agent 页的附属区 | 别和管理 Agent 自动决策混成一个页面；别建第二套 memory store；别做没有 scope 隔离的项目记忆 |
| Progress 进度卡 | ✅ 已落：会话 `progress` 非空时在右侧上下文栏顶部渲染 `SessionProgressCard`（✓/spinner/○/删除线 + N/M + 进度条 + 活动态），和下方当前文件夹文件列表同栏；数据走 `progress_updated` 事件 → `session.progress`（dto.ts + event-processor，重载经 `managedToSession` 仍在）。✅ 会话行 `SessionItem` 的 N/M 小药丸也已落（commit `f36b9340`，`SessionMeta.progress` + `summarizeProgress`） | 别把 Progress 卡塞回聊天正文顶部；别新建 Progress 页/store；未真正驱动的步骤别显示为 in_progress/completed |
| Workbench 布局 / Tool Dock | `AppShell.tsx` + `PanelStackContainer.tsx` + `WorkspaceContextSidebar.tsx` + `panel-constants.ts` + `workbench-layout.ts`。壳层/阴影/分屏规范见 **`docs/37` §0/§6**（Craft 原生栈；Tool Dock chrome 统一 `CraftModulePanel`；多模块 flex-col + `ModuleResizeSash`；`terminal/session/{id}` 当前是一等内容面板；旧底部 Terminal 卡片不再从默认工作台渲染）。Tool Dock 模块：`progress/files/review`；Terminal 不进 Tool Dock；内容面板最多同时挂载 9 个；7/8/9 固定 3×3 grid，10+ 只移出较早可见面板、不删除 session；普通新建会话不再新增内容面板，团队/多 Agent 观察走团队群聊；compact 返回按钮只回到当前 navigator/list route，不删除 panel/session；2026-07-03 CDP 已验证内容面板顶部胶囊重排可改变 DOM 顺序，2 面板 grid resize sash 可调比例，Tool Dock 拖拽期间模块高度和 `transform` 不变；ready 后不保留 `z-splash` 全屏遮罩在工作台上方；面板数量不得触发左全局 sidebar、Navigator 或右 Tool Dock 的自动收缩/互斥；工作区四边统一使用 `PANEL_EDGE_INSET`，sidebar↔Navigator / Navigator↔内容 / 内容↔Tool Dock / Tool Dock 模块 seam 统一使用 `PANEL_GAP`，不得按某一条边单独补负 margin 或 padding；Tool Dock 只在当前宽度能满足固定左列 + 内容 grid + 右栏时 dock，否则不渲染为停靠列，不能挤压或覆盖内容面板 | 别在 AppShell 外再包 gutter wrapper；无 terminal 时别让内容列多一层 `overflow-auto`；别复活 `WorkbenchModuleFrame` 第三套 chrome；别为对齐改 Navigator shadow 拆层；别把旧底部卡片恢复成终端主入口；别为了腾空间写入 `setIsSidebarVisible(false)`；别自动隐藏或压缩 Navigator；别把左栏显示和右栏显示做成互斥；别恢复普通新建会话进新面板；别把 compact 返回做成 close panel；别让启动/热更新遮罩盖住 ready 工作台 |
| 主导航页面切换 | `NavigationContext.navigate(..., { replaceStack: true })` + `AppShell` 左侧主导航 handlers。左侧主导航（所有会话/状态/标签/数据源/技能/自动化/设置）是工作区级页面切换，必须替换整个 main panel stack；会话详情、source/skill/automation 详情等页面内部 drill-in 才更新当前 panel。普通新建会话只创建/进入当前主会话；终端、浏览器等明确工作面入口才可用 `newPanel` 增加内容面板 | 别让点击“数据源/设置/技能”等主导航只替换当前 focused 对话框；别把主页面塞进多对话框 grid 的某一格；别用隐藏旧面板伪装页面切换；别用普通新建会话制造多聊天窗口 |
| 团队群聊 | ✅ 已落：队长会话复用为 `teamConversationSessionId`。无 `@` 的直接聊天保留原 Craft 发送链路，等同跟队长聊天；`@全体成员` 才走 `sendTeamMessage(audienceAll)` 广播；`@G-编号` 定向成员，后端解析并写原 session timeline。收到 `team_*` 事件后刷新原 transcript。队长 `TurnCard` 回复和 Agent 团队消息都复用同一条只读身份标签栏。旧 hidden conversation 仅在无队长时作内部 fallback，不显示重复入口。 | 别建群聊页/群聊库，别在会话列表里加输入框或再造群消息库 |

---

## 5 · 唯一允许「新建独立页面」的情况

只有四个**专业工作面**可以有自己的整页布局和原生引擎，且仍必须接真实 craft session/permission/timeline、共用工作区/全部文件/Library/Agent/记忆/账本：

1. 无限画布　2. AIGC 生成　3. 网页/文档　4. 视频剪辑

除此之外（团队、CLI、管理 Agent、设置、记忆、审查、上下文）**一律在原界面增量改**，不新建壳。

---

## 6 · 提交前自检（缺一条不算完成）

- [ ] 三道闸（§1）都答齐了，且不是靠「新建壳/页/store」。
- [ ] 没命中 §3 任意一条硬「不要」。
- [ ] 改的文件在我名下（`docs/32 §3`），没碰共享契约和别人的禁改清单。
- [ ] 没有假按钮：未接后端的写操作 `disabled` 或明确报错。
- [ ] 人能做的写操作，Agent 有等价结构化工具；都过 permission、进 timeline、可回滚。
- [ ] 页面/按钮/输入语法/工具的变化，已按 AGENTS 规则 35 同步 `AGENTS.md`、相关 docs、bundled docs、tool schema/handlers、MCP 说明。
- [ ] `git diff --check` + `./scripts/craft.sh run typecheck:all` 通过；改了什么按 `docs/32 §6` 格式汇报。

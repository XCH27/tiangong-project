# 44 · 三通道 Skill 注入与编排协作模型

> **参考层**（挂接 2026-07-06 首次写入）：本文为 Apex Omni Review Skill 在三种连接通道下的注入策略与编排配合规范，是 `docs/38`（API/CLI 分离）、`docs/17`（双层 Agent）、`docs/43`（能力装载）的交汇补丁。
> 路线与状态以 `docs/蓝图/INDEX-文档总地图.md` + `docs/蓝图/04-团队编排与TeamRun闭环.md` 为准。

---

## 0 · 问题起点

我们的平台有三种接入方式：

1. **订阅会员**（Subscription）—— 在 Fleet GUI 内通过 API 直连使用
2. **API** —— 开发者 BYOK，API 接入 Fleet 平台
3. **CLI**（Claude Code、Cursor、Codex、agy 等）—— 本地命令行 harness，由用户自订阅

**痛点**：Apex Omni Review Skill 包含了大量多智能体编排提示词（Captain / Reviewer / Executor 队列、审查矩阵、TokenBudget 控制等）。这些内容对订阅会员是有价值的，但对 CLI 用户来说是严重冲突：CLI 宿主已有自己成熟的控制环（如 Claude Code 的 `todo_write` / `TaskCreate`，Cursor 的 `SwitchMode` / `TodoWrite`），再注入我们的编排提示词会造成：

- 双重控制环叠加（Agent Inception）
- 工具名称冲突（两套 todo/task 工具）
- 审查与执行角色分裂（宿主有自己的角色模型）
- Token 膨胀（两套 meta-review 规则在上下文里共存）

---

## 1 · 核心口号（与蓝图 00 §1.3 对齐）

> **Fleet 的 Skill 只给 Fleet 控制的 Lane 注入。CLI 的 harness 自治，Fleet 不替代。**

Apex Skill 是 Fleet 的内部智能质控工具。它只在 Fleet **拥有控制权**的 RuntimeLane 里发挥作用。在 CLI Lane，由宿主的 harness 自行管理控制环，Apex Skill 收敛为只读约定层（规范 + 代码质量纲领），不注入编排控制。

---

## 2 · 三通道画像定义

下表与 `docs/38 §3`（Surface 分离）和 `docs/43 §3`（CapabilityLoadout 分层 scope）完全对齐：

| 通道画像 | Surface | RuntimeLane | 接入者 | Apex Skill 注入策略 | 编排控制权归属 |
|---|---|---|---|---|---|
| **`CLI-PASSTHROUGH`** | `surface='terminal'` | CLI harness（Claude Code / Cursor / Codex / agy 等） | 本机 CLI 用户 | **最小化**：只注入代码规范 + 质量纲领；屏蔽 Captain/Reviewer/Executor 拓扑规则；屏蔽 meta-review 矩阵和 TokenBudget 调度 | **CLI 宿主自治**（不经 Fleet Bridge） |
| **`MEMBER-CRAFT-ORIGINAL`** | `surface='chat'` | API control lane | 订阅会员（轻量） | **标准层**：注入 Craft Agents 原版 Solo/Pair 控制逻辑；单智能体 + 轻量自检；无审查矩阵 | **Fleet API 控制**（API lane） |
| **`MEMBER-APEX-SUPER`** | `surface='chat'` | API control lane + 可选 CLI harness lane（经 Bridge） | 订阅会员（超级版） | **完整层**：注入 Apex 全套编排规则（Captain / Executor / Review Orchestrator 拓扑；Planning-Execution 分离；3-Strike Linter；ReviewMatrix；TokenBudget；HandoffGuardrail） | **Fleet 双层 Agent**（管理 Agent + TeamRun 受控） |

---

## 3 · 三通道的 CapabilityLoadout 配置（对接 `docs/43`）

按 `docs/43 §3` 的四层 scope 模型，在 identity/session scope 层注入：

### 3.1 `CLI-PASSTHROUGH` Loadout

```yaml
scope: { level: 'session', refId: 'cli-passthrough' }
enabled:
  - capabilityId: 'skill:apex/code-conventions'     # 代码规范纲领（只读）
    permissionProfile: L0
  - capabilityId: 'skill:apex/quality-checklist'    # 轻量质量清单（只读）
    permissionProfile: L0
quarantine:
  - 'skill:apex/team-orchestration-loop'            # 禁止注入多智能体控制环
  - 'skill:apex/conduct-governance'                 # 禁止注入审查行为矩阵
  - 'skill:apex/handoff-guardrail'                  # 禁止注入移交守卫规则
  - 'skill:apex/coordination-governance'            # 禁止注入协调治理规则
  - 'skill:apex/capability-profile'                 # 禁止注入能力画像编排
basis: 'CLI 宿主已有自己的控制环，注入编排 Skill 会导致双重控制环冲突'
```

### 3.2 `MEMBER-CRAFT-ORIGINAL` Loadout

```yaml
scope: { level: 'identity', refId: 'member-craft-original' }
enabled:
  - capabilityId: 'skill:apex/code-conventions'     # 代码规范纲领
    permissionProfile: L0
  - capabilityId: 'skill:apex/quality-checklist'    # 质量清单
    permissionProfile: L1
  - capabilityId: 'skill:apex/capability-profile'   # 能力画像（单体）
    permissionProfile: L1
optional:
  - 'skill:apex/conduct-governance'                 # 可按需加载（用户触发 Heavy Audit）
quarantine:
  - 'skill:apex/team-orchestration-loop'            # 原版 Craft 无多智能体编排
  - 'skill:apex/coordination-governance'
  - 'skill:apex/handoff-guardrail'
basis: 'Craft Agents 原版 Solo/Pair 模式，无多智能体队列'
```

### 3.3 `MEMBER-APEX-SUPER` Loadout

```yaml
scope: { level: 'identity', refId: 'member-apex-super' }
enabled:
  - capabilityId: 'skill:apex/code-conventions'
    permissionProfile: L0
  - capabilityId: 'skill:apex/quality-checklist'
    permissionProfile: L1
  - capabilityId: 'skill:apex/team-orchestration-loop'
    permissionProfile: L2
  - capabilityId: 'skill:apex/conduct-governance'
    permissionProfile: L2
  - capabilityId: 'skill:apex/coordination-governance'
    permissionProfile: L2
  - capabilityId: 'skill:apex/handoff-guardrail'
    permissionProfile: L2
  - capabilityId: 'skill:apex/capability-profile'
    permissionProfile: L2
basis: 'Apex 超级版完整编排能力，通过 Fleet 双层 Agent + TeamRun 受控'
```

---

## 4 · 编排形式配合矩阵（核心问题）

这是三通道最容易产生理解混淆的地方，需要一次性厘清。

### 4.1 「编排控制权」归谁

| 情形 | 谁发出任务指令 | 谁持有控制环 | 谁拥有 timeline | 审查/质控在哪里发生 |
|---|---|---|---|---|
| CLI 单人模式 | CLI 用户 | **CLI 宿主**（Claude Code / Cursor 自带 loop） | CLI 本地（有 Bridge 才回 Fleet） | CLI 宿主自带 linter/test；Apex Skill 只提供离线纲领 |
| CLI 队长 + API 队员（经 Bridge） | CLI 队长经 `fleet.start_member_run` | **Fleet TeamRun**（`docs/38 §4`）| Fleet timeline（带 attributionChain） | API 队员在自己的 session 里执行；Apex `MEMBER-APEX-SUPER` 规则注入 API 队员 |
| Subscription Solo（Craft Original） | 订阅会员 API 直连 | **Fleet API lane**（单体 Session） | Fleet craft session | Apex `MEMBER-CRAFT-ORIGINAL` 规则注入，本地顺序审查 |
| Subscription Team（Apex Super） | 订阅会员 → 管理 Agent → TeamRun | **Fleet 双层 Agent**（管理 Agent + Captain/Executor）| Fleet craft session + TeamRun | Apex `MEMBER-APEX-SUPER` 完整注入；Planning-Execution 分离；Review Orchestrator 本地汇总 |

### 4.2 CLI 队长 + API 队员的关键规则

当 CLI 用户作为队长，经 Fleet Bridge 调用 API 队员时（`docs/38 §4` 受控 TeamRun 模式）：

**CLI 侧（队长 · CLI-PASSTHROUGH）**：
- 队长的 CLI 宿主控制环不受干扰——Apex Skill 不注入队长的 CLI context
- 队长只看到 8 个固定 `fleet_*` 工具（`docs/38 §4.1`）
- 队长经 `fleet.start_member_run` 发起 TeamRun，同步阻塞等待 `RunReport`

**API 侧（队员 · MEMBER-APEX-SUPER）**：
- API 队员在自己的 Fleet session 里执行
- **此时 API 队员的 Loadout = `MEMBER-APEX-SUPER`**，Apex 编排规则完整注入
- 队员执行时遵守：Planning-Execution 分离、Read-Before-Edit、3-Strike Linter
- 队员完成后回压缩 `RunReport`（不回完整会话，不回完整 diff）

**管理 Agent（永远 API cheap lane）**：
- 负责 TeamRun 的权限、loadout、成本账本（`docs/17 §2`）
- 不注入任何 CLI 规则；永不走 CLI（规则 41）

### 4.3 「审查子智能体」的通道边界

这是最容易产生 Token 浪费的地方（用户原始痛点）：

| 情形 | 是否允许并行审查子智能体 | 规则 |
|---|---|---|
| `CLI-PASSTHROUGH` | **禁止** | CLI 宿主控制环不受 Fleet 控制，注入子智能体会造成双重 loop |
| `MEMBER-CRAFT-ORIGINAL` | **禁止**（日常）| Solo/Pair 模式无队列；本地顺序审查 |
| `MEMBER-APEX-SUPER` · T1/T2 审计 | **禁止** | 轻量/标准审计由 Review Orchestrator 本地顺序/并发运行各 lens |
| `MEMBER-APEX-SUPER` · T3 Heavy 审计（大型 repo，明确批准 Token 预算后） | **允许** | 仅此情形可并行专项审查子智能体 |

---

## 5 · 通道检测与自动路由

### 5.1 CLI 通道检测（`CLI-PASSTHROUGH` 自动激活条件）

检测到以下任一特征即判为 `CLI-PASSTHROUGH`，不注入编排 Skill：

```
- 环境变量：CLAUDE_CODE=1 / CURSOR_AGENT=1 / CODEX_EXEC=1 / AGY_CLI=1
- 工作区目录存在 .claude/ 或 .cursor/ 或 .codex/
- RuntimeLane.launchMode = 'stdio-acp' | 'one-shot' | 'pty'（见 docs/38 §8.1）
- surface = 'terminal'（docs/38 §3）
- BridgeInjection 状态 = 'BRIDGE_UNAVAILABLE'（无 Bridge 时也走 passthrough）
```

### 5.2 会员通道框架选择

在 `surface='chat'`（API / 订阅会员）场景，通道画像由**用户主动切换**，非自动推断：

```
默认值：MEMBER-CRAFT-ORIGINAL（轻量、低成本、快响应）
用户切换：Fleet GUI 设置页 → 「AI 框架」→ 「Apex 超级版」→ MEMBER-APEX-SUPER
API header：X-Framework-Preference: craft-original | apex-super
```

---

## 6 · Apex Skill 文件在三通道的加载规则

| Skill 文件 | CLI-PASSTHROUGH | MEMBER-CRAFT-ORIGINAL | MEMBER-APEX-SUPER |
|---|---|---|---|
| `SKILL.md`（核心分发器） | 只读§1-§3（规范层）；跳过多智能体 Dispatch 节 | 读§1-§5；Dispatch 限 Solo/Pair | 全读 |
| `references/conduct-governance.md` | ❌ 不加载 | ✅（作为可选 Heavy Audit 时加载） | ✅ |
| `references/coordination-governance.md` | ❌ 不加载 | ❌ 不加载 | ✅ |
| `references/team-orchestration-loop.md` | ❌ 不加载 | ❌ 不加载 | ✅ |
| `references/handoff-guardrail.md` | ❌ 不加载 | ❌ 不加载 | ✅ |
| `references/capability-profile.md` | ❌ 不加载 | ✅（单体 profile） | ✅（全画像） |
| `references/reviewer-prompts.md` | ❌ 不加载 | ❌ 不加载 | ✅ |

---

## 7 · 混合编排场景下的冲突防范

### 7.1 最危险场景：CLI 队长 + Apex Super API 队员共用 workspace

风险：CLI 宿主和 Apex Super 各自都会在 workspace 里写文件，互不知情。

**防范机制（对接 `docs/38 §7` + `蓝图 05` WorkspaceFileLeaseManager）**：
- API 队员写文件前必须向 Fleet `WorkspaceFileLeaseManager` 声明写目标（`writeTargets`）
- CLI 队长占用 workspace 时，Fleet 给其 `workspace:*` 粗粒度租约
- 冲突时 API 队员进入 `blocked_waiting_for_lease` 状态，不并发踩文件
- CLI 队长完成后释放租约，API 队员继续

### 7.2 「二次注入」风险：Apex Skill 规则出现在 CLI 的 system prompt 里

如果 Fleet 错误地把 `MEMBER-APEX-SUPER` 规则注入了 CLI 宿主（如通过 `.claude/CLAUDE.md` 或 Cursor Rules），CLI 宿主会尝试理解和执行这些规则，与自身控制环产生冲突。

**防范机制**：
- Fleet 的 Skill 注入只通过 Fleet 自己的 `SessionManager` + `CapabilityLoadoutService` 完成
- 不向 CLI 的配置文件（`.claude/CLAUDE.md`、`.cursor/rules`、`AGENTS.md`）写 Apex 编排规则
- `RuntimeLauncherAdapter` 注入的内容只有 `fleet_*` Bridge 工具描述，不含 Apex Skill 规则（见 `docs/38 §8.3`）

### 7.3 「并行审查」混乱：两种接入方式同时触发审查

如果同一个 workspace 既有 CLI 队长在跑，又有 Subscription 用户在 Fleet GUI 发审查请求：

**处理规则**：
- WorkspaceFileLeaseManager 保障写互斥，两个 run 不并发写同一文件
- 审查结果归集到 Fleet timeline，不在 CLI 端单独维护第二份审查日志
- CLI 侧只看到 `fleet.get_run_report` 的压缩报告，不看 Fleet GUI 的完整审查矩阵

---

## 8 · 与现有文档的关系

| 文档 | 本文依赖关系 |
|---|---|
| `docs/38-API-CLI分离与跨Runtime团队编排.md` | 本文的 Surface 分离（§3）、TeamRun 受控模式（§4.2）、RuntimeLauncherAdapter（§5.1 检测）直接继承自该文档 |
| `docs/17-Agent协作与管理Agent模型.md` | 本文的「管理 Agent 永不走 CLI」、「双层 Agent 编排」继承自该文档 §2 |
| `docs/43-能力装载与插件技能商城.md` | 本文的 CapabilityLoadout 配置（§3）直接使用该文档定义的三平面模型和 scope 体系 |
| `docs/蓝图/04-团队编排与TeamRun闭环.md` | 本文的编排配合矩阵（§4）是该蓝图的 Skill 注入侧补充，不替代该蓝图的技术规格 |
| `docs/蓝图/08-能力装载与插件商城闭环.md` | 本文的 Loadout 配置是该闭环的 Skill-specific 实例 |
| `apex-omni-review-FINAL.skill` | 本文定义了该 Skill 在三通道下的加载规则（§6），Skill 自身不重复定义通道检测逻辑 |

---

## 9 · 反模式

| 禁止 | 正确做法 |
|---|---|
| 在 CLI 配置文件（`.claude/CLAUDE.md` 等）里写 Apex 编排规则 | 只通过 Fleet `CapabilityLoadoutService` 注入；不碰 CLI 配置文件 |
| CLI-PASSTHROUGH 下仍然调用 Apex Skill 的 Captain/Executor 拓扑规则 | 检测到 CLI surface 后立即把编排 Skill 标 `QUARANTINE` |
| 让 API 队员把完整 Apex 审查矩阵结果塞回 CLI 队长的 context | RunReport 只回压缩摘要 + evidenceRefs；完整矩阵留在 Fleet session 抽屉 |
| 在 MEMBER-CRAFT-ORIGINAL 里强制触发并行审查子智能体 | Solo/Pair 下 Review Orchestrator 本地顺序审查，无子智能体 |
| 不区分通道，把 Apex Skill 全量注入所有 session | 按 Loadout scope 精确控制，CLI 只注入规范层 |
| CLI 队长和 API 队员并发写同一文件 | WorkspaceFileLeaseManager 先拿租约，冲突进 `blocked_waiting_for_lease` |

# 23 · CLI Runtime 重做规格
> ⚠️ **参考层**（2026-07-05 三层定形）：本文为细节/历史权威；当前路线与状态以 `docs/蓝图/INDEX-文档总地图.md` + `docs/04`（含 §1b 最新决策）+ `docs/32` 为准。

> 状态日期：2026-06-24
> 当前 `app/` 已重置为干净 craft-agents-oss 基座。本文只保留上一轮验证出的产品规格和实现边界，不再把旧代码视为当前实现。
> **2026-06-23 进度：后端基座 + 输入框三按钮选择器 ✅ 已落主线**。
> **2026-06-24 更新**：刷新会扫描常见本机 Agent CLI（Goose/Claude Code/Codex/Grok/Hermes/OpenCode/Antigravity/Qwen/Pi/Cursor Agent/OpenClaw），并自动测试。`protocol='acp'`（Goose/Hermes/OpenCode/Custom ACP）走 stdio ACP；Codex/Claude Code/Grok/Antigravity(`agy`) 走官方 one-shot CLI adapter，进入聊天 runtime picker 并可发送；Qwen/OpenClaw 等未接发送 adapter 的 runtime 才标记 `needs_adapter`。Gemini CLI 不再作为内置本机 runtime 探测项；Google 路线以后按 Antigravity `agy`。
> **已完成**：catalog/health/RPC/协议（同上批）+ **ACP 发送链路**：`services/acp/`（`AcpConnection` JSON-RPC ndjson、`AcpRuntimeSession` initialize/new/prompt/stream/permission/cancel、stdio transport、`CliRuntimeHost` 进程复用与清理，均有 mock-transport 单测）+ 会话级 runtime/model 选择（`cliRuntimeId`、`cliRuntimeModelId`、`setCliRuntime`、`setCliRuntimeModel`、`cli_runtime_changed`、`cli_runtime_models_changed`）+ `sendMessage` 路由（`runCliRuntimeTurn` 复用 craft text_delta/text_complete/complete）+ 附件硬拒绝 + 进程清理（cancel/delete/cleanup）+ 输入框三按钮（CLI / 模型 / Token 环）+ 设置页本机 CLI 列表/自动测试 + **Custom runtime 新增/编辑/删除表单**。2026-07-03 补：`cli-runtimes.json` 解析失败时仍可读取 detected 候选，但所有写操作会拒绝并保留原文件，避免把损坏配置静默覆盖为空配置。
> **未完成（下一步）**：Qwen/OpenClaw 等 native/subscription adapter、Custom runtime 高级校验、usage/额度采样适配器；Codex/Claude/Grok/Antigravity/Pi/Cursor Agent 当前是 one-shot adapter，尚未做完整会话恢复/逐工具权限细分。验收以 `docs/24 §0` 为准。
> **2026-06-27 D19 迁移说明**：输入框 CLI picker 是当前已落路径；目标态会迁到 `surface='terminal'` 的一等终端面板，普通对话只走 API。
> **2026-07-03 迁移状态**：上述目标态已部分落地（`f1279789`/`145fb5e2`/`6e36071f`，2026-06-28）——聊天 `surface='chat'` 已隐藏 CLI picker，`surface='terminal'` 一等终端面板已存在。2026-07-03 又补了 `WorkspaceFileLeaseManager` 内存基础服务（TTL + read/write/git_write 冲突 + 单测），以及 `TeamRunCoordinator.startRun` → 目标 seat craft session `SessionManager.sendMessage` 的真实投递基础；无 dispatcher 或投递失败会 failed，不再假 running；`teamRun.sendMessage` RPC 已按 target seat 投递真实 session；`TeamRun.workspaceFileLeases` 已接租约，声明写入范围冲突会进入 `blocked_waiting_for_lease` 并阻止 dispatch；`RuntimeLauncherAdapter` 新增 native/subscription one-shot adapter，`testCliRuntime` 可返回 launcher 的 binary/version/bridgeStatus 诊断，并能真实启动 one-shot 进程返回 pid/startedAt/stderrTail。仍未完成：Bridge/MCP 注入、ACP/PTY launcher、Bridge 同步阻塞、`teamRun.invokeAction`、permission UI、租约持久化和报告归集。详见 `docs/32 §2`「D19」行与 `docs/38-API-CLI分离与跨Runtime团队编排.md`。

## 目标

CLI Runtime Host 是新基座的第一批重做能力：让用户在同一个 craft session 里选择本机 CLI/ACP runtime 发送消息，并把输出、权限、错误、停止、诊断全部写回现有 timeline。

它不是第二套聊天系统，也不是独立终端页。它必须接 craft 现有 `SessionManager`、permission、RPC、renderer event flow 和配置系统。

## 第一版必须支持

- **Custom ACP runtime**：用户可配置 `command/args/env`，用于接入任意本机 ACP stdio runtime。
- **Detected scan**：刷新扫描常见本机 Agent CLI，且只在本机 PATH 上检测到命令后出现在设置页。
  - ACP：Goose `goose acp`、Hermes `hermes acp`、OpenCode `opencode acp`、Custom ACP runtime。可直接进入聊天 runtime picker。
  - Native/subscription one-shot：Codex `codex exec`、Claude Code `claude -p`、Grok `grok --single`、Antigravity `agy --print`、Pi `pi -p`、Cursor Agent `cursor-agent --print`。可进入聊天 runtime picker，发送前走 craft permission，输出写回 timeline。
  - 未接 adapter：Qwen/OpenClaw 等。只显示“已检测，待 adapter”，不显示启用开关，不进入聊天 runtime picker。
- **模型信息**：ACP 模型以 runtime 握手为准；native/subscription 可显示已知静态模型提示（如 Codex/Grok），但不代表已可发送。
- **健康测试分级**：`available`、`fail_cli`、`fail_acp`、`needs_adapter`、`disabled`，并保留阶段、原因、stdout/stderr tail。
- **设置页边界**：
  - managed runtime 不可删除、禁用或改启动参数。
  - detected runtime 不可改 command/args/env，但可测试、禁用、删除。
  - custom runtime 可完整编辑。
  - `cli-runtimes.json` 损坏时，列表只展示可重建的 detected 候选；新增/编辑/启停/删除等写操作必须拒绝并提示用户修复配置，不得写回空 store。
- **发送契约**：
  - 未选择 CLI 时继续走 API 模型路径。
  - 已选择 CLI 时，ACP 走 stdio adapter；已支持的 native/subscription 走 one-shot adapter。
  - runtime 和 model 分离：`cliRuntimeId` 只表示使用哪个本机 CLI；`cliRuntimeModelId` 表示该 CLI 当前 ACP session 内的模型选择。
  - 模型清单优先来自 ACP `session/new` 返回的 `configOptions` / `models`，Fleet 不按模型名猜测。
  - 切换模型优先用 `session/set_config_option`，兼容降级用 `session/set_model`；runtime 不暴露模型时显示“模型由 CLI 管理”，不伪造列表。
  - 思考强度使用全局 `ThinkingLevel`，再按 runtime 能力裁剪：Claude/Grok 支持 `low`–`max`，Pi 支持 `off`–`xhigh`，Codex/Antigravity/Cursor/ACP 不伪造不支持的思考参数。
- **聊天入口**：
  - 不新建 CLI 专用聊天页；输入框底部使用三个独立按钮：CLI / 模型 / Token 环（见 `docs/36`）。
  - 不在顶部栏保留第二个 CLI 选择器；运行方式只在输入框 CLI 按钮切换。
  - 选择 API 模型时自动退出 CLI runtime；选择 CLI Runtime 后，本轮和后续发送走该 runtime。
  - UI 必须中文显示：`本机 CLI`、`API 模型`、`CLI 模型`、`模型由 CLI 管理`。
- **附件第一版硬拒绝**：选择 CLI Runtime 后，任何附件都拒绝，提示移除附件或切回 API 模型。
- **进程清理**：停止、错误、窗口关闭、session 结束都要清理子进程。

## 参考实现边界

优先看这些来源，但不要直接照搬旧 app 代码：

- craft-agents-oss：session、permission、RPC、renderer event flow。
- AionUi（绿灯）：ACP/custom agent、进程生命周期、team/skill 注入模式。
- open-design（绿灯）：runtime definitions、prompt transport、stream parser 思路。
- AionUi（绿灯）：采用 `agent kind/protocol + ACP model info` 的分层做法；能读到模型就展示，不能读到不伪造。
- Multica（黑盒参考）：采用 daemon/PATH 扫描多 CLI 的方向；Fleet 吸收“刷新即扫描全部本机 Agent CLI”，但不迁第二套 daemon/session。
- Hermes（黑盒参考）：Codex/Grok/provider 走 runtime switch / provider plugin / gateway 思路；Fleet 当前已接 Hermes/OpenCode ACP 和 Codex/Claude/Grok/Antigravity/Pi/Cursor Agent one-shot adapter，后续补完整 session/native 协议。
- OpenClaw（黑盒参考）：只采用其本机 CLI、managed profile、loopback gateway、profile/session-key 隔离等行为思路；OpenClaw 不是会员/订阅来源，当前 Fleet 仅检测诊断，不作为已接发送 adapter；不复制源码、不接管 Gateway、不自动安装插件/Skill，不绕过用户已有订阅/登录态。
- Goose / Hermes / OpenCode / Custom ACP：按 stdio ACP 做 opt-in 实机验证；Codex/Claude/Grok/Antigravity/Pi/Cursor Agent 走 one-shot native/subscription adapter；Qwen/OpenClaw 等继续待 adapter。
- Provider 图标：`ConnectionIcon`/`provider-icons.ts` 已统一覆盖 Antigravity、Grok Build、xAI、Hermes、OpenCode、DeepSeek 等静态 SVG；Groq 暂无绿灯静态资产，继续 favicon fallback。LobeHub Icons 的 npm 包为 MIT，覆盖大量 AI/LLM 品牌；后续新增优先用 `@lobehub/icons-static-svg` 接现有 `<img src>` 管线，React 包 `@lobehub/icons` 需先做适配层，UIED SVG 作为补充来源。

## 对标结论（2026-06-23）

- **AionUi / Multica**：更偏“检测并管理外部 agent/CLI”，优点是启动、健康检查和 team 入口清楚；Fleet 吸收其进程生命周期和可观测性，但不迁第二套会话。
- **Warp / Zed / Cursor / Claude / Codex**：更偏自身运行时或编辑器内置 agent，模型和用量展示贴近各自产品；Fleet 不能照搬其 UI 壳，应复用 Craft 原顶部栏、输入框模型选择器、permission 和 timeline。
- **OpenCode**：动态模型/档位适配值得参考；Fleet 的实现原则是 ACP runtime 握手优先，能拿到 runtime 模型清单就显示，拿不到就明确“模型由 CLI 管理”。
- **Fleet 的更优点**：API 与 CLI 是同一个 craft session 的两条发送路由；模型切换、权限、停止、输出、用量和回放不分裂。CLI 只负责本机执行和原生模型能力，Fleet 负责会话级路由、可见性和安全边界。

## 建议文件落点

- `app/packages/server-core/src/services/cli-runtime-*`
- `app/packages/server-core/src/handlers/rpc/cli-runtime.ts`
- `app/packages/shared/src/protocol/dto.ts`
- `app/apps/electron/src/renderer/components/cli-runtime/*`
- `app/apps/electron/src/renderer/pages/settings/*`

命名和目录可以按新基座实际结构微调，但不得另起第二套 session store。

## 验收

实现后至少验证：

```bash
./scripts/craft.sh run typecheck:electron
./scripts/craft.sh run --filter @craft-agent/server-core typecheck
git diff --check
```

补充测试应覆盖：

- custom runtime 成功和失败。
- detected scan 只在本机 PATH 存在时进入设置页，不能把静态候选误报为“已安装”。
- protocol='acp' 或 `hasCliRuntimeSendAdapter(runtime)` 为 true 才进入聊天 runtime picker；其余 native/subscription 显示 needs_adapter。
- fail_cli/fail_acp/needs_adapter 分级。
- model/thinking 透传；思考强度必须按 runtime 能力裁剪。
- 附件硬拒绝。
- 进程 dispose。

真实 Goose / Hermes / OpenCode / Kimi / Custom ACP 只能做 opt-in smoke，不进入默认 CI。Codex/Claude/Grok/Antigravity/Pi/Cursor Agent 的 one-shot adapter 可做本机手动验收；Qwen/OpenClaw 等未接 native/subscription adapter 前只能检测和展示，不能承诺已可发送。

## Surface 分离目标（D19 · 2026-06-27，P0–P2 落地状态 2026-06-28）

> **Fleet owns the team, CLI owns a run.** CLI Runtime 的目标归属是 terminal surface，不是普通对话框 runtime picker。详见 `docs/38-API-CLI分离与跨Runtime团队编排.md`。
>
> **2026-07-01 状态更新**：下面「目标态」已在 `f1279789`/`145fb5e2`/`6e36071f`（2026-06-28）落地，不再是未来时——`surface = 'chat'` 会话已不显示 CLI picker，终端按钮已创建独立一等面板。状态权威见 `docs/32 §2`「D19」行；本节保留作为行为规格，不重复维护进度数字。

- **现状（2026-06-28 起）**：`surface = 'chat'` 的普通会话已不显示 CLI runtime picker（`FreeFormInput` 按 `surface` 条件渲染），只走 API 模型路径；`cliRuntimeId`/`cliRuntimeModelId` 字段语义不变，只在 `surface = 'terminal'` 会话上绑定。
- **CLI 入口**：终端按钮先走现有 `routes.action.newSession({ surface: 'terminal' })` 创建 craft session，再打开 `routes.view.terminal(sessionId)`（实际 route：`terminal/session/{id}`）渲染 `TerminalPanel.tsx`（xterm + PTY）。它复用既有终端按钮，不新增按钮、不另起第二套 store；session header 持久化 `surface: 'terminal'`。`TerminalPanel` 已通过 `appendTerminalTranscript` 把 PTY 回车输入/输出写回同一 craft session（输入 `user`，输出 `tool`，不触发 LLM），并在 terminal route 聚焦时继续渲染“所有会话”Navigator。2026-07-03 补：terminal panel 重挂载会加载同一 session 的持久化 transcript 并恢复显示；header/拖拽标签/列表新面板打开路径按 terminal session 处理。状态：transcript 持久化与重挂载显示 `usable`；活 PTY 进程跨页面保活和 AgentSeat↔RuntimeLane 归属字段仍 `not implemented`。
- **终端一等面板**（`docs/37 §0.4`）：`TerminalPanel.tsx` 已经 `PanelSlot`/`pushPanelAtom` 接入多面板 grid，与 API 队员对话并排；`Cmd+J` 与顶部终端按钮走同一 `routes.action.newSession({ surface: 'terminal' })` 路径，不再打开旧底部 split。旧 `BottomTerminalPanel` 组件已删除，不得恢复为默认入口。
- **不新建第二套 session**：CLI/终端会话仍在 craft `SessionManager` 里，带 `surface` 标识；不另起第二套 store。

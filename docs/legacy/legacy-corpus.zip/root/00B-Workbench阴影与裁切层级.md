# Workbench 阴影与裁切层级
> ⚠️ **参考层**（2026-07-05 三层定形）：本文为细节/历史权威；当前路线与状态以 `docs/蓝图/INDEX-文档总地图.md` + `docs/04`（含 §1b 最新决策）+ `docs/32` 为准。

> 速查：对话框 / 终端 / Tool Dock 底边 `shadow-middle` 被裁掉时，按本文「布局契约」查，不要零散加 wrapper。

## 布局契约（单一真相，禁止打地鼠）

`PanelStackContainer` 桌面内容区只有 **两种模式**，由可见 content panel 数量切换：

| 模式 | 结构 | 禁止 |
|---|---|---|
| **A. 单面板 / row（craft 基线）** | `scrollRef` → `motion.div` flex 行 → sidebar / navigator / **PanelSlot 直接 sibling** | 不要在 PanelSlot 外包 `flex-col` + `overflow-auto` |
| **B. 多面板 grid（Fleet 扩展）** | 同一 flex 行内的 content area 使用 `overflow-visible` grid 壳承载多个 `PanelSlot`；终端也是 `terminal/session/{id}` 普通 content panel | 不要新增 bottom slot、terminal wrapper、嵌套滚动列或第三套面板 chrome |

**真实间隙**：AppShell shell row 统一使用 `PANEL_EDGE_INSET` 作为工作区左 / 上 / 右 / 底外缘 inset，所有相邻区域和 Tool Dock 模块 seam 统一使用 `PANEL_GAP`。阴影溢出不得再通过负 margin / 额外 padding 改变可测 rect。

**终端叠层**：终端不再是底部模块；它与聊天/设置/文件等一样由 `PanelSlot` 承载，参与同一 row/grid 布局。

## 硬规则

1. **禁止** 在 `shadow-middle` 祖先上使用 `overflow-auto`（含 `overflow-x-auto` + `overflow-y-visible` 组合）。
2. **禁止** 为修阴影/高度再加第三套 wrapper；只能改 A/B 两种模式之一。
3. 终端面板间距用 `PANEL_GAP`，不用 `pt-1` / `height + 4`。
4. Tool Dock 模块：`CraftModulePanel` 外壳 `overflow-visible`，内容区 `overflow-hidden`；禁止复活 `WorkbenchModuleFrame` 第三套 chrome 或旧 `BottomTerminalPanel`。

## Tool Dock 高度契约

与 `PanelStackContainer` 同一 flex 行时：

| 节点 | 类 / 样式 | 禁止 |
|---|---|---|
| 外层壳 | `self-stretch h-full min-h-0 shrink-0 flex-col` | 单独 `h-full` 在 aside 上 |
| `aside` | `flex-1 min-h-0 flex-col overflow-visible` | `h-full` 代替 flex-1；用负 margin / padding 改变右栏可测高度 |
| 每个模块 | `flex-1` + `flex: ratio 1 0px` | 固定 `min-h-[120px]` 组件默认值 |

## 层级（L0–L6）

| 层 | 节点 | overflow | 阴影 |
|---|---|---|---|
| L0 | AppShell shell row | hidden；四边 `PANEL_EDGE_INSET` | — |
| L1 | `PanelStackContainer` scrollRef | x:clip, y:visible；不持有边距补偿 | — |
| L2 | content area flex/grid 壳 | visible | — |
| L3 | `PanelSlot` | hidden（内容裁切） | shadow-middle |
| L4 | terminal surface `PanelSlot` | hidden（PTY 内容裁切） | shadow-middle |
| L5 | `WorkspaceContextSidebar` aside | visible；不持有边距补偿 | 子模块 shadow-middle |

## 验收

1. 单聊天框、不开终端 → 底边阴影与 craft 一致。
2. `Cmd+J` 开终端 → 新增/聚焦 `terminal/session/{id}` content panel；不出现底部 split；聊天↔终端之间阴影完整。
3. 工作区左 / 上 / 右 / 底外缘均为 `PANEL_EDGE_INSET`；sidebar↔Navigator、Navigator↔内容、内容↔Tool Dock、Tool Dock 模块之间均为 `PANEL_GAP`。终端 / Tool Dock 底边阴影完整。
4. 新建 7/8/9 个内容面板 → 当前工作台使用稳定 3×3 grid；新建超过 9 个时最多挂载 9 个，较早面板只从可见栈移出，不删除会话。
5. 右侧 Tool Dock 只在剩余宽度满足当前内容 grid 最小宽度时 dock；面板数量不得自动折叠或压缩左全局 sidebar、“所有会话”Navigator 或右侧 Tool Dock。空间不足时右栏不进入停靠列，不能 overlay 到内容上，也不能挤压内容面板到不可读。
6. 多内容面板 grid 中，普通选中态不得用 `shadow-panel-focused` 外扩 ring，不得给 `PanelSlot` 提升 `z-[1]`，拖拽态不得用 `scale` 放大面板盒；否则选中聊天框会把阴影/边缘压到相邻行上方。顶部胶囊重排不得新增 wrapper 或自由悬浮层；2026-07-03 CDP 已验证 2 面板内容胶囊可换位、2 面板 resize sash 可把宽度从 342/342 调到 384/300、Tool Dock 拖拽期间模块高度和 `transform` 不变。后续全矩阵仍需覆盖 3/6/7/8/9/10 面板。

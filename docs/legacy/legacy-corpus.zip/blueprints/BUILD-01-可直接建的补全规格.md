# BUILD-01 · 可直接建的补全规格（把"机制/规格"层补到"能开工"层）

> **为什么有这篇**：审计发现——记忆后端已落地、团队编排后端在但前端几乎空、能力商城/记忆→Skill 飞轮/浏览器标注动作层三块**只有机制没有可开工的前后端细节**。本文对这些欠详细的块，补上 **协议签名 + RPC 方法签名 + 事件名 + 组件树 + 数据流 + 验收用例 + 并行文件所有权**，并逐块对标本地最佳参考做到顶级。
> **配套**：本文补的是 `蓝图/04/05/08` + `UI-02` 的可开工细节，不替代它们的产品叙述。Agent 开工前读「对应蓝图（做什么）→ 本文（怎么建）」。
> **2026-07-05 状态更正**：§A.1 的 `capability.ts` **已冻结落码**（不再是"Lead 新建"，以代码为准核对字段后直接进 §A.3 服务实现）；§F 画布已列入 F 轨（蓝图 00 §4），其中**网页节点先过 UI-02 §6 的 BrowserView spike 三选一**再开工；§C 群聊/TeamRun 防接错边界表已正式化进 `蓝图/04` 头部。
> **审计真相（代码核对 2026-07-04）**：
> - 记忆：✅ 后端 `memory-store.ts`+`memory.ts` 协议+`memory` RPC+3 前端页面已落。缺：向量召回、记忆→Skill 飞轮接线。
> - 团队编排：🟨 后端 `team-coordinator.ts`(720)+`team-run-coordinator.ts`(422) 在；前端**只有 `TeamRosterHeader.tsx`，teamRun 前端 0 处**。
> - 能力商城：⛔ 无 `capability.ts`、无 catalog/loadout 服务、前端 0 处。相邻基础 = `internal-action.ts`（完整协议）+`skills` RPC（已有）。
> - 浏览器标注：🟨 `packages/ui/src/components/annotations/*` 基建在（interaction-selectors/style-tokens）；缺标注动作层 RPC + 接浏览器节点。

---

## A · 能力装载 / 工具商城（补全 蓝图 08 · 对标 internal-action.ts + lobehub plugins）

> **对标**：`shared/protocol/internal-action.ts`（已有完整 `ActionVerb/ActionPermissionLevel/ActionLocality/InternalActionDefinition/Registry`——`capability.ts` 照它的结构造，不从零）；`源码参考/software/lobehub/plugins` + `builtin-tool-memory`（市场浏览+安装+运行 UI 范式）。

### A.1 协议冻结（Lead · 新建 `shared/protocol/capability.ts`）

```ts
export type CapabilityKind =
  | 'internal-action' | 'skill' | 'mcp' | 'cli-runtime'
  | 'api-provider' | 'connector' | 'plugin'

export type LicenseGate = 'green' | 'pending' | 'blackbox' | 'proprietary'  // D20
export type CapabilityHealth = 'ready' | 'degraded' | 'missing' | 'unverified'
export type CapabilityLocality = 'LOCAL_ONLY' | 'REMOTE_ELIGIBLE'           // 规则14
export type CapabilitySource = 'integrate' | 'adapt'                         // D24

export interface CapabilityDescriptor {
  id: string                       // `kind:source/name`，如 `mcp:figma/figma`
  kind: CapabilityKind
  title: string; description: string          // 默认中文（§汉化）
  source: CapabilitySource
  licenseGate: LicenseGate
  version: string; checksum?: string
  health: CapabilityHealth
  locality: CapabilityLocality
  installed: boolean               // 安装平面（本机有没有）
  iconSource?: string
  // 依赖：一个 skill 声明它要哪些 internal-action/mcp/cli
  requires?: { internalActions?: string[]; mcp?: string[]; cliRuntime?: string[] }
}

/** 装载平面：此刻给谁/在哪范围挂哪些能力、开多大权限 */
export interface CapabilityLoadout {
  seatId: string                   // 复用 team-run.ts 的 AgentSeat.seatId
  laneId?: string
  scopeId: string                  // workspace/session scope（多项目隔离）
  internalActions: string[]        // 允许的 action id
  skills: string[]; mcpServers: string[]
  cliCapabilities: string[]; apiTools: string[]
  maxPermissionLevel: ActionPermissionLevel   // 该 loadout 的权限上限
}

export interface CapabilityCatalog { descriptors: CapabilityDescriptor[]; observedAt: string }
export interface LoadoutResolveResult { loadout: CapabilityLoadout; droppedByLicense: string[]; droppedByHealth: string[] }
```

### A.2 RPC 方法签名（Lead 建空壳注册 → Agent 填实现）

| RPC channel | 签名 | 权限 |
|---|---|---|
| `capability.catalog` | `(workspaceId) => CapabilityCatalog` | L0 |
| `capability.loadout.get` | `(scopeId, seatId) => CapabilityLoadout` | L0 |
| `capability.loadout.set` | `(loadout: CapabilityLoadout) => LoadoutResolveResult` | L1 |
| `capability.install` | `(descriptorId) => CapabilityDescriptor` | **L2**（改本机） |
| `capability.uninstall` | `(descriptorId) => void` | L2 |
| `capability.compose` | `(scopeId, seatId, taskHint?) => CapabilityLoadout` | L1（管理 Agent 自动装载，读记忆飞轮 §B） |

事件：`capability_catalog_changed` / `capability_loadout_changed` / `capability_install`（写 timeline，含 licenseGate 决策）。

### A.3 服务（server-core，Agent 实现）

- `CapabilityCatalogService`：枚举五类来源 → `CapabilityDescriptor[]`。internal-action 直接读 `InternalActionRegistry`（已有）；skill 读 `skills` RPC 已有能力；mcp/cli/api 读各自 registry。
- `CapabilityLoadoutService`：按 seat/lane/scope 存取 loadout，落 `<workspace>/.fleet/loadouts.json`。
- `CapabilityResolver`：装载时按 licenseGate（pending/proprietary 需确认）+ health（missing 剔除）过滤 → `LoadoutResolveResult`。MCP 按 scope 隔离启动（接蓝图 03 RuntimeLauncherAdapter）。

### A.4 前端组件树（UI-01 §7 技能页 + 装载面板 · 对标 lobehub market）

```
SkillMarketPage (新)                       ← 左栏「技能」入口
├── Tabs [技能市场 | 已安装]               (trae tabs)
├── CategoryChips [全部|开发|数据|设计|内容|效率]
├── SearchInput
├── CapabilityGrid                         (2 列, trae cards)
│   └── CapabilityCard × N
│       ├── icon + title + description
│       ├── LicenseBadge (green/pending/blackbox/proprietary)  ← 颜色语义
│       ├── HealthDot (ready/degraded/missing)
│       └── InstallButton [+]/[已安装]      → capability.install
└── UploadButton [+ 上传技能]

LoadoutPanel (新, 每 workspace/seat)         ← 装载最小集
├── SeatSelector (G-01/G-02…)
├── CapabilityChecklist (勾选装载哪些)       → capability.loadout.set
├── PermissionCap [L0|L1|L2|L3]
└── ResolvePreview (droppedByLicense/Health 提示)
```

### A.5 验收用例
- [ ] catalog 能枚举 internal-action+skill+mcp+cli+api 五类，licenseGate/health 正确。
- [ ] loadout 按 seat/scope 存取；不同 workspace 工具表隔离（改 A workspace loadout 不影响 B）。
- [ ] 装 pending/proprietary 能力弹确认；green 直接装。
- [ ] MCP 按 scope 隔离启动，多入口（CLI/API/MCP）共存不冲突。
- [ ] 商城安装 ≠ 装载分离（装了不自动挂，需在 LoadoutPanel 勾）。

### A.6 并行文件所有权
`shared/protocol/capability.ts`(Lead 冻) · `server-core/services/capability-{catalog,loadout,resolver}.ts` · `handlers/rpc/capability.ts`(Lead 空壳) · `renderer/pages/SkillMarketPage.tsx` · `renderer/components/loadout/LoadoutPanel.tsx`。

---

## B · 记忆 → Skill 沉淀飞轮（补全 蓝图 05 §4.1 · 对标 CowAgent 记忆服务 + lobehub AddExperienceMemory）

> **对标**：`源码参考/software/CowAgent/agent/memory/`（`service/chunker/embedding/provider/rebuild/conversation_store` = 完整 embedding 记忆服务，用于把记忆升级到向量召回，docs/05 说"向量库未做"的正解）；`lobehub/packages/builtin-tool-memory/src/client/Intervention/AddExperienceMemory`（把"沉淀经验"做成可确认的 UI 范式）。
> **现状**：记忆 CRUD/分区/TF-IDF 已落；**缺两件**：① 向量召回（顶级化）；② 程序记忆候选 → 确认蒸馏成 Skill 的接线（飞轮）。

### B.1 协议补充（Lead · 扩 `shared/protocol/memory.ts`）

```ts
// 程序记忆候选（重复模式发现，蓝图05 §4.1）
export interface ProceduralCandidate {
  id: string
  scopeId: string; seatId?: string
  actionSequence: string[]        // 重复的 internal-action id 序列
  observedCount: number           // 命中次数
  similarity: number              // 相似度（0-1）
  status: 'candidate' | 'confirmed' | 'decayed'
  suggestedSkillName?: string
  evidenceSessionIds: string[]    // 反推 Workflow Trace 用（docs/39）
  observedAt: string
}
```

### B.2 RPC + 事件

| RPC | 签名 | 说明 |
|---|---|---|
| `memory.candidates.list` | `(scopeId?) => ProceduralCandidate[]` | 记忆面板"程序记忆候选"区 |
| `memory.candidates.distill` | `(candidateId) => { skillManifestPath }` | 确认蒸馏 → 走 docs/39 Skill Distiller，产出 `FleetSkillManifest` |
| `memory.candidates.dismiss` | `(candidateId) => void` | 忽略 → 按 §4.2 衰减 |
| `memory.recall` | `(query, topK) => MemoryEntry[]` | **向量召回**（新，替代/叠加 TF-IDF） |

事件：`procedural_candidate_found`（管理 Agent 扫描时）/ `memory_distilled_to_skill`（写 timeline）。

### B.3 服务（对标 CowAgent）
- **向量召回**：新增 `MemoryEmbeddingService`，结构照 CowAgent：`chunker`（切片）+ `embedding/provider`（本地嵌入，如 bge-small/gte）+ 向量存 `<workspace>/.fleet/memory-vectors/`（sqlite-vec 或 hnswlib）+ `rebuild`（重建索引）。检索时向量 + 关键词混合。**本地优先、离线可用**（与开源无云一致，D26）。
- **飞轮扫描**：管理 Agent 在 Decay/Retrieval 例行扫描时（不新增常驻进程，蓝图 05 §4.1），对同 seat/user 跨会话的相近 internal-action 序列打分 → 写 `ProceduralCandidate(status:candidate)`。阈值/次数留实现调参。
- **蒸馏**：`distill` 把候选的 `evidenceSessionIds` 反推成 `docs/39 §5.5` Workflow Trace → 交 `docs/39 §5.6` Skill Distiller → 产出 `FleetSkillManifest` → 该 Skill 被 `capability.compose`（§A.2）优先装载。飞轮闭合。

### B.4 前端（扩 `MemorySettingsPage.tsx`，已存在）
```
MemorySettingsPage (已有, 扩展)
├── PartitionTabs [7 分区]                  (已有)
├── MemoryList (查看/删除/启禁)             (已有)
├── + ProceduralCandidateSection (新)       ← 飞轮 UI, 对标 lobehub AddExperienceMemory
│   └── CandidateCard × N
│       ├── actionSequence 预览 + observedCount
│       ├── [蒸馏成 Skill] → memory.candidates.distill  (L2 确认)
│       └── [忽略] → dismiss
└── + RecallSearchBox (新, 向量召回演示/调试)
```

### B.5 验收
- [ ] 向量召回：语义近似查询能命中非字面匹配的记忆（对比 TF-IDF 提升可见）。
- [ ] 跨 ≥2 会话重复相近 action 序列 → 生成 candidate。
- [ ] 确认蒸馏 → 产出 FleetSkillManifest，下次同类任务被 compose 优先装载（飞轮闭合可验）。
- [ ] 候选长期不确认 → 按衰减规则降权，不无限堆积。
- [ ] 删除/蒸馏走 L2/L3，写 timeline。

### B.6 并行文件所有权
`shared/protocol/memory.ts`(Lead 扩) · `server-core/services/memory-embedding.ts`(新) · `memory-store.ts`(扩候选) · `handlers/rpc/memory.ts`(扩) · `renderer/pages/settings/MemorySettingsPage.tsx`(扩)。

---

## C · 团队编排前端（补全 蓝图 04 · 后端在、前端几乎空 · 对标 AionUi teamMapper/useTeamRunView）

> **现状**：后端两个 coordinator + `team-run`/`team` RPC 都在；前端**只有 `TeamRosterHeader.tsx`**。这是"后端在前端空"的典型——不是蓝图不够，是前端没建。本节把前端补到可开工。
> **对标**：AionUi 的 `teamMapper`/`useTeamRunView`/`useSiderTeamBadges`（团队状态→UI 映射、TeamRun 视图、侧栏 badge——AionUi 是绿灯，可迁模式）。

### C.1 前端组件树（对话流内 + 画布编排视图 UI-02 §8 两处）

```
对话流内（会话是队长时）:
TeamGroupChat (新)
├── TeamRosterHeader (已有)                 队长/成员花名册
├── TimelineFeed
│   ├── TaskCard         (指派任务卡)        ← teamRun propose/start
│   ├── PermissionCard   (attributionChain 全链 + 风险 + 写目标 + 成本源)
│   ├── ReportCard       (RunReport: changedFiles/diffSummary/evidenceRefs)
│   └── MemberMessageCard (@Agent 私发/广播)
├── MemberDrawer (成员抽屉: 完整执行/diff/证据/回滚)
└── Composer (带 @Agent 补全 + 编排模式选择 群聊/TeamRun/DAG)

画布编排视图 (UI-02 §8):
CanvasOrchestration
├── AgentDialogWindowNode × N   (每 Agent 一个对话窗节点)
│   ├── header: seat 序号 + role + laneBadge (API/CLI)
│   ├── body: 该 Agent timeline 卡（复用 TaskCard/ReportCard）
│   ├── status: running/待确认/完成
│   └── [⛶全屏] → MemberDrawer
└── OrchestrationEdge × M       (指派/报告连线, 标 attributionChain)
```

### C.2 前端 ↔ 后端对接（RPC 已存在，前端只需接）

| 组件动作 | 已有 RPC | 事件订阅 |
|---|---|---|
| 指派任务 | `teamRun.propose` / `teamRun.startRun` | `team_run_*` 状态机事件 |
| 发消息 | `team.sendMessage`（team-coordinator） | session events |
| 看报告 | `teamRun.getReport` | `run_report` |
| 改身份/规则 | `team-rules` RPC | `labels_changed` |
| 权限批准 | permission 通道 | `permission_request` |

> **关键提示（防接错，接 REVIEW §风险2）**：**群聊发消息/改身份走 `team`（TeamCoordinator）；跨 runtime 派 TeamRun 走 `teamRun`（TeamRunCoordinator）。** 前端两套卡都复用同一 timeline 渲染，但调不同 RPC。

### C.3 验收
- [ ] 会话切队长 → 出现团队群聊；`@Agent` 私发/广播正确。
- [ ] 指派任务 → TaskCard → 后端真实投递 → ReportCard 回填（不是假 UI）。
- [ ] 权限卡展示完整 attributionChain + 成本六值来源。
- [ ] 画布编排视图：每 Agent 一个对话窗节点 + 指派/报告连线；人可在窗内插话批权限。
- [ ] 群聊消息走 `team`、TeamRun 走 `teamRun`，不混用（代码可查）。

### C.4 并行文件所有权
`renderer/components/team/{TeamGroupChat,TaskCard,PermissionCard,ReportCard,MemberDrawer}.tsx` · `renderer/canvas/nodes/AgentDialogWindowNode.tsx` · 复用已有 `TeamRosterHeader.tsx` + `team`/`teamRun` RPC（不改后端契约）。

---

## D · 浏览器标注 / 设计动作层（补全 蓝图 06 + UI-02 §6 · 对标 open-design live-artifacts）

> **现状**：`packages/ui/src/components/annotations/*`（interaction-selectors/style-tokens/annotation-resolver）基建在；**缺**：标注动作 → 结构化 DesignAction → 写 SessionEvent 的接线，以及接进浏览器节点。
> **对标**：`源码参考/plugins/open-design/specs/2026-04-29-live-artifacts/`（live-artifact 的 provenance/template/data 结构 + 禁止裸字段校验——DesignAction 的信封与来源留痕照它）。

### D.1 协议补充（扩 `shared/protocol/design.ts`）

```ts
export type AnnotationMode = 'single' | 'box' | 'multi'   // 单选/框选/多选
export interface WebAnnotation {
  id: string; nodeId: string                // 所属网页/artifact 节点
  mode: AnnotationMode
  selector: string                          // 元素选择器/坐标框（interaction-selectors 已有）
  note?: string; commentAI?: string         // 人工注释 / Comment AI
  evidenceRef?: string                      // 截图/证据
  actor: ActorRef; createdAt: string
}
// DesignAction 信封（人和 AI 共用，D7）——source 留痕对标 open-design provenance
export interface DesignAction {
  id: string; kind: 'annotate' | 'select' | 'insert' | 'transform' | 'mask' | 'style' | 'export'
  targetNodeId: string; payload: unknown
  actor: ActorRef; agentId?: string; runtime?: string
  undoHandle?: ActionUndoHandle             // 复用 internal-action.ts
  provenance: { sourceUrl?: string; license?: string; hash?: string }  // open-design 式
}
```

### D.2 RPC + 事件

| RPC | 签名 | 权限 |
|---|---|---|
| `design.annotate` | `(WebAnnotation) => WebAnnotation` | L0（普通网页只读注释） |
| `design.action` | `(DesignAction) => { undoHandle }` | L1 编辑 / L2 删除（仅 artifact/本地 preview 可编辑，规则18） |
| `design.export` | `(nodeId, format) => assetPath` | L1 |
| `design.review.submit` | `(bundle, platforms[]) => ReviewReport`（蓝图07） | **L2/L3**（外发） |

事件：`design_action`（每动作写 SessionEvent，可回放回滚）/ `annotation_added`。

### D.3 前端（接 UI-02 网页节点浮动工具栏）
```
WebNode 选中 → FloatingToolbar (web 变体):
[单选][框选][多选][批量注释][Comment AI][截图][进设计]
                                            │
  普通网页: 只到"注释/截图/给Agent上下文"(L0)
  artifact/本地preview: 开放"进设计"→ ArtifactStudio(openpencil/penpot 全屏)
AnnotationLayer (叠在网页节点上, 复用 interaction-selectors)
└── AnnotationMarker × N (选区高亮 + 注释气泡 + Comment AI)
```

### D.4 验收
- [ ] 普通网页可单/框/多选 + 批量注释 → 证据包进 timeline，**不可**破坏性编辑。
- [ ] artifact/本地 preview 可进 ArtifactStudio 编辑；每个 DesignAction 有 actor/provenance、可回滚。
- [ ] 字体/网络资源/AI 输出记 source/license/hash（open-design provenance 式，规则20）。
- [ ] 外部审查外发走 L2/L3 + secret scan（蓝图07）。

### D.5 并行文件所有权
`shared/protocol/design.ts`(Lead 扩) · `server-core/services/design-engine.ts`(已有 309 行, 扩 annotate/action) · `handlers/rpc/design.ts`(已有, 扩) · `packages/ui/src/components/annotations/*`(已有, 接线) · `renderer/canvas/nodes/WebNode.tsx` + `FloatingToolbar` web 变体。

---

## E · 落地状态总表（本文覆盖的四块 · 补全后）

| 能力 | 后端 | RPC | 前端 | 协议 | 蓝图详细度（补全前→后） | 对标参考 |
|---|---|---|---|---|---|---|
| 记忆 CRUD/分区 | ✅ | ✅ | ✅ | ✅ | 够 → 够 | — |
| 记忆向量召回 | ⛔ | ⛔(补 §B.2) | ⛔ | 补 §B.1 | 机制 → **可建** | CowAgent embedding |
| 记忆→Skill 飞轮 | ⛔ | ⛔(补 §B.2) | ⛔ | 补 §B.1 | 机制 → **可建** | lobehub AddExperienceMemory |
| 团队编排后端 | ✅ | ✅ | — | ✅ | 够 → 够 | — |
| 团队编排前端 | — | (已有) | ⛔→补 §C.1 | — | 空 → **可建** | AionUi useTeamRunView |
| 能力装载/商城 | ⛔ | ⛔(补 §A.2) | ⛔ | 补 §A.1 | 规格 → **可建** | internal-action.ts + lobehub |
| 浏览器标注动作层 | 🟨 | 补 §D.2 | 🟨→补 §D.3 | 补 §D.1 | 机制 → **可建** | open-design live-artifacts |
| 调用 Bridge 同步阻塞 | 🟨骨架 | ✅ | ⛔ | ✅ | 够（承重墙未做，蓝图04） | omnigent native-hook |

> 其余能力见下方 §F/§G 补全。native-hook 逐 runtime 策略见 REVIEW §2.1（已登记）。

---

## F · 无限画布地基（补全 UI-02 · 关键路径 · 整块净新建 · 对标本地 tldraw）

> **审计铁证**：`apps/electron/src/renderer/canvas/` **目录不存在**——UI-02 描述的整个无限画布（节点/连线/浮动栏/编排窗/剪辑框/网页节点/设计节点）**在代码里 0 行**。而你点名"没落地"的能力（生图/生视频/剪辑/编排/标注）**全部挂在画布上**。所以这是**最高优先级的净新建**，不是接线。
> **对标**：`源码参考/software/tldraw`（本地完整 monorepo，可直接依赖）。画布 store ↔ SessionEvent 的语义照 `源码参考/plugins/tapnow-reverse-config/.config/contracts/canvas-orchestration.md`（CREATE/PATCH/group/derivation-edge 已验证范式）。

### F.1 地基分层（Agent 按此顺序建 `renderer/canvas/`）

```
renderer/canvas/
├── CanvasRoot.tsx            tldraw 实例 + 深色域(.canvas-dark) + 视口虚拟化
├── store/
│   ├── canvas-store.ts       tldraw store ↔ Fleet 节点/连线记录
│   └── session-sync.ts       store 变更 → SessionEvent（人/AI 同一路径, D14）
├── nodes/                    自研 shape（NodeShell 外壳 + 类型内容）
│   ├── TextNode / ImageNode / VideoNode / AudioNode
│   ├── WebNode (§D 浏览器节点) / WebsiteNode + MiniAppCapsuleNode (§F.2 网站功能映射)
│   ├── DesignNode (§ArtifactStudio)
│   ├── ClipFrameNode (剪辑框, 连线引素材) / AgentDialogWindowNode (§C 编排窗)
│   └── GroupNode / PluginCardNode
├── edges/ DerivationEdge.tsx  派生/引用连线（箭头曲线）
├── toolbar/ FloatingToolbar.tsx  选中随动浮动栏（image/video/web/text 变体, §D.3）
├── AddNodePanel.tsx          左侧"+ 添加节点"（TapNow 式分类面板）
└── CanvasHeader.tsx          ▷预览 ⊞排布 ⤢全屏 ⋯ + 缩放
```

### F.2 协议 + RPC（Lead 新建 `shared/protocol/canvas.ts`）

```ts
export type CanvasNodeType =
  | 'text' | 'image' | 'video' | 'audio' | 'web' | 'website' | 'mini-app'
  | 'design' | 'clip' | 'chat' | 'group' | 'plugin'
export interface CanvasNode {
  id: string; type: CanvasNodeType; sessionId: string
  x: number; y: number; w: number; h: number
  assetId?: string; assetPath?: string        // 生成产物自动登记（tapnow discipline）
  parentId?: string                            // 组
  title?: string; contentRef?: string
  website?: WebsiteNodeRef
  capsule?: MiniAppCapsuleRef
}
export interface CanvasEdge { id: string; from: string; to: string; edgeType: 'derive'|'reference'|'feed-asset' }

export interface WebsiteNodeRef {
  url: string
  profileId?: string          // 用户授权登录 profile；不读 cookie/token 原文
  screenshotAssetId?: string
  actionMappingIds?: string[]
}

export interface MiniAppCapsuleRef {
  websiteNodeId: string
  title: string
  actionMappingIds: string[]
}

export interface WebsiteActionMapping {
  id: string
  websiteNodeId: string
  actionId: string            // 稳定 tool/action 名，如 jimeng.generateImage
  label: string
  paramsSchema: unknown
  executionMode: 'official_api' | 'browser_assist' | 'user_confirmed_browser'
  permissionLevel: 'L0' | 'L1' | 'L2' | 'L3'
  outputTypes: Array<'image' | 'video' | 'audio' | 'webpage' | 'ppt' | 'file'>
  downloadPolicy: 'required' | 'optional' | 'manual'
}
```

| RPC | 签名 | 说明 |
|---|---|---|
| `canvas.node.write` | `(CanvasNode, mode:'create'\|'patch') => CanvasNode` | tapnow §2 CREATE/PATCH 语义 |
| `canvas.node.get`/`list`/`search` | 读节点/连线 | 读 incoming/outgoingEdges 判数据流 |
| `canvas.edge.create` | `(CanvasEdge) => CanvasEdge` | 连线引素材 |
| `canvas.group.recent` | `(label) => {groupId}` | 本轮≥2产物收口（tapnow auto-group） |
| `canvas.website.mapAction` | `(WebsiteActionMapping) => WebsiteActionMapping` | 把网站核心按钮/流程固化成人和 Agent 共用 action |
| `canvas.website.runAction` | `(mappingId, params, outputTarget:'canvas'\|'library'\|'download') => {jobId}` | 调用官方 API 或受控浏览器流程 |
| `canvas.asset.ingest` | `(source, fileRef, provenance) => CanvasNode` | 下载/导入外部网站生成素材，落本地后登记节点 |

事件：`canvas_node_changed`/`canvas_edge_changed`/`website_action_mapped`/`website_action_run`/`canvas_asset_ingested`（写 SessionEvent，回放回滚）。**生成产物（生图/生视频/网站组件输出）由 External Job 或 WebsiteActionAdapter 完成后自动调 `canvas.asset.ingest` + `canvas.node.write` 登记，不重复 add**（tapnow discipline，接 §G）。

### F.2.1 网站组件实现边界（WebsiteNode / MiniAppCapsule）

- **不是 BrowserPane 功能**：WebsiteNode/MiniAppCapsule 属于 `renderer/canvas/**` 的画布节点和画布动作，不能实现成 BrowserPane 面板、浏览器工具栏按钮或旧 `browser_tool` 的别名。它可以调用 Browser/CDP/download/profile adapter，但调用结果必须回到 canvas store、SessionEvent、资产 ingest 和画布节点连线。
- **WebsiteNode**：先解决"网站在画布里可用"。字段包含 URL、登录 profile 引用、缩略截图、全屏打开入口、输出队列、可下载素材列表。
- **MiniAppCapsule**：由 WebsiteNode 的高频动作固化而来，只显示核心表单/按钮。人点击按钮和 Agent 调 `canvas.website.runAction` 使用同一 `WebsiteActionMapping`。
- **动作来源**：官方 API/MCP 优先；无官方 API 时可用 `browser_assist` 或 `user_confirmed_browser`，但不做 stealth、不绕验证码/风控/额度/付费墙。
- **输出资产**：所有生成图片/视频/PPT/网页/file 必须先落本地 session/workspace 资产目录，记录网站、URL、账号来源、输入参数、生成时间、hash、许可证/商业风险，再生成画布节点并连 `derive` 边。
- **成本来源**：第三方订阅/API 只读记为 `SUBSCRIPTION_QUOTA` / `BYOK_API` / `EXTERNAL_JOB` / `UNKNOWN`；Fleet 不卖会员，不把第三方订阅写成免费。

### F.3 验收
- [ ] `renderer/canvas/` 建成，CanvasRoot 用本地 tldraw 渲染，深色域 + 令牌。
- [ ] 8 类节点 shape 可创建；WebNode/DesignNode/ClipFrame/AgentDialogWindow 可 `⛶全屏`。
- [ ] WebsiteNode 可保存网站缩略、全屏打开和登录 profile 引用；MiniAppCapsule 可展示映射动作表单。
- [ ] `canvas.website.runAction` 的人类按钮和 Agent action 同源；执行后素材下载到本地并自动生成画布节点。
- [ ] 选中节点出随动浮动工具栏（按类型变工具集）。
- [ ] 连线可把图/网页引入剪辑框；导出产物回登记为节点。
- [ ] store 变更进 SessionEvent，人和 AI 改同一份，可回放回滚，无第二套真相。
- [ ] 几千节点虚拟化流畅、内存可控。

### F.4 并行文件所有权
`shared/protocol/canvas.ts`(Lead 冻) · `renderer/canvas/**`(画布 Agent 独占) · `handlers/rpc/canvas.ts`(Lead 空壳) · `server-core/services/canvas-service.ts`(新, 持久化节点/连线到 session) · `server-core/services/website-action-adapter.ts`(新, 网站映射动作执行/下载/归因)。**这是一个 Agent 的大活，独立 worktree。**

---

## G · 省 Token / 审查中心前端（补全 蓝图 07 · 后端已实、前端 0 · 对标已有 external-job-service）

> **审计铁证**：`external-job-service.ts` 已实现 `PackProjectInput/PackProjectResult`（打包）、`ExternalReviewProvider`（外部审查）、`ImageGenProvider`（生图）、`run/poll`（异步 job）。**后端是真的**。但 `grep 审查中心/打包/ReviewReport` 前端 **0 处**——只有一个 `ExternalJobsSettingsPage.tsx`。所以蓝图 07 缺的是**前端**，不是后端。
> **对标**：已有后端接口即契约；UI 参考用户发的 Craft「使用情况」+ TapNow 审查卡。

### G.1 前端组件（接已有 external-job RPC）
```
顶部工具区:
[打包当前项目] → PackDialog (范围/格式/token count/secret scan) → external-job PackProject
[提交外部审查] → ReviewDialog (选平台 + 数据包摘要 + secret scan + 成本) → external-job review (L2/L3外发)

审查报告:
ReviewReportCard (平台/bundleHash/成本/隐私/原始返回/归一化)  ← poll external-job
Token 环节省区 (压缩前后/外部审查节省估算, 真实vs估算分色)      ← 接 UI-01 §6 Token 页
```

### G.2 RPC（多数已有，确认签名）
| 动作 | RPC（external-job 已有） |
|---|---|
| 打包 | `externalJob.packProject(input) => PackProjectResult` |
| 外部审查 | `externalJob.run(jobId)` + `poll` → ReviewReport |
| 生图/生视频 | `externalJob.run` (ImageGenProvider) → 产物自动登记画布(§F.2) |

### G.3 验收
- [ ] 打包输出应用 ignore/secret scan，显示 token count。
- [ ] 外发前展示数据包摘要+secret+平台+成本+回滚，走 L2/L3。
- [ ] ReviewReport 归一化多平台返回、可追踪。
- [ ] 真实/估算/未知成本三色分开；不写"免费"。
- [ ] 生图产物自动进画布节点（§F.2），不重复 add。

### G.4 并行文件所有权
`renderer/components/review/{PackDialog,ReviewDialog,ReviewReportCard}.tsx` · 复用已有 `external-job` RPC + `ExternalJobsSettingsPage.tsx` + `git-review-service`（不改后端）。

---

## H · 最终落地状态总表（全能力 · 代码核对 2026-07-04）

| 能力 | 后端服务 | RPC | 前端 | 协议 | 净差距 | 补全在 |
|---|---|---|---|---|---|---|
| 记忆 CRUD/分区/TF-IDF | ✅ | ✅ | ✅ | ✅ | 无 | — |
| 记忆向量召回 | ⛔ | ⛔ | ⛔ | ⛔ | 后端+前端 | §B |
| 记忆→Skill 飞轮 | ⛔ | ⛔ | ⛔ | ⛔ | 全栈 | §B |
| 团队编排后端(两coordinator) | ✅ | ✅ | — | ✅ | 无 | — |
| 团队编排前端(群聊/卡/编排窗) | — | ✅ | ⛔(仅Roster) | ✅ | **前端** | §C |
| Bridge 同步阻塞(调用) | 🟨骨架 | ✅ | ⛔ | ✅ | 后端补完+前端 | 蓝图04 |
| 能力装载/工具商城 | ⛔ | ⛔ | ⛔ | ⛔ | 全栈(有相邻基础) | §A |
| 浏览器标注/设计动作层 | 🟨(engine在) | 🟨 | 🟨(基建在) | 🟨 | 接线+协议 | §D |
| **无限画布(节点/连线/浮动栏)** | ⛔ | ⛔ | **⛔整块无** | ⛔ | **全栈净新建** | **§F** |
| 省Token/审查中心 | ✅(external-job) | ✅ | ⛔ | ✅ | **前端** | §G |
| 生图/生视频 | ✅(ImageGenProvider) | ✅ | 🟨(设置页) | ✅ | 前端接画布 | §F/§G |
| 路由决策可视 | ✅ | ✅ | ✅(ModelRoutingEvent) | ✅ | 无 | — |
| 终端 surface | 🟨 | ✅ | ✅(TerminalPanel) | ✅ | launcher 补完 | 蓝图03 |
| 设计引擎(patch/rollback) | ✅(design-engine) | ✅ | ⛔(接画布) | ✅ | 前端接画布 | §D/§F |
| native-hook 逐runtime | ⛔ | — | — | 🟨 | 后端 | REVIEW§2.1 |

**一句话结论**：你观察到"很多没落地"是**准确的**，但原因分三类——(1) **整块净新建**：无限画布(§F)是最大的、且是生图/剪辑/编排/标注的共同地基；(2) **后端在、前端空**：团队编排(§C)、审查中心(§G)、生图接画布；(3) **全栈未起但有相邻基础**：能力商城(§A)、记忆飞轮(§B)。**我之前的蓝图对 (2)(3) 停在了规格层——本 BUILD-01 已把它们补到"能直接建"。** 关键路径 = 先建 §F 画布地基，其上的 §C/§D/§G 才有落点。

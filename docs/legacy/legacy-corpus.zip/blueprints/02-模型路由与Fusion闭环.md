# 02 · 模型路由 / Fusion / 分层缓存闭环

> **主 Agent 工作包**。上游裁决见 `00-蓝图总纲 §1`。对应决策 D5；细节权威 = 旧 `docs/03-Fusion多模型融合方案.md`（本闭环为收口执行版）。
> **红线**：路由**只挂 API/OAuth 路径**；选了 CLI Runtime（`cliRuntimeId != null`）整条主干（Auto/Fusion/缓存/瘦身）跳过（规则 39）；生成类走 External Job 平面；管理 Agent 固定 cheap API、永不 Fusion、不给 CLI；Fusion 默认关。
> **方案 B 吸收点**：「本地算力优先路由」= 把 `LOCAL_COMPUTE`（本地模型/MLX）作为**一个路由候选源**纳入 Auto 打分，不是中枢、不另起进程。
> **2026-07-05 修订（4 条）**：① **Fusion 定级**——已建 1000+ 行但默认关、仅 C4：标注为"已建非当前验收项"，Wave 2 不投入新工时，只保开关不坏（REVIEW-07-04 §2.4）；② **跨篇依赖登记**——L2 语义缓存的本地 embedding 与 BUILD-01 §B `MemoryEmbeddingService` 是同一件事，共用一个服务，禁止两套 embedding；③ **数据回流全本地**——RouteLLM 训练数据只落本机 Fleet 数据目录（D26 无云），文档中"数据管线"一律指本地文件/SQLite；④ **mini 判官预算**——判官仅在 Auto 模式且任务类型不明时触发，结果按 (taskType hash) 缓存 24h，单会话判官调用设上限（默认 20 次/会话），超限退默认 tier，防"每条消息交判官税"。

## ① 一句话闭环
对标 Cursor Auto + OpenRouter Fusion：Auto 两轴路由（任务类型 × 复杂度 → fast/balanced/best，含 mini 判官 + 级联升级）→ 输入瘦身（引用蓝图 07）→ 分层缓存（L1 provider prefix / L2 Fleet exact·semantic / L3 panel）→ Fusion（仅 C4，默认关，Synthesis / Plan 两形态 + 后置 Verification）；每条决策写 timeline，偏好数据回流训 RouteLLM。

## ② 现状（代码已核对）
- 🟨 `shared/protocol/routing.ts` 存在；`SessionManager.sendMessage` 见 `cliRuntimeId` 即 `return`（整条路由跳过，行为正确但选择点=创建会话时人工选，此后不重判）。
- 🟨 Auto 路由骨架 / 缓存 / Fusion 落地程度以 `docs/32` 为准（本闭环不重复进度账）。
- ⛔ RouteLLM 训练管线、本地算力候选源未接。

## ③ 目标态
1. **选择粒度写死**：CLI/API 的选择点在**创建 TeamRun/分派任务时**（任务级），不是逐消息；Auto 路由是逐消息级、只在 API lane 内生效（00 §1.3、docs/38 §3.1）。
2. **Auto**：两轴（taskType × complexity）→ tier；mini 二段判官；级联 cascade 升级；默认 manual。
3. **缓存**：L1 provider prefix（稳定前缀，参照 Reasonix）/ L2 Fleet exact + semantic / L3 panel。
4. **Fusion（默认关，仅 C4）**：Synthesis（文本/审查）/ Plan（动作/重构/设计/视频）+ 后置 Verification 交叉取证。预算分档 Quality/Budget/Custom + 守门 deny。
5. **本地算力候选（吸收 B）**：Auto 打分时把本地模型作为候选，命中则成本记 `LOCAL_COMPUTE`；不持有真相、不当中枢。
6. **数据回流**：接受/重试/换模型/回滚采集进管线，够量训 RouteLLM。

## ④ 前端
- **模型/CLI 运行时选择器**（沿用 `docs/36` 交互）：显示 tier / Fusion 开关 / 预算档 / 本地候选。
- **路由决策可视**：详情显示 taskType/complexity/tier/fusionMode/basis（来自 `model_routing_decision` 事件）。
- **缓存/Fusion 账**：`cache_ledger` 命中真实/估算/未知分开显示（接蓝图 07 Token 环）。
- 管理 Agent 会话不显示 Fusion/tier 选择（固定 cheap）。

## ⑤ 后端
- **协议**（`routing.ts`，改则回 Lead）。
- **服务**：Auto 路由器 + mini 判官 + cascade；分层缓存；Fusion orchestrator + Verification；本地算力候选适配。CLI lane 一律短路跳过（规则 39）。
- **事件**：`model_routing_decision`（每请求）；`cache_ledger`（Fusion/缓存命中）。
- **数据管线**：偏好事件落库，RouteLLM 训练框架。

## ⑥ Agent 工具与 permission/timeline
- 路由是系统行为，不需人确认；但每条决策**必须**写 timeline（规则 40）。
- Fusion 高成本，受预算守门 deny；超档要人确认。

## ⑦ 验收矩阵
- [ ] CLI lane 消息完全跳过 Auto/Fusion/缓存（`cliRuntimeId != null` 短路）。
- [ ] Auto 两轴 → tier 正确；mini 判官 + cascade 生效；默认 manual。
- [ ] 三层缓存命中写 `cache_ledger`，真实/估算/未知分开。
- [ ] Fusion 默认关；开启后 C4 才触发；Verification 交叉取证。
- [ ] 本地算力命中成本记 `LOCAL_COMPUTE`，与 `SUBSCRIPTION_QUOTA`/`BYOK_API` 区分。
- [ ] 每条路由决策进 timeline；偏好数据入管线。

## ⑧ 并行边界
- **文件所有者**：路由/缓存/Fusion 服务、模型选择器组件、路由决策可视组件。
- **只读依赖**：`routing.ts`、蓝图 01 的 `QuotaSnapshot`（读额度给建议）、蓝图 07 的瘦身能力。
- **回 Lead 加**：`routing.*` 字段、事件类型、i18n。
- **波次**：Wave 2，**排在蓝图 04 Bridge smoke 之后**（承重墙优先）。

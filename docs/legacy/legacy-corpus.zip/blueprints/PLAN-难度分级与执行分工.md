# PLAN · 难度分级与执行分工（谁做什么 · 文档够不够）

> **回答你三个问题**：① 哪里最难；② 文档够不够详细、别的 Agent 能否处理；③ 简单的只给验收标准。
> **一个诚实前提（重要）**：本会话沙箱**没有 bun**（仓库整条工具链 typecheck/test/build 都基于 bun），也**装不了**（网络受限）。所以我**无法在这里编译/跑测**任何 TS 改动。按你 `AGENTS.md` 规则 23「外部/多智能体报告必须本机核验」,**最难的后端系统代码我不应该在这里盲写**——那正是不 typecheck 就必然出错的部分。**最难的活要在你真实开发环境里、由能跑 bun 的 Agent（或我在有 bun 的环境）做,人盯着验收。** 下面把它拆到"接手就能写+能验"的程度。

---

## 0 · 结论速览（三档）

| 档 | 判定标准 | 谁做 | 文档状态 |
|---|---|---|---|
| **🔴 最难（承重墙）** | 改动面广、易返工、错了拖垮全局、需在真实运行环境反复验 | **我/资深 Agent 在有 bun 的环境 + 人盯验收** | 已到"可建",但**必须能跑测**才动 |
| **🟡 中等** | 边界清、有相邻范式、单人独立 worktree 可完成 | **其他 Agent 按 BUILD-01 + 蓝图独立做** | **够详细,可派** |
| **🟢 简单** | 前端接线/展示/配置,后端已就绪 | **任意 Agent,只给验收标准** | 只需验收清单 |

---

## 1 · 🔴 最难（4 块承重墙 · 不能盲写,要能跑测 + 人盯）

> 这 4 块的共同特征:**它们是别的东西的地基**,而且**只有在真实运行/typecheck 下才能确认对**。我在无 bun 沙箱里写 = 违反规则 23。正确做法:在有 bun 的环境做,每步 `typecheck:all` + 对应单测。

### 1.1 Bridge 同步阻塞闭环（D19 核心 · 最高优先）
- **为什么最难**:跨进程异步→对外同步的时序机制,涉及 CLI 进程、MCP loopback、TeamRun 状态机、超时/取消/权限拒绝多路径。错了整个"CLI 队长调 API 队员"是假的。
- **代码实证(我已定位精确缺口)**:`team-run-coordinator.ts:167` `startRun` 分派后**立即返回,没有 blocking await**;`session-mcp-server/src/index.ts:298` `fleet_start_member_run` 工具**已注册但没接 blocking→RunReport 回填**。缺的就是这一条缝:CLI 调工具 → 挂起(maxBlockMs=180000) → TeamRun 异步跑完 → 返回压缩 RunReport / 超时返回 RUN_TIMEOUT_PENDING_REPORT。
- **要能跑的验收**:选一个真实 CLI(或 mock dispatcher),端到端 smoke:`fleet_start_member_run` → 挂起 → API 队员执行 → RunReport 回 CLI。**必须实机 smoke 过**,不能只 typecheck。
- **文档**:蓝图04 + BUILD-01 §H 已够;补了精确缺口位置,接手可直接改这两个文件。

### 1.2 SessionManager 端口化（9.6k god-object · 并行前置）
- **为什么最难**:283k 行代码里最中心的文件,所有闭环都穿过它。拆错→全线编译崩。属"改动面最广"。
- **做法**:照仓库已做对的 `TeamCoordinator`(纯编排+注入端口)范式,抽 `PersistencePort/AuthPort/CredentialPort/BroadcastPort/DispatchPort`,主体只编排。**每抽一个端口跑一次 `typecheck:all` + 全测**,增量提交(规则12用 git 表达恢复点)。
- **为什么不能盲写**:一次动 9.6k 行、跨 10 类职责,无 typecheck 必错。**这块最需要 bun 环境 + 人盯**。
- **文档**:REVIEW §风险1 给了方向;**细粒度拆分清单需在能 typecheck 的环境边拆边定**,不是纸上能拆完的。这是唯一"文档无法预先写全、必须在环境里做"的块。

### 1.3 无限画布地基（整块净新建 · 生图/剪辑/编排/标注的共同地基）
- **为什么最难(工作量维度)**:`renderer/canvas/` **0 行**,要从 tldraw 接入 + 8 类自研节点 shape + store↔SessionEvent 双向同步 + 浮动栏 + 连线。是最大的单块新建,且富交互需实机调。
- **做法**:BUILD-01 §F 已给分层/协议/RPC/验收。本地有完整 tldraw 可依赖。**需在 Electron renderer 里实机跑**(虚拟化/内存/缩放清晰度都要看真机)。
- **文档**:§F 够开工;但画布是"边跑边调"的活,验收含性能(几千节点流畅),必须实机。

### 1.4 native-hook 逐 runtime 权限桥（CLI timeline 细粒度的唯一解）
- **为什么难**:每个 CLI(Claude/Codex/Cursor/Qwen/Hermes)一套 hook 拦截,跨语言(omnigent 是 Python,要重写 TS),fail-closed 时序敏感。
- **做法**:REVIEW §2.1 已指出本地 omnigent 有**逐 runtime 成套 hook**可对标;每个 runtime 一行策略,重写为 TS,不跨语言迁码。
- **文档**:方向够;每个 runtime 的具体拦截点需对着 omnigent 对应文件 + 真实 CLI 实机验。

**这 4 块我在此不写代码的理由,一句话:它们要么改动面大到必须 typecheck、要么要实机 smoke/性能验——无 bun 沙箱写出来的都是不可信产物,违反你自己的规则 23。**

---

## 2 · 🟡 中等（其他 Agent 按文档独立做 · 我确认文档够详细）

> 这些**边界清晰、有相邻范式、BUILD-01 已给到组件树+RPC签名+验收**。一个 Agent 独立 worktree 就能做,不需要我。我逐条确认"文档够不够"。

| 块 | 依赖 | 文档够吗 | 派给 Agent 的入口 |
|---|---|---|---|
| **能力装载/工具商城** | capability.ts(Lead 先冻,§A.1 已给完整协议) | ✅ 够(协议+6RPC+组件树+验收+对标) | BUILD-01 §A |
| **记忆→Skill 飞轮 + 向量召回** | memory.ts 扩(§B.1) | ✅ 够(候选协议+RPC+对标 CowAgent) | BUILD-01 §B |
| **团队编排前端** | team/teamRun RPC(已存在) | ✅ 够(组件树+防接错提示+验收) | BUILD-01 §C |
| **浏览器标注/设计动作层** | design.ts 扩(§D.1)+已有 design-engine | ✅ 够(协议+RPC+接线点+对标 open-design) | BUILD-01 §D |
| **省Token/审查中心前端** | external-job RPC(已实) | ✅ 够(组件+已有后端签名+验收) | BUILD-01 §G |
| **设置页 6 分区重构** | 各设置 RPC 已有 | ✅ 够(UI-01 §8 删/并/留表) | UI-01 §8 |
| **设计系统页(主题卡)** | 主题 config | ✅ 够(UI-00 §4.1) | UI-00 §4.1 |

> **中等档的共识**:文档已把"做什么+怎么接+验收"写全,Agent 不用猜。**唯一前置**:Lead 先在有 bun 的环境冻结 §A.1/§B.1/§D.1/§F.2 那几个新协议(capability/memory 扩/design 扩/canvas),这是并行的起跑枪(规则36)。

---

## 3 · 🟢 简单（只给验收标准,任意 Agent 接）

> 后端已就绪或纯展示,不需要设计,只需"照验收做对"。这里直接给验收,不再写方案。

| 块 | 后端就绪? | 验收标准(达成即完) |
|---|---|---|
| 路由决策卡展示 | ✅ ModelRoutingEvent 已有 | 每条 Auto 路由消息显示 taskType/complexity/tier/fusionMode/basis,数据来自 `model_routing_decision` 事件,无硬编码 |
| Token 使用统计页 | ✅ usage RPC | 显示累计/峰值/会话/活跃天 + 热力图 + 最常用模型/插件;**无金额/无账号**;真实vs估算分色 |
| 终端一等面板收口 | ✅ TerminalPanel 已有 | `⌘J` 与 [+新建]→新终端 同一路径;新建终端进"所有会话";旧底部卡不恢复;PTY 等待 stdin 高亮 |
| 生图/生视频产物进画布 | ✅ ImageGenProvider 已实 | External Job 完成后自动调 `canvas.node.write` 登记为节点,**不重复 add**;成本记 EXTERNAL_JOB |
| 会话列表 lane/状态 badge | ✅ AgentSeat/RuntimeLane | 每项显示 API/CLI/running/待确认 badge,映射 craft session status,颜色用语义令牌 |
| 空态中央输入卡 | ✅ chat-composer 组件 | 标题+大圆角 composer+本地/选择文件夹+4 场景卡,对齐 TRAE;模型选择只此一处 |
| 外观/主题切换 | ✅ theme config | 浅/深主题一键切;画布默认深色;令牌驱动,无每页开关 |
| i18n 汉化 | ✅ i18n locales | 第三方能力标题/描述经 i18n 包裹,默认中文;新增 key 回 Lead 加 |

> 简单档的规则:**不写方案,PR 只按上面这一行验收判过。** 达不到就打回,达到就合。

---

## 4 · 我在这个会话里能可靠交付什么（不吹）

- ✅ **能**:审计代码真实状态、定位精确缺口(如 Bridge 那条缝在哪两行)、把欠详细的蓝图补到可建、做难度分级与派工、写验收标准、梳理文档。这些不需要跑 bun,可靠。
- ❌ **不能可靠做**:在此沙箱写并"声称完成"最难的后端系统代码——无 bun 无法 typecheck/test/smoke,产物不可信,违反规则 23。

**建议的下一步(你选)**:
1. 我按 §2 中等档,挑一块(如能力商城)**把 `capability.ts` 协议文件的完整 TS 写出来**(纯类型,不依赖运行时,风险最低),你拿到有 bun 的环境 typecheck。这是"我能在这做、且对你有用"的最大安全增量。
2. 或我继续把 §1 那 4 块承重墙的**实现级拆解**写得更细(仍是文档,能跑测的 Agent 照着落),不写会崩的代码。
3. 或你在有 bun 的环境开一个能编译的 Agent,我把每块的实现指令写成可执行任务交接单(规则37格式)。

我不假装把最难的代码"做掉了"——那对你没价值,还会埋雷。

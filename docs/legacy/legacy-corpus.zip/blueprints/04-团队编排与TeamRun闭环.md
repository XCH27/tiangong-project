# 04 · 团队编排与 TeamRun 闭环（承重墙）

> **主 Agent 工作包 · 最高优先级承重墙**。上游裁决见 `00-蓝图总纲 §1`。对应决策 D11/D16/D19；权威规格 = 旧 `docs/38-API-CLI分离与跨Runtime团队编排.md`（本闭环为其收口执行版）；协议 `team-run.ts` 已冻结。
> **红线**：不新建第二套 team/session store（规则 13/31）；Bridge 对外同步阻塞、对内异步 TeamRun（规则 41）；L2/L3 Internal Action 不直接暴露给 CLI lane（规则 42）；管理 Agent 永不走 CLI。
> **方案 B 处置**：DAG 编排作为**第三种可选模式**保留（M2+，用于静默重放录制流程），**不取代**群聊/TeamRun（见 §③ 三模式）。
>
> **⚠ 两个 coordinator 边界表（2026-07-05 补，防接错 · REVIEW-07-04 风险 2）**：
>
> | 团队动作 | 走哪个 | RPC 前缀 |
> |---|---|---|
> | 群聊发消息 / @成员 / 改身份 / 改规则 / promote 队长 / 成员报告卡 | **TeamCoordinator**（同 runtime 团队脊柱，`handleCommand`，落 `.fleet/team.rules.json`） | `team.*` |
> | 跨 runtime 派活 / Bridge 同步阻塞 / RunReport / 租约阻塞 / invokeAction | **TeamRunCoordinator**（D19 受控执行） | `teamRun.*` |
>
> 前端两类卡复用同一 timeline 渲染但调不同 RPC；把群聊消息接进 TeamRunCoordinator（或反之）= 第二套投递路径，违反规则 13/31。两个类的文件头需互写交叉注释。
>
> **2026-07-05 难点补注**：① **阻塞期心跳**——`fleet_start_member_run` 挂起期间每 15s 向 CLI stdout 侧写一行进度注释（部分 CLI 对 180s 静默 tool call 判死）；② **重启恢复**——in-flight blocking call 在应用重启后不可恢复原 promise，统一落 `RUN_TIMEOUT_PENDING_REPORT` 语义：CLI 拿 runId 用 `fleet_get_run_report` 补取，恢复逻辑以此为准；③ **Bridge loopback token**——每 session 生成、只绑当前 workspace scope、进程退出即失效、不落磁盘明文；泄漏处置 = revoke session token 即断。

## ① 一句话闭环
一套脊柱支撑三种编排模式——群聊（人在环，默认）/ TeamRun 受控（CLI 队长经 Fleet Bridge 同步阻塞调 API 队员）/ DAG（可选静默批处理）——所有指派、权限、成本、报告都带完整 `attributionChain` 回 Fleet timeline，外部黑盒 CLI 以为调了同步工具，内部实为可暂停/可授权/可恢复的异步 TeamRun。

## ② 现状（代码已核对 2026-07-04）
- ✅ `team-run.ts` 冻结：`AgentSeat`/`RuntimeLane`/`TeamRun`/`RunReport`/`AttributionChain`/错误码/`TeamRunCost(六值)`/`FLEET_BRIDGE_TOOLS`(8 个固定工具)。
- 🟨 `team-run-coordinator.ts`：propose/startRun/getStatus/getReport/cancel/submitReport 状态机全；`startRun` 走真实 `SessionManager.sendMessage` 投递（不假 running）；`startRunAndWaitForReport` + `teamRun:startRun({waitForReport:true})` 有 blocking await / `timeout_pending_report` 骨架；`teamRun.invokeAction` 接 `InternalActionExecutorService`（仅 L0/L1，L2/L3 结构化拒绝）；`workspaceFileLeases` 接 lease manager。
- 🟨 ACP CLI `session/new.mcpServers` 能注入 Fleet Bridge MCP，`session-mcp-server` 暴露 `fleet_*` 工具经 loopback callback 调 TeamRun。
- ⛔ **真实 CLI Bridge tool 端到端 smoke、成员报告自动归集、逐工具 timeline（native hook）、permission UI 未完成**。所有 one-shot adapter `bridgeInjection='not-supported'`——**当前没有一个真实 CLI 能经 Bridge 调 API 队员**。这是本闭环要打通的核心。

## ③ 目标态（三模式一套脊柱）
1. **群聊模式（默认 · D16）**：会话即 Agent，显示模型/runtime 图标 + 稳定序号；「队长」标签切换队长；有队长后显示团队群聊，`@Agent` 私发、不 @ 广播。身份扩展原 `labels/config.json` + session `labels`（规则 32），不建第二套。
2. **TeamRun 受控模式（D19 · 本波次重点）**：Fleet Bridge 固定 8 工具（不动态生成成员工具）；`fleet.start_member_run` 对外**同步阻塞**（默认 `maxBlockMs=180000`），内部异步调度 API 队员；完成回压缩 `RunReport`（changedFiles/diffSummary/evidenceRefs/cost，不回完整会话）；超时回 `RUN_TIMEOUT_PENDING_REPORT`；权限拒绝回 `USER_PERMISSION_DENIED_FINAL`（CLI 必须停）。
3. **DAG 模式（吸收方案 B · M2+ 可选）**：把「录制好的 Workflow Trace」（蓝图 07/记忆飞轮产出）编成明确的有向流水静默重放，用于可重复批处理。**不取代**群聊；无队长时也可跑；是编排的第三选项，不是唯一。
4. **状态机**：`proposed→approved→queued→running→blocked_waiting_for_{permission,user,lease}→completed/failed/cancelled/timeout_pending_report`，每步写 event 带 `runId/agentSeatId/runtimeLaneId/attributionChain/evidenceRefs`。
5. **权限链**：`user → G-01 leader/cli:codex → fleet.start_member_run → G-02 designer/api → canvas.edit`，结构化错误码，L2/L3 冷却防弹窗循环。
6. **编译/Linter死循环程序化防御 (Linter Loop Prevention)**：系统级监控 Executor 执行过程。若同一 Executor 对同一文件的同类型编译/Linter 错误连续修复失败 3 次，运行系统自动熔断，强制标记该 Run 状态为 `failed_recoverable` 并抛出 `3_STRIKE_LINTER_CIRCUIT_BREAKER_TRIPPED`，禁止继续消耗 Token。
7. **模式切换物理锁 (Mode Gating Lock)**：运行时强制执行 Plan/Execution 物理状态控制。当 Session 进入 `Plan` 模式时，底层系统程序化封锁所有写相关 RPC（如 `files.write`）与 `WorkspaceFileLeaseManager` 的 write 租约申请（快速拒绝并返回 `ERROR_PLAN_MODE_READ_ONLY_CEILING`），将 Prompt 的软性约束升级为运行底座的物理屏障。

## ④ 前端（挂点/组件/字段/页面）
- **沿用**：craft 会话列表/聊天/labels/permission/timeline，**不建孤岛多 Agent 页**（规则 31）。
- **会话列表**：`AgentSeat + lane badge`（`G-01 队长 · API 控制 / Codex CLI 执行中`）。
- **群聊 timeline**：只显示任务卡 / 权限卡 / 报告卡 / 证据引用；完整细节留成员 session 抽屉。
- **权限卡**：展示 `attributionChain` 全链 + 风险等级 + 写目标 + 成本来源（六值，接蓝图 01）。
- **成员抽屉**：API 队员完整执行细节、diff、证据、回滚。
- **编编模式选择**：创建任务时选 群聊/TeamRun/DAG（不在运行中乱切，00 §1.3）。
- **错误展示**：结构化错误码 + 原因 + 下一步。

## ⑤ 后端（协议/服务/RPC/事件）
- **协议**（已冻，只读，改则回 Lead）：`team-run.ts` 全部。
- **服务（本波次核心）**：
  - **Fleet Bridge 同步阻塞 smoke**：选一个真实 CLI（Codex 或 Claude Code / 或已通的 ACP runtime）注入固定 Bridge 工具 → `fleet.start_member_run` → API 队员执行 → 压缩 `RunReport` 回 CLI。**smoke 通了才算 D19 核心闭环。**
  - **PTY 终端快照实时文件同步 (PTY Snapshot Watcher Sync)**：后台由 xterm/node-pty 驱动的 `RuntimeLane` 会自动向 `.fleet/terminals/$session_id.txt` 输出格式化的 PTY 快照（包含 PID、CWD、最后命令、退出状态及最后 100 行输出流）。这使智能体能像读取普通文件一样低 token 地监测终端输出，取代频繁的 Bash 轮询指令。
  - 成员报告自动归集：`submitReport` 接真实 session事件，自动汇成 `RunReport`。
  - `idempotencyKey` 去重；应用重启未完成 run 恢复为 `blocked_waiting_for_user`/`failed_recoverable`；崩溃记 stderr tail/exit code/runtime/cwd。
  - **native-hook 权限桥（承接蓝图 03）**：Claude/Codex 类无 ACP 但有 hook 的 runtime，参照 omnigent `native_policy_hook.py` 结构（只学结构、重写 TS，不迁码）拦截 `PreToolUse/PostToolUse/UserPromptSubmit` → Fleet 权限服务裁决 → hook `permissionDecision/decision:block` 落地，fail-closed。ACP 类走 AionUi `AcpPermissionRequest` 结构（`allow_once/allow_always/reject_once/reject_always`）。
- **RPC**（Lead 空壳，部分已有）：`teamRun.propose/startRun/getStatus/getReport/cancel/sendMessage/invokeAction`。
- **事件**：状态机每步 + 权限 + 成本 + 报告卡。

## ⑥ Agent 工具与 permission/timeline
- CLI lane 只见 8 个固定 `fleet_*` 工具（下划线名，避免点号被拒）；不绕 permission/loadout/租约/成本账本。
- `fleet.invoke_internal_action` 仅 L0/L1；L2+ 必须走 TeamRun 或 permission。
- 结果不回 secret/完整 stdout/完整会话，用 `evidenceRefs` 指向 Fleet 内部证据。
- 管理 Agent 固定 cheap API，永不 CLI（规则 25/41）。

## ⑦ 验收矩阵
- [ ] **端到端 smoke**：真实 CLI 队长 → `fleet.start_member_run` → API 队员执行 → RunReport 回 CLI（**承重墙验收**）。
- [ ] 同步阻塞：超时回 `RUN_TIMEOUT_PENDING_REPORT` 带 runId/progress/evidenceRefs，CLI 释放 tool call 不卡死。
- [ ] 权限拒绝回 `USER_PERMISSION_DENIED_FINAL`，CLI 停止该分支；同链 L2/L3 冷却生效。
- [ ] 租约冲突 run 进 `blocked_waiting_for_lease`（接蓝图 05）。
- [ ] 群聊 `@Agent` 私发/广播正确；身份扩展原 labels 不建第二套。
- [ ] 成员报告自动归集成 RunReport，群聊只显示卡片、不泄完整会话。
- [ ] attributionChain 全链展示；成本六值来源正确。

## ⑧ 并行边界
- **文件所有者**：`team-run-coordinator.ts`、`handlers/rpc/team-run.ts`、`session-mcp-server` 的 `fleet_*`、native-hook 桥服务、群聊/权限卡/成员抽屉组件。
- **只读依赖**：`team-run.ts`（承重墙）、蓝图 03 的 ACP Bridge 注入链路（前置）、蓝图 05 的 lease manager 契约、蓝图 01 的成本来源。
- **回 Lead 加**：新错误码/字段、`teamRun.*` RPC、i18n。
- **波次**：Wave 2 起（承接 03 的 ACP 注入）；Bridge 同步阻塞 smoke 是**全项目最高优先级**，先于蓝图 02 的 Fusion/缓存增强。

# 03 · CLI Runtime 与终端闭环

> **主 Agent 工作包**。上游裁决见 `00-蓝图总纲 §1`。对应决策 D3(首攻)、D19；协议 `cli-runtime.ts` + `team-run.ts` 已冻结。
> **红线**：本机能力默认 `LOCAL_ONLY`（规则 14）；不自研 Claude Code 克隆，只做 adapter/bridge（规则 41）；启动 CLI/写配置/改 PATH 走 permission+timeline（规则 16/28）；不静默改用户全局 CLI 配置。
>
> **⚠ 2026-07-05 修订 · D29 人机统一 PTY（本篇最大变化，采纳 EVAL-01 §0）**：
> - **裁决**：`@lydell/node-pty`（跨平台 prebuild、无 node-gyp）取代 Python `terminal_pty_host.py`，**人和 Agent 共用同一条 PTY 会话**：人敲键走 xterm 前端，Agent 走 `terminal.run_command` internal action 写入同一 PTY，输出经 `@xterm/headless` 解析回 SessionEvent；终端会话 = 一条 `RuntimeLane`，命令进 permission（L2）+ timeline + 可选 lease。Python host 在 smoke 通过前保留为回退，不再扩功能。
> - **并发写序（难点）**：PTY 同刻只允许一个"写主"——人正在输入（自上次 keypress <2s）时 Agent 命令**排队**并在终端条提示"Agent 待执行：<cmd>"；人可回车放行或 Esc 拒绝；Agent 长命令执行中人侧输入被缓冲提示。所有仲裁写 timeline。
> - **输出回传截断**：`@xterm/headless` 解析按 4KB/事件分片，超 64KB 折叠为 evidenceRef（完整输出落 session 文件），防 timeline 爆炸。
> - **平台矩阵**：mac/Linux=forkpty，Windows=ConPTY（node-pty 内建）；三平台实机 smoke 是验收项。
>
> **native-hook 逐 runtime 策略表（补 REVIEW-07-04 §2.1，对标本地 omnigent 成套 hook，只学结构、重写 TS，不迁 Python 码）**：
>
> | Runtime | 对标文件（源码参考/software/omnigent） | 拦截点 | 注入方式 |
> |---|---|---|---|
> | Claude Code | `claude_native_hook.py` | PreToolUse/PostToolUse/UserPromptSubmit → `permissionDecision` | settings.json hooks（workspace-local） |
> | Codex | `codex_native_hook.py` | exec 前策略钩子 → decision:block | config.toml 注入（temp profile） |
> | Cursor | `cursor_native_permissions.py` | 权限回调 | 局部配置 |
> | Qwen | `qwen_native_permissions.py` | 同上 | 局部配置 |
> | Hermes | `hermes_native_permissions.py` | 同上 | 局部配置 |
> | 其余 | — | 无 hook 面 → `bridgeInjection:'not-supported'`，只 one-shot | — |
>
> 全部 fail-closed：hook 回调超时/失联 = 拒绝执行该工具调用。每个 runtime 的拦截点需对着 omnigent 对应文件 + 真实 CLI 实机验（PLAN §1.4）。

## ① 一句话闭环
把终端从「底部卡片」升级为**一等面板**（可多开、进 grid、与 API 队员并排），普通对话目标态只走 API、CLI 只从 `surface='terminal'` 创建；每种外部 CLI 有明确的 `RuntimeLauncherAdapter`（启动/Bridge 注入/清理/诊断），为蓝图 04 的跨 Runtime 编排提供受控执行面。

## ② 现状（代码已核对 2026-07-04）
- 🟨 `apps/electron` 已有 `TerminalPanel.tsx` 一等面板；`routes.action.newSession({surface:'terminal'})` → `routes.view.terminal(id)` → `PanelSlot` 渲染 xterm PTY，持久化 `surface`；`Cmd+J` 已走同一路径；旧 `BottomTerminalPanel` 已删。
- 🟨 `surface='chat'` 已隐藏 CLI picker（`FreeFormInput` 按 surface 条件渲染）。
- 🟨 `server-core/services/runtime-launcher-adapter.ts`：接口 + registry + `NativeOneShotRuntimeLauncherAdapter`（真启动 one-shot，返回 pid/startedAt/stderrTail/version/bridgeStatus）。ACP runtime 标 `launchMode='stdio-acp'`、`bridgeInjection='mcp-config'`，`CliRuntimeHost` 持进程并把 Bridge MCP 传进 `session/new`。
- ⛔ PTY launcher、native-hook 注入、长会话 cleanup、真实 ACP CLI smoke 未做。所有 one-shot adapter `bridgeInjection='not-supported'`，不能当队长。

## ③ 目标态
1. 终端一等面板：多开、进 grid、会话列表显示 `AgentSeat + lane badge`（如 `G-01 队长 · API 控制 / Codex CLI 执行中`）。
2. `RuntimeLauncherAdapter` 矩阵按 §8.3 落地：ACP 类（Goose/OpenCode/Hermes/Custom/Kimi）走 stdio-ACP + mcp-config Bridge；Codex/Claude/Grok/Antigravity/Pi/Cursor 先 one-shot「CLI 单跑」；未接 adapter 的只检测诊断。
3. 每种 runtime 的 `bridgeInjection` 明确区分 `mcp-config`/`env`/`args`/`native-hook`/`not-supported`（native-hook 为蓝图 04 的 Claude/Codex hook 拦截预留）。
4. Bridge MCP 用 loopback + 短期 token，仅当前 workspace/session scope；远端 workspace 标 `LOCAL_ONLY` 不启本机 Bridge。

## ④ 前端（挂点/组件/字段/页面）
- **沿用**：`TerminalPanel.tsx`、`PanelSlot`、会话列表、`FreeFormInput`。
- **会话列表**：加 lane badge（seat role + runtime + 状态）。字段来源 `AgentSeat` + `RuntimeLane`。
- **终端入口**：`TopBar` 终端按钮 / `Cmd+J`（已有），**不恢复底部卡片**。
- **PTY 挂起**：检测 stdin 等待时自动高亮并露出终端，不静默卡死（前端事件 + 高亮态）。
- **设置页 · CLI Runtime**：每个 runtime 显示 binary 路径/版本/登录态/`bridgeStatus`（available/unavailable/`团队队长`/`CLI 单跑`）+ 诊断 stderr tail。数据来自 launcher `diagnostics`。
- **错误展示**：显示结构化错误码（`BRIDGE_UNAVAILABLE`/`MCP_LAUNCH_FAILED`…）+ 原因 + 下一步，不显示 generic error。

## ⑤ 后端（协议/服务/RPC/事件）
- **协议**（已冻，只读）：`cli-runtime.ts`、`team-run.ts` 的 `RuntimeLane`。`RuntimeLauncherAdapter` 契约字段：`runtimeId / launchMode / bridgeInjection / configWriteScope / cleanup / diagnostics`。**新增** `bridgeInjection` 枚举值 `'native-hook'` → 回 Lead 加。
- **服务**：
  - 补 ACP launcher 真实 smoke：拉起一个真实 ACP CLI，注入 Fleet Bridge MCP，验证 `fleet_*` 工具可见（为蓝图 04 铺路）。
  - **Node.js 运行时 Native Hook 拦截规范 (Node Native Hook Intercept Spec)**：对于 Claude Code 和 Codex 等带 Hook 但无 ACP 的 CLI：
    - **拦截器注入**：由 Fleet 在会话启动时生成临时的 `fleet-claude-hook.js` 脚本，并通过 `~/.claude/settings.json`（或项目级 `.claude/settings.json`）的 `commands-hook` 进行注入。
    - **Payload 校验与返回协议**：该脚本读取 stdin 的 hook JSON：
      - `PreToolUse` (工具执行前门禁)：解析 `tool_name` 与 `tool_input` 并发往 Fleet 权限决策服务。若判定拦截，返回 `{"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny", "reason": "Fleet Policy Intercepted"}}`，且退出码为 0，迫使 CLI 终止命令。
      - `UserPromptSubmit` (命令提示词门禁)：解析 `prompt`。若拦截，返回 `{"decision": "block", "reason": "Fleet Blocked"}`，退出码 0，丢弃该 prompt。
      - `PostToolUse` (后置观测)：如果发现敏感写操作被绕过，返回带有警告的 `additionalContext` 指引。
  - PTY launcher（长会话）+ cleanup（退出删临时 config/token/loopback bridge）。
  - 统一走 System Tools / Project Environment registry 探测 PATH/版本（规则 28），不各模块私探。
- **RPC**（Lead 空壳）：`cliRuntime.list/test/launch/diagnostics`（`LOCAL_ONLY`）。
- **事件**：启动/停止/崩溃写 timeline（runtime/launcher/cwd/exit code/stderr tail/配置写入范围/清理结果）。

## ⑥ Agent 工具与 permission/timeline
- 探测/诊断可无 UI 自动执行；**启动 CLI、写配置、改 PATH、改全局 MCP 设置**必须 permission + timeline（规则 16/28）。
- 写全局配置走 L2/L3 且可回滚；优先 temp-session / workspace-local 配置。
- 管理 Agent 永不走 CLI（规则 25/41）。

## ⑦ 验收矩阵
- [ ] `surface='chat'` 无 CLI picker；CLI 仅从 terminal surface 创建；新建终端进「所有会话」。
- [ ] 一个真实 ACP CLI 能被拉起且 `fleet_*` Bridge 工具可见（smoke）。
- [ ] Claude Code 真实 CLI 在 Hook 触发时被 `fleet-claude-hook.js` 拦截，在 `PreToolUse` 下返回结构化 `permissionDecision: deny` 且阻止命令执行（smoke）。
- [ ] one-shot runtime 显示「CLI 单跑」，不暴露团队工具；ACP runtime 达标后显示「团队队长」。
- [ ] 设置页显示每 runtime 的诊断（路径/版本/登录态/bridgeStatus）。
- [ ] PTY stdin 等待被前端检测并高亮。
- [ ] 不安装 CLI 时默认 CI 不被阻塞（smoke opt-in，规则见 docs/38 §11）。

## ⑧ 并行边界
- **文件所有者**：`server-core/services/runtime-launcher-adapter.ts` 及新增 launcher、`CliRuntimeHost`、`TerminalPanel.tsx`、CLI Runtime 设置页组件。
- **只读依赖**：`cli-runtime.ts`、`team-run.ts`（承重墙）。
- **回 Lead 加**：`bridgeInjection: 'native-hook'` 枚举、`cliRuntime.*` RPC、i18n。
- **交接给 Wave 2**：ACP Bridge 注入链路是蓝图 04 Fleet Bridge 同步阻塞 smoke 的前置；完成后移交 04 的 B1 Agent。
- **波次**：Wave 1，与 01/05 并行。

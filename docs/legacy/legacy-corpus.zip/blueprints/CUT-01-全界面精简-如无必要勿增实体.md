# CUT-01 · 全界面精简：如无必要，勿增实体

> **⚠ 2026-07-05 修订（两条）**：① **messaging 决断撤销**——D28 用户拍板保留 Telegram/WhatsApp：§5 表中 `MessagingSettingsPage 删整页+删功能` 一行作废，设置恢复显示，§7 执行记录 #2 的 messaging 隐藏需回滚（server 隐藏维持）；能力归属见 `蓝图/09-messaging闭环`。② 本文其余决断在 **D27-R（Craft 原壳保留+缩减）**口径下全部有效且升格为 U 轨执行表（见 `蓝图/00 §4`、`UI-01 §2`）。
> **原则**：如无必要，勿增实体（Occam）。每个模块/按钮/设置项只问一句——**删了它，产品会坏吗？** 不会 → 删或收起。
> **方法**：先看全，再决断。本文是对**整个界面**的实体必要性审计 + 决断清单，配合代码直接删改（已开始执行，见 §5 执行记录）。
> **代码事实（已核对）**：`app-shell` 68 个组件、输入区 49 个交互元素+一堆选择器变体、设置 18 页共 6940 行、AppShell 3777 行含重型 session 过滤机器。这就是"功能复杂、按钮多、很多没必要"的量化证据。

---

## 1 · 判断标尺（每个实体过这三问）

| 问 | 删 | 留 |
|---|---|---|
| ① 产品核心流程离了它就断吗？ | 否→删 | 是→留 |
| ② 它是否与别处重复（同一职责第二套 UI）？ | 是→删重复的 | 否 |
| ③ 它是否高频到值得常驻/值得单独设项？ | 否→收进菜单或删设项 | 是→留 |

> 特别地：**任何"变体组件"（Compact*、第二套 Menu）默认是重复实体**，除非能证明基础组件无法覆盖该场景。

---

## 2 · 顶栏（TopBar）：按钮从一排砍到 3 个

**现状**：右侧一排 = BrowserTabStrip + tool-dock 模块按钮×N + 上下文侧栏开关 + 新建终端 + 新建会话面板 + 新建浏览器面板。左侧 = 侧栏开关 + 菜单 + 后退 + 前进 + workspace pill + 加 workspace。

| 实体 | 决断 | 理由（三问） |
|---|---|---|
| 新建会话面板按钮（SquarePen） | **删** | ②多面板并排是被 D27 废弃的模型；新建走统一 [+新建] |
| 新建浏览器面板按钮（Globe） | **删** | 同上；浏览器改为画布节点（UI-02），不在顶栏单开 |
| tool-dock 模块按钮×N | **删/收** | ③低频；Tool Dock 整体废弃（见 §4），能力入口进画布/左栏 |
| 上下文侧栏开关 | **移** | 合进"全部文件"栏的显隐，不单占顶栏按钮 |
| 后退/前进 | **收** | ③低频；drill-in chevron + 手势已覆盖，桌面保留但降级 |
| 加 workspace（FolderPlus） | **并** | 并进 workspace pill 的下拉，不单列按钮 |
| onToggleBottomTerminal/isBottomTerminalVisible props | **已删** | ①死 prop，无人传（§5 已执行，typecheck 通过） |
| 新建终端按钮 | 留 | ①终端一等入口（但也可并进 [+新建]▾） |

**顶栏目标**：`[侧栏] [菜单] · workspace pill ·  … · [+新建▾]`。一排 8+ 按钮 → 3 个。

---

## 3 · 输入区（FreeFormInput）：从 49 个交互元素砍到必要

**现状**：模型选择器（+Compact 变体）、权限模式选择器（+Compact）、来源选择器×3（+Compact）、工作目录选择器×3（+Compact）、Vision 开关、CLI 下拉、提及菜单……49 个交互元素。

| 实体 | 决断 | 理由 |
|---|---|---|
| 模型选择器 `ModelDropdown/ModelButton` | 留（唯一处） | ①核心；但**全 App 只此一处**（去重矩阵），删别处所有模型选择 |
| `CompactModelSelector` 等所有 Compact 变体 | **删** | ②变体=重复；用 CSS/响应式让基础组件覆盖窄屏，不养第二套 |
| 权限模式选择器 | **收** | ③默认 ask 就够；把 L0-L3 细选收进"更多"，不常驻 |
| 来源选择器（Source ×3） | **并为1** | ②三个变体合一；来源选择低频，收进 [+] 附件菜单 |
| 工作目录选择器（×3） | **并为1** | ②同上；空态选一次即可，不必每条消息都显示 |
| Vision 开关 | **删显式开关** | ③自动按模型能力判定，不给用户手动开关（无必要设项） |
| CLI 下拉 | **收** | 只在 terminal surface 出现，chat 不显示（surface 分离，D19） |
| ToolbarStatusSlot / ContextBadge | **精简** | 状态类最弱视觉，不占主行 |

**输入区目标**：一行 = `[+附件] [Agent角色▾]  文本  [模型▾] [🎙] [↑]`。选择器从 ~10 类 → 3 个，Compact 变体全删。

---

## 4 · 主外壳模块：删掉整块非必要

| 模块 | 决断 | 理由 |
|---|---|---|
| **BottomTerminalPanel**（+state+storage+layout math） | **删整块** | ②与一等 `TerminalPanel` 重复；文档早说删了但代码还在（活重复），只留 TerminalPanel |
| **Tool Dock**（ToolDockFilesModule/DocumentPreview/config/layout/useWorkspaceToolDock） | **删整块** | ①非核心；文件走"全部文件"栏、预览走画布节点，不需要右侧 dock |
| **WorkspaceContextSidebar** | **并** | 与"全部文件/Library"职责重叠，合成一个右栏 |
| **多面板 workbench**（Panel/PanelSlot/PanelStack/PanelDragGhost/ModuleResizeSash/WorkbenchModuleFrame/CraftModulePanel） | **大幅收** | D27 单自适应工作面；不需要拖拽多面板并排的整套机器（专业工作面用画布，不用 panel 网格） |
| **session 过滤机器**（16×FilterMenuRow/ViewFiltersMap/FilterModeSubMenu/FilterLabelItems/AltExcludeTooltip） | **大幅砍** | ③过度设计；会话列表一个搜索 + 三状态（进行/待审/完成）足够，删多级 label 过滤子菜单 |
| Compact* 全家桶（CompactSessionMenu/CompactSessionListFilter/CompactWorkspaceSwitcher/CompactPanelTransition） | **删** | ②响应式覆盖，不养移动端第二套 |
| MultiSelectPanel / BatchSessionMenu | **收** | ③批量操作低频，收进右键菜单 |
| FabNewChat | **删** | ②与 [+新建] 重复 |
| SendToWorkspaceDialog + SendResourceToWorkspaceDialog | **并为1** | ②两个几乎一样的对话框 |

---

## 5 · 设置：18 页 6940 行 → 6 分区，删掉整页

> 已做：注册表分组为 6 桶 + 隐藏 messaging/server（§已执行，typecheck 通过）。下面是**进一步删整页/删设项**。

| 设置页 | 行数 | 决断 | 理由 |
|---|---|---|---|
| MessagingSettingsPage | 880 | **删整页 + 删功能** | ①Telegram/WhatsApp 非 Fleet 范围（D26 无账号无推送生意）；连同 messaging-gateway 后端一起退役 |
| ServerSettingsPage | 298 | **删/隐藏** | ①嵌入式服务器非默认用户需要 |
| AiSettingsPage | 1289 | **拆+瘦** | ③1289 行必然堆了大量低频项；只留 API 连接(BYOK)，其余移或删 |
| LabelsSettingsPage | 166 | **删设项** | ③多级 label 体系配合 §4 过滤机器一起砍 |
| InputSettingsPage | 131 | **并入外观** | ③输入偏好不值单页 |
| PreferencesPage | 278 | **并入外观** | ②与 Appearance 心智重叠 |
| WorkspaceSettingsPage | 566 | **瘦** | 只留必要，去重 |
| ManagerSettingsPage | 308 | **瘦** | 管理 Agent 边界项，去低频 |
| PermissionsSettingsPage | 329 | **收** | 默认策略一处，去逐项开关 |

**Vision 开关、逐页 Fusion 开关、各种显隐开关**：全删（自动判定或进快捷键）。

---

## 6 · 一句话目标

**顶栏 8+按钮→3，输入区 10+选择器→3、Compact 变体全删，主外壳删掉 BottomTerminal/ToolDock/多面板机器/过滤机器/Compact全家桶，设置 18 页→6 分区并删 messaging/server 整页。** 全程 typecheck 守护，删一块验一块。

---

## 7 · 执行记录（代码 · 边删边验）

| # | 动作 | 文件 | 验证 |
|---|---|---|---|
| 1 | 删 TopBar 死 prop onToggleBottomTerminal/isBottomTerminalVisible | `TopBar.tsx` | ✅ typecheck 0 err |
| 2 | 设置注册表分 6 组 + 隐藏 messaging/server | `settings-registry.ts`/`menu-schema.ts`/`SettingsNavigator.tsx`/7×locale | ✅ typecheck 0 err |
| … | （下列按 §2-§5 顺序执行，每步记录） | | |

> 纪律：本会话无 bun 不能跑应用，只能 typecheck。**删除类改动逐个 typecheck；涉及 AppShell 大改（删 BottomTerminal/ToolDock/多面板）风险高，按小步提交，每步验证不破坏类型闭包。**

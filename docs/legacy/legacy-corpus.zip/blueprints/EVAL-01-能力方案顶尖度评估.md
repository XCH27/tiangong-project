# EVAL-01 · 能力方案顶尖度评估（不是删UI，是评"方式对不对"）

> **评估口径（用户升级的标尺）**：
> 1. **双向可调**：每个功能必须 **Agent 和人共同可调用**，且**都真需要**。人能做 Agent 不能做（或反之）= 坏的，不是完成。
> 2. **方式最顶尖**：不只看功能在不在，要评**实现方式**是否最好/最稳/最快/最适合团队编排。
> 3. **不为删而删**：增/减/移/并都要论证；砍掉的必须真无必要，保留的必须真需要且双向可调。
> **本文只评方案对错，配合 CUT-01（UI 精简）、BUILD-01（补全）一起看。**

---

## 0 · 头号结论：终端连接方式**不是最顶尖的**，且违反"双向可调"

### 0.1 代码事实（已核对）
- 人用终端 = `interactive-terminal-ipc.ts` 起一个 **Python PTY host 脚本**（`terminal_pty_host.py`），Electron IPC 桥接。
- 该脚本自己注明：非 Unix 平台 `PTY is not supported on this platform` → **Windows 直接不支持**。
- 脚本注明选 Python 而非 `node-pty` 的理由：**只为省掉 node-gyp 原生编译**。
- 最关键：注释明说「**Agent 命令执行不走这里**」——人用 Python PTY，Agent 走 ACP/CLI Runtime，**两条完全分离的路**。

### 0.2 为什么这不顶尖（逐条对标尺）
| 标尺 | 现状 | 问题 |
|---|---|---|
| **双向可调** | 人走 Python PTY，Agent 走 ACP，**两套** | ❌ 违反"同一功能 Agent+人共调"。同一个终端会话，人敲的和 Agent 跑的进不了同一条 PTY/同一条 timeline |
| 最稳 | Python stdlib `pty`，Unix-only | ❌ Windows 不支持；跨平台不稳 |
| 最快 | 多进程 + base64 over JSON over IPC | 🟨 base64+JSON 每字节编解码，长输出有开销；node-pty 直接二进制流更快 |
| 最适合团队编排 | 人终端与 Agent lane 割裂 | ❌ 团队编排要求"队长在终端里做的事 = 一条可授权可回放的 lane"，现在人终端根本不进 TeamRun/permission/timeline |

### 0.3 最顶尖的做法（对标本地参考）
本地参考里**最好的终端栈已经在仓库**：
- `opencode`：`@lydell/node-pty 1.2.0-beta.12`（node-pty 的活跃 fork，跨平台 prebuild，无需 node-gyp——**恰好解决了 Python 方案想规避的编译问题，且不牺牲跨平台**）。
- `Kun`：`node-pty ^1.1.0` + `@xterm/xterm ^6` + `addon-fit` + `addon-web-links`（完整的 xterm 前端栈）。
- `oh-my-pi`：`@xterm/headless`（无头 PTY，适合 Agent 侧解析终端输出）。

**建议的顶尖架构（统一一条 PTY，人和 Agent 共用）**：
```
                ┌── 人敲键 (xterm 前端) ──┐
一条 PTY 会话 ──┤                          ├── 同一条 node-pty 进程
(node-pty)      └── Agent 命令 (internal   ┘   同一条 timeline / permission / lease
                     action terminal.run)      → 进 TeamRun lane, 可授权可回放
                @xterm/headless 供 Agent 解析输出
```
- **PTY 层统一**：`@lydell/node-pty`（跨平台、无 gyp、快），替代 Python host。人和 Agent **同一条 PTY 会话**。
- **前端**：`@xterm/xterm` + `addon-fit`（现在 `TerminalPanel` 已用 xterm，保留）。
- **Agent 侧**：`terminal.run_command` internal action 写入**同一条 PTY**，输出经 `@xterm/headless` 解析回 SessionEvent；命令执行进 permission（L2）+ timeline + 可选 lease。
- **团队编排**：终端会话 = 一条 `RuntimeLane`（terminal lane），队长在终端做的每条命令都可归入 attributionChain、可回放。这才让"终端"成为团队编排的一等公民，而不是人类私有的黑盒。
- **ACP CLI**（Goose/Codex 等外部 harness）仍走各自 ACP/stdio，不变——那是"外部 CLI harness lane"，与"本机人机共用终端 lane"是两类，但都统一到 RuntimeLane 抽象下（D19）。

> 这条改造是**架构级**，属承重墙，需在有 bun 的环境做 + 实机 smoke（node-pty 是原生模块，必须真机验 Windows/mac/Linux）。本会话不盲改，但**评估结论明确：现终端方案应换成 node-pty 统一人机 PTY，这是团队编排顶尖度的关键前置**。

---

## 1 · 双向可调审计（每个功能：Agent 能调吗？人能调吗？都需要吗？）

> 规则：✅✅=双向齐、真需要（留）；🟨=一侧缺（补齐，不删）；❌=某侧多余或整体没必要（评估删/合）。

| 功能 | 人可调 | Agent 可调 | 都需要? | 结论 |
|---|---|---|---|---|
| 发消息/对话 | ✅ | ✅（Agent 是对话主体） | 是 | ✅✅ 留 |
| 模型选择 | ✅ picker | 🟨 路由自动，但 Agent 不能显式"换模型" | 是 | 留；**补** Agent 侧 `routing.select` 动作，双向齐 |
| 终端命令 | ✅ 敲键 | 🟨 走分离 ACP，不进人终端 | 是 | **改**（见 §0）统一 PTY，双向进同一条 |
| 文件操作(增删改移) | ✅ UI | ✅ internal action | 是 | ✅✅ 留（确保走同一 action id） |
| 记忆 增删查 | ✅ 设置页 | 🟨 Agent 读注入，但写/删候选未接线 | 是 | 留；**补** Agent 侧记忆写/蒸馏（BUILD-01 §B） |
| 能力装载/商城 | ❌ 无 UI | ❌ 无 catalog | 是 | **补全栈**（BUILD-01 §A），双向可调 |
| 浏览器标注 | 🟨 基建在 | 🟨 DesignAction 未接 | 是 | 补（BUILD-01 §D），人框选 + Agent 也能标注 |
| 团队编排(派活/权限/报告) | 🟨 前端空 | ✅ Bridge 工具 | 是 | 补前端（BUILD-01 §C），人也能在群聊派活 |
| 画布(节点/连线/编排) | ❌ 无 | ❌ 无 | 是 | **补全栈**（BUILD-01 §F），人拖 + Agent canvas_* |
| 权限模式细选(L0-L3 每项) | ✅ 一堆开关 | — | 否(过细) | **收**：默认 ask，细项收起（人调即可，非高频） |
| Vision 开关 | ✅ 手动 | — | 否 | **删**：按模型能力自动判定，人和 Agent 都不需手动 |
| 多面板拖拽布局 | ✅ | — | 否 | **删**：Agent 不需要、人也用不上（D27 单工作面） |
| Tool Dock | ✅ | — | 否 | **删**：能力入口进画布/左栏，Agent 无此概念 |
| session 多级 label 过滤 | ✅ 复杂菜单 | — | 否(过度) | **砍**：一个搜索+三状态够，Agent 按 status 查即可 |
| Telegram/WhatsApp 推送 | ✅ 设置 | 🟨 | 否(超范围) | **删**：D26 无账号无推送生意 |

> 关键洞察：**"该删的"几乎都是"只有人单向能调、Agent 根本没有对应概念"的纯人类 UI 糖**（多面板/ToolDock/Vision开关/多级过滤）——删它们不违反双向可调，反而让"每个留下的功能都双向齐"这条线更干净。**"该补的"都是双向缺一侧**（画布/商城/记忆写/编排前端）——这些不能删，要补齐另一侧。

---

## 2 · 其它能力的方式顶尖度速评（是否有更好选择）

| 能力 | 现方式 | 顶尖度 | 更好选择 |
|---|---|---|---|
| 画布引擎 | 未建 | — | 本地 `tldraw`（已确认，UI-00 §8）——顶尖，直接用 |
| 设计节点引擎 | design-engine(patch/rollback) 在 | 🟨 | openpencil vs **penpot** 对照（penpot 更接近 Figma 级，REVIEW §2.2） |
| 记忆检索 | TF-IDF + 3gram | 🟨 够用非顶尖 | 向量召回，对标本地 `CowAgent` embedding（BUILD-01 §B） |
| CLI 权限细粒度 | ACP 请求/无 hook | 🟨 | omnigent 逐 runtime native-hook（本地成套，REVIEW §2.1） |
| 外部审查/生图 | external-job 已实 | ✅ | 方式对，补前端即可（BUILD-01 §G） |
| 路由 | 两轴+缓存 | ✅ | 方式对；本地算力候选可加（蓝图02） |
| SessionManager | 9.6k god-object | ❌ 工程债 | 端口化，对标自家 TeamCoordinator（REVIEW §1） |

---

## 3 · 修正后的行动纪律（回应"不要为删而删"）

1. **删之前先过双向可调表**：只删"单向人类糖 + Agent 无此概念 + 非高频"的（§1 已逐条判定）。
2. **补 > 删**：双向缺一侧的一律补齐，不删（画布/商城/记忆写/编排前端/浏览器标注）。
3. **方式不顶尖的先评估再改**：终端(node-pty 统一)、记忆(向量)、CLI 权限(native-hook)、SessionManager(端口化)——都是架构级，需 bun 环境 + 实机验，不在无 bun 沙箱盲改。
4. **每个留下的功能**：确保 Agent 和人走**同一个 action id / 同一条 timeline**（D7/D14），不是两套实现。

---

## 4 · 一句话
**头号问题不是按钮多，是终端把人和 Agent 劈成两条路、且用 Unix-only 的 Python PTY——这既不双向可调也不跨平台，不适合团队编排。最顶尖做法是 node-pty 统一一条人机共用 PTY、并入 RuntimeLane/permission/timeline。UI 该删的恰好都是"只有人能调、Agent 无此概念"的糖，删它们让双向可调更纯粹；双向缺一侧的（画布/商城/记忆写/编排前端）一律补齐不删。**

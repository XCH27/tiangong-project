# 07 · 省 Token / 上下文效率 / 外部审查中心闭环

> **主 Agent 工作包**。上游裁决见 `00-蓝图总纲 §1`。对应决策 D9；细节权威 = 旧 `docs/16-上下文效率与外部AI审查方案.md`。
> **红线**：一个中心、一条管线、一份成本账本，不是七个散按钮（规则 24/29）；真实 token / 估算节省 / 外部平台成本**必须分开**，「不消耗 Fleet API token」≠「免费」；外部网站只用用户授权登录态和正常交互，不自动注册/不读 cookie/token/不绕验证码额度（规则 21/22 / D23）；Repomix/MarkItDown/Headroom/OpenHands 未绿灯前只做 optional sidecar/黑盒参考。

> **2026-07-05 修订**：**半自动降级流升为一等路径**——目标 AI 网站出现反自动化/验证码/风控时，管理 Agent **不重试对抗**（规则 22），自动降级为：打开该平台 tab → 预填打包内容与审查 prompt → 高亮提示用户手动点击发送 → 用户送出后 Agent 继续收割返回并归一化。UI 上两条路径同卡呈现（"自动提交 ✓ / 需要你点一下 ⚠"），成本与留痕规则不变。失败不算错误态，算预期分支。

## ① 一句话闭环
把「省 token、项目打包、格式转换、代码图谱、上下文压缩、用量可视化、外部 AI 多平台审查、成本/隐私提示」合成**一条管线的一个中心**：输入整理 → 上下文压缩 → 用量可观测 → 外部审查 → 归档/成本，由**管理 Agent**统一驱动，项目 Agent 只提需求和消费报告。

## ② 现状（代码已核对）
- ✅ `shared/protocol/usage.ts`：`UsageSource`(provider/runtime/local-metered/estimated/unknown) + `PlanUsage` + 四本账结构。
- 🟨 Token 环 session 用量 usable；usage RPC 部分。
- ⛔ 打包/压缩/codegraph/外部审查多为候选 sidecar 或未落地。

## ③ 目标态（一条管线）
```
输入整理 ─▶ 上下文压缩 ─▶ 用量可观测 ─▶ 外部审查 ─▶ 归档/成本
Repomix式打包  rtk压输出     Usage/Token环   用户授权登录态   ReviewReport
MarkItDown转换 codegraph替整文件 真实/估算/未知  多平台提交       Fleet数据目录
secret scan   Reasonix稳定前缀  三色区分       每次外发权限卡   成本/隐私可审计
      └──────────── 管理 Agent 统一驱动 ──────────────┘
```
1. **打包**：当前 git repo / 改动 / 目录 / 文件 / 会话相关文件 → Markdown/XML/text/zip；自动 `.gitignore`/`.repomixignore`/secret scan/二进制过滤；显示 token count/文件数/排除项/风险。
2. **压缩**：rtk 命令输出压缩（gain/discover 统计）；codegraph 结构化图谱替整文件读取；Reasonix 稳定前缀（缓存友好）。
3. **用量可观测（四本账，统一展示不混算）**：Provider 用量 / 套餐额度（接蓝图 01 QuotaAdapter）/ Fleet 本地计量 / API 余额；优化节省（rtk/压缩/cache）是**附加对比指标，不计入已用量**避免重复扣减。
4. **外部审查**：一键打包 → 模板生成审查 prompt → 管理 Agent 在内置浏览器用**用户已授权**登录态提交多平台 → 下载/归一化成 `ReviewReport`；每次外发展示数据包摘要+secret scan+目标平台+预计成本+回滚点。

## ④ 前端
- **顶部按钮**（workspace/session 工具区）：「打包当前项目」+「提交外部审查」。
- **打包面板**：范围选择 + 输出格式 + token count/文件数/排除/风险。
- **Token 环**：上下文占比 / 输入输出 / 缓存读写 / 工具调用 / 压缩前后 / 外部审查节省估算；真实与估算分开标注（接蓝图 01 套餐分区）。
- **审查报告**：`ReviewReport` 可追踪卡（平台/bundle hash/成本/隐私/原始返回/归一化）。
- **外发确认卡**：数据包摘要 + secret scan + 目标平台 + 成本 + 可回滚。

## ⑤ 后端
- **协议**（`usage.ts`，改则回 Lead）：`UsageSource`/`PlanUsage`/四本账/`ReviewReport`。
- **服务**：ProjectPack（打包/secret scan）；压缩适配（rtk/codegraph/Reasonix 按绿灯边界，rtk 不自动装全局 hook）；`ReviewCenter`（浏览器自动化提交 + 归一化）；成本报表。
- **事件**：打包/压缩/外发/审查写 timeline，记 bundle hash/文件清单/secret scan/目标平台/权限确认/原始输出/token before-after/真实估算未知成本/回滚点（规则 21）。

## ⑥ Agent 工具与 permission/timeline
- 打包/压缩 L1（本地）；外部审查外发 L2/L3（看内容敏感度）；secret 命中强制人确认。
- 外部审查记忆写入第七分区（外发记录，敏感度最高，可审计，D2）。
- 管理 Agent 驱动整条管线，项目 Agent 不各自处理登录态/上传/隐私守门（D9）。

## ⑦ 验收矩阵
- [ ] 打包输出正确应用 ignore/secret scan/二进制过滤，显示 token count。
- [ ] 四本账统一展示但不混算；优化节省作附加指标不重复扣减。
- [ ] 外发前展示数据包摘要+secret scan+目标平台+成本+回滚。
- [ ] `ReviewReport` 归一化多平台返回、可追踪。
- [ ] 真实/估算/未知成本三色分开；「不消耗 Fleet token」不写成「免费」。
- [ ] 外部网站仅用授权登录态，无自动注册/读 token/绕验证码。

## ⑧ 并行边界
- **文件所有者**：ProjectPack/压缩/ReviewCenter 服务、打包面板、Token 环节省分区、审查报告组件、外发确认卡。
- **只读依赖**：`usage.ts`（承重墙）、蓝图 01 QuotaAdapter（四本账里的套餐账）、蓝图 06 浏览器链路（外发提交）、蓝图 05 记忆（外部审查分区）。
- **回 Lead 加**：`usage.*`/`ReviewReport` 字段、i18n。
- **波次**：Wave 3（治理面封顶，规则 29）。

# 05 · 文件、Library 与租约闭环（含 M3 幽灵补丁树）

> **主 Agent 工作包**。上游裁决见 `00-蓝图总纲 §1`。对应决策 D15、D19 §7；协议 `team-run.ts` 的 lease 字段已冻结。
> **红线**：AI 分类/移动/重命名/删除必须 permission+timeline（规则 16）；「全部文件」是 raw view，Library 是已授权/索引的资产层，两者不混；专业工作面共享同一素材仓库，不另建（规则 34）。
> **方案 B 吸收点**：内存级 Shadow Workspace（幽灵补丁树）不是「替代」物理租约，而是 M3 建在租约**之上**的优化（P6），先后关系而非替代。见 §③ 与 §⑤ 的 M3 段。
>
> **2026-07-05 修订（3 条）**：① **状态降级**——`workspace-file-lease-manager.ts` + 单测实测**未提交**（untracked），②现状的"已接入 ✅"降为 🟡 候选，先 commit 收口；② **UI 归位（D27-R 后冲突消除）**——"全部文件/Progress"就在 **Craft 原版右侧上下文栏原挂点**（D15 原义），不再受"新壳无右栏"影响；画布素材抽屉与其职责分工见 UI-02 §9；③ **`.fleet/` 数据安全通用规范（新增，本篇为归属地，各篇引用）**——所有 `.fleet/*.json` 落盘（leases/memory/loadouts/team.rules）统一：**原子写**（写 `*.tmp` → fsync → rename）；**损坏自愈**（解析失败→自动备份坏文件为 `*.corrupt.<ts>` → 从空态/最近备份重建，绝不崩进程）；**版本字段**（`schemaVersion`，向后兼容读取）；每次重建写 timeline 事件。

## ① 一句话闭环
默认工作台右侧显示「全部文件 / 当前工作区」（上方 Progress 看板、下方文件列表、可整体隐藏），Library 是其上的资产层；所有 Agent/人的写操作先拿轻量 `WorkspaceFileLease`，冲突进 `blocked_waiting_for_lease` 并在 UI 显示「谁在等谁释放哪个文件」，不并发踩文件；M3 再上内存幽灵补丁树 + 自动合并。

## ② 现状（代码已核对 2026-07-04）
- 🟨 `server-core/services/workspace-file-lease-manager.ts`：完整内存实现（TTL、read/write/git_write 冲突规则、过期清理），7 单测。已接入 `team-run-coordinator.ts` 的 `acquireWorkspaceFileLeases`——冲突发 `team_run_lease_blocked` 并阻止 dispatch。
- ✅ `team-run.ts`：`TeamRun.workspaceFileLeases` 字段 + `WORKSPACE_WRITE_LOCKED` 错误码已冻结。
- ⛔ 持久化（内存单例，重启全丢）、permission UI（租约冲突后人无感知）、CLI harness 粗粒度 `workspace:*` 租约声明、幽灵补丁树均未做。
- 🟨 「全部文件」右侧栏（D15）部分，Library 资产层未完整。

## ③ 目标态
1. **租约（M1 承重墙）**：API 队员写文件前声明 `writeTargets`；目标不明的写默认拒绝或要求确认；外部 CLI 无法精确声明时给 `workspace:*` 粗粒度租约；Git mutate 统一拿 `.git` 写锁；冲突进 blocked 不崩溃。
2. **持久化**：租约落 `<workspace>/.fleet/leases.json`；重启还原未释放的过期租约（按 TTL 清理）。
3. **UI**：冲突时 permission/timeline 显示「G-02 正在等待 G-01 释放 `src/Button.tsx`」+ 原因 + 预计。
4. **全部文件 / Library**：raw file view（按图片/MD/网页/视频/音频/PPT/代码/字体/模板过滤）+ Library 资产层（已选用/授权/索引，记来源/许可证/hash/version）。
5. **M3 增强（幽灵补丁树，吸收自方案 B）**：内存级 Shadow Workspace，写操作先落内存补丁树，冲突用补丁树三路合并替代「阻塞等待」，通过后再 apply 到物理文件。**M3 才做，M0–M2 只做租约 + 冲突拒绝**（规则 24 条件触发）。
6. **Plan Mode 租约拦截门禁 (Plan Mode Lease Intercept)**：当智能体处于 Plan 模式时，`WorkspaceFileLeaseManager` 将在底层快速拦截所有 write 类型的租约请求，禁止其获取写锁，并报错 `LEASE_DENIED_PLAN_MODE_READ_ONLY`。以此在底层杜绝 Plan 阶段静默修改文件的异常行为。
7. **租约冲突排队侦听器 (Lease Queue Listener)**：冲突队列不仅仅是挂起，租约管理器会维护一个 `blockedRunQueue` 数组。当前持有写租约的 Run 完成或被 Cancel 后，由侦听器通过事件流通知并自动将租约轮转分发给队列首位的 Run，并在 UI 同步更新最新的排队拓扑。

## ④ 前端（挂点/组件/字段/页面）
- **沿用**：默认工作台右侧上下文栏（D15），不新建壳。上=Progress 看板，下=文件列表，右侧按钮整体隐藏/显示。
- **全部文件**：文件列表 + 类型过滤器（chips）。**左侧不再新增「全部文件」按钮**（D15 约束）。
- **Library**：资产卡显示来源/许可证/复用范围/hash（设计资产记忆 D2 第六分区）。
- **租约冲突**：permission 卡新增租约字段（`ownerSeat`/`targets`/`mode`/`reason`/等待中）。timeline显示等待关系。
- **删除/移动/重命名**：走 permission 确认（L2/L3），显示证据链。

## ⑤ 后端（协议/服务/RPC/事件）
- **协议**（已冻，只读）：`team-run.ts` 的 `workspaceFileLeases` / lease 字段（`leaseId/ownerRunId/ownerSeatId/targets/mode/ttlMs/reason`）、`WORKSPACE_WRITE_LOCKED`。
- **服务**：
  - `WorkspaceFileLeaseManager` 加持久化（`.fleet/leases.json`）+ 启动还原 + 过期清理。
  - `WorkspaceFileLeaseManager` 新增与会话 Mode 状态（Plan/Execution）的同步感知接口，拦截并拒绝 Plan Mode 下的 `acquire` 写租约请求。
  - 粗粒度 `workspace:*` / repo 租约（给 CLI harness）。
  - Git mutate 统一 `.git` 写锁；并发 Git 写拒绝或排队。
  - **M3**：`ShadowWorkspaceService`（内存补丁树 + 三路合并 + apply）——**独立文件，M3 才建**，不动租约主路径。
- **RPC**（Lead 空壳）：`workspace.leases.list/acquire/release`；`files.list/move/rename/delete`（写走 permission）。`LOCAL_ONLY`。
- **事件**：租约获取/释放/冲突写 timeline；文件写操作带 lease 引用。

## ⑥ Agent 工具与 permission/timeline
- 读文件/列目录 L0；写/移动/重命名 L2；删除/清空 L3（规则 26）。
- Agent 写代码前必须声明 `writeTargets`（否则拒绝）。
- 租约冲突不给 Agent「强写」逃生舱，只能等待/排队/换 shadow worktree。

## ⑦ 验收矩阵
- [ ] 两个 run 并发写同一文件：后者进 `blocked_waiting_for_lease`，UI 显示等待关系，不崩溃、不并发写。
- [ ] read 不互斥、write/git_write 互斥、`workspace:*` 覆盖一切（复用现有 7 单测 + 补持久化单测）。
- [ ] 重启后过期租约被清理、未过期租约还原。
- [ ] 全部文件类型过滤可用；Library 资产卡显示来源/许可证。
- [ ] 删除走 L3 确认 + timeline。
- [ ] （M3，不在本波次）幽灵补丁树 flag 关闭时行为=纯租约。

## ⑧ 并行边界
- **文件所有者**：`workspace-file-lease-manager.ts`、`server-core files/workspace` 服务、全部文件/Library 右侧栏组件、租约 permission 卡组件。M3 的 `ShadowWorkspaceService` 单独文件。
- **只读依赖**：`team-run.ts`（承重墙）。**与蓝图 04 的耦合点**：lease 阻塞状态由 04 的 TeamRunCoordinator 消费——本 Agent 只保证 manager 契约稳定，04 负责调度侧。
- **回 Lead 加**：`workspace.leases.*` / `files.*` RPC、i18n。
- **波次**：Wave 1，与 01/03 并行。M3 幽灵补丁树排 Wave 3 之后（条件触发）。

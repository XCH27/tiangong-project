# 09 · messaging（Telegram / WhatsApp 桥）闭环

> **主 Agent 工作包**。依据 **D28（2026-07-05 用户拍板保留）**，回应 REVIEW-07-04 §4 问题 1。此前 CUT-01 §5 的删除决断已撤销。
> **红线**：与 D26 不冲突——用的是**用户自己的 IM 账号凭据**，不是 Fleet 账号系统；外发消息走 permission + timeline（不静默外发）；不做自动注册/群发/营销面；遵守各平台官方 Bot/API 通道（Telegram Bot API、WhatsApp 官方通道），不做协议逆向或封号风险玩法。

## ① 一句话闭环
把 Fleet 的任务/会话事件桥到用户自己的 Telegram/WhatsApp：**出向**（任务完成/待授权/失败通知推到 IM）与**入向**（IM 里回复批准/继续/追加指令，映射回同一 session），让长任务可以"人走开、手机上批"。

## ② 现状（代码已核对 2026-07-05）
- ✅ `packages/messaging-gateway`（Telegram+WhatsApp adapter，registry ~1.6k 行）+ `packages/messaging-whatsapp-worker` 存在。
- ✅ 前端已接线：`components/messaging/*`、`SessionItem.tsx`、`MessagingSettingsPage.tsx`(880 行)、配对码弹窗。
- 🟨 曾被 CUT-01 隐藏（settings-registry 分组），按 D28 **回滚恢复显示**。
- ⛔ 与 permission/timeline 的整合度未审计：入向指令是否走 permission 分级、出向是否写 timeline、凭据存储是否走 craft credentials.enc——本闭环第一件事是**审计现状并补齐这三点**。

## ③ 目标态
1. **出向通知**：可按事件类型订阅（任务完成/待授权 L2+/失败/RunReport 摘要）；内容为摘要+evidenceRef 链接，**不外发完整代码/secret**（复用蓝图 07 secret scan）。
2. **入向控制**：白名单账号 + 配对确认；指令集收敛为 `批准/拒绝/继续/状态/停止`（映射 permission 决策与 session 命令）；**L3 永不允许远程批准**（删除/发布/付款必须回桌面确认）。
3. **身份归位**：入向消息以 `actor: user(remote:telegram)` 进同一 timeline，可回放；不是第二个会话系统。
4. 凭据入 craft 加密存储；断线重连与配对状态在设置页可诊断。

## ④ 前端
`MessagingSettingsPage` 恢复显示（归"能力与插件"分区）：通道连接/配对码/白名单/事件订阅开关/最近外发记录（含 secret scan 结果）。会话内出向事件显示为 timeline 卡（"已推送到 Telegram"）。

## ⑤ 后端
- gateway 现有 adapter 保留；补 `MessagingPolicy`：事件过滤 + secret scan + 速率限制（防轰炸）。
- 入向命令解析 → 映射 permission RPC / session 命令；未识别指令回帮助文本，不猜。
- 事件：`messaging_outbound`（含内容摘要 hash、目标通道）/ `messaging_inbound`（含指令、决策结果）全写 timeline。

## ⑥ permission
出向：订阅配置 L1；单次外发含项目内容摘要 L2 首次确认后按订阅自动。入向：`批准` 仅限 L2 及以下且该请求本就 pending；L3 拒绝并提示回桌面。配对/改白名单 L2。

## ⑦ 验收
- [ ] 设置页恢复可见；配对 Telegram 成功收到测试通知。
- [ ] 待授权 L2 事件推送 IM，回复"批准"后任务继续，timeline 记录 remote actor 全链。
- [ ] L3 事件推送仅通知，回复批准被拒并提示回桌面。
- [ ] 外发内容过 secret scan；命中时不发送并提示。
- [ ] 凭据在 craft 加密存储；删除通道即撤凭据。

## ⑧ 并行边界
文件所有者：`packages/messaging-gateway`、`messaging-whatsapp-worker`、`components/messaging/*`、`MessagingSettingsPage.tsx`。只读依赖：permission 通道、timeline、secret scan（蓝图 07）。波次：Wave 3（C4）。
